-- Add language column to learning_activities
ALTER TABLE learning_activities ADD COLUMN IF NOT EXISTS language TEXT DEFAULT 'english';

-- Create certifications table
CREATE TABLE IF NOT EXISTS certifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  issuing_organization TEXT NOT NULL,
  issue_date DATE NOT NULL,
  expiry_date DATE,
  credential_id TEXT,
  credential_url TEXT,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create language_skills table
CREATE TABLE IF NOT EXISTS language_skills (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  language TEXT NOT NULL,
  reading_time_spent INTEGER DEFAULT 0,
  listening_time_spent INTEGER DEFAULT 0,
  proficiency_level TEXT,
  last_activity TIMESTAMP DEFAULT NOW()
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_certifications_user_id ON certifications(user_id);
CREATE INDEX IF NOT EXISTS idx_language_skills_user_id ON language_skills(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_language_skills_user_language ON language_skills(user_id, language);