-- Add missing columns to learning_milestones table
ALTER TABLE learning_milestones 
ADD COLUMN IF NOT EXISTS is_shared BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS privacy_level TEXT DEFAULT 'private',
ADD COLUMN IF NOT EXISTS share_url TEXT,
ADD COLUMN IF NOT EXISTS social_platforms JSONB DEFAULT '[]';

-- Create learning_goals table
CREATE TABLE IF NOT EXISTS learning_goals (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    creator_id INTEGER REFERENCES users(id),
    category TEXT NOT NULL,
    target_date TIMESTAMP WITH TIME ZONE,
    progress INTEGER DEFAULT 0,
    participants JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create milestone_celebrations table
CREATE TABLE IF NOT EXISTS milestone_celebrations (
    id SERIAL PRIMARY KEY,
    milestone_id INTEGER REFERENCES learning_milestones(id),
    user_id INTEGER REFERENCES users(id),
    celebration_type TEXT DEFAULT 'like',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create milestone_comments table
CREATE TABLE IF NOT EXISTS milestone_comments (
    id SERIAL PRIMARY KEY,
    milestone_id INTEGER REFERENCES learning_milestones(id),
    user_id INTEGER REFERENCES users(id),
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);