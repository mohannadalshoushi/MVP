import { db } from '../server/db';
import * as schema from '../shared/schema';
import { sql } from 'drizzle-orm';

async function main() {
  try {
    console.log('Starting database migration...');

    // Drop all tables if they exist (for clean setup)
    await db.execute(sql`DROP TABLE IF EXISTS learning_milestones CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS tool_usages CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS learning_summaries CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS quiz_questions CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS learning_activities CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS categories CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS users CASCADE`);

    // Create tables
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        name TEXT,
        email TEXT,
        sector TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL,
        color TEXT NOT NULL
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS learning_activities (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        url TEXT NOT NULL,
        source TEXT NOT NULL,
        category_id INTEGER NOT NULL,
        content_type TEXT NOT NULL,
        time_spent INTEGER NOT NULL,
        quiz_score INTEGER,
        summary TEXT,
        learning_date TIMESTAMP DEFAULT NOW()
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS quiz_questions (
        id SERIAL PRIMARY KEY,
        activity_id INTEGER NOT NULL,
        question TEXT NOT NULL,
        options JSONB NOT NULL,
        correct_option INTEGER NOT NULL,
        user_answer INTEGER
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS learning_summaries (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS tool_usages (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        tool_name TEXT NOT NULL,
        tool_category TEXT,
        hours_spent INTEGER NOT NULL,
        last_used_date TIMESTAMP DEFAULT NOW(),
        icon TEXT NOT NULL,
        color TEXT NOT NULL
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS learning_milestones (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        achieved_at TIMESTAMP DEFAULT NOW(),
        milestone_type TEXT NOT NULL,
        icon_name TEXT NOT NULL,
        celebrated_at TIMESTAMP,
        is_hidden BOOLEAN DEFAULT FALSE
      )
    `);

    // Add default categories
    const defaultCategories = [
      { name: 'Programming', icon: 'Code', color: '#0ea5e9' },
      { name: 'Design', icon: 'Palette', color: '#f43f5e' },
      { name: 'Marketing', icon: 'TrendingUp', color: '#8b5cf6' },
      { name: 'Data Science', icon: 'BarChart', color: '#10b981' },
      { name: 'Project Management', icon: 'Trello', color: '#f59e0b' },
      { name: 'Business', icon: 'Briefcase', color: '#6366f1' },
    ];

    for (const category of defaultCategories) {
      await db.insert(schema.categories).values(category).onConflictDoNothing();
    }

    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    process.exit(0);
  }
}

main();