import { db } from "./server/db";
import { certifications, languageSkills } from "./shared/schema";
import { eq } from "drizzle-orm";

// Test user ID
const userId = 1;

// Clear existing data for the test user
async function clearExistingData() {
  await db.delete(certifications).where(eq(certifications.userId, userId));
  await db.delete(languageSkills).where(eq(languageSkills.userId, userId));
  console.log("Cleared existing test data");
}

// Insert sample certifications
async function insertCertifications() {
  const date = new Date();
  const lastYear = new Date(date);
  lastYear.setFullYear(date.getFullYear() - 1);
  const nextYear = new Date(date);
  nextYear.setFullYear(date.getFullYear() + 1);

  const certificationsData = [
    {
      userId,
      name: "Project Management Professional (PMP)",
      issuingOrganization: "Project Management Institute",
      issueDate: lastYear,
      expiryDate: nextYear,
      credentialID: "PMP-123456",
      credentialURL: "https://www.pmi.org/verify/PMP-123456",
      description: "Global gold standard for project management certification, validating expertise in leading projects across industries."
    },
    {
      userId,
      name: "AWS Certified Solutions Architect",
      issuingOrganization: "Amazon Web Services",
      issueDate: date,
      expiryDate: null,
      credentialID: "AWS-SA-78901",
      credentialURL: "https://aws.amazon.com/verification",
      description: "Validates expertise in designing distributed systems on AWS, including security, scalability, and cost optimization."
    },
    {
      userId,
      name: "Certified Information Security Manager (CISM)",
      issuingOrganization: "ISACA",
      issueDate: lastYear,
      expiryDate: null,
      credentialID: "CISM-345678",
      credentialURL: null,
      description: "Focuses on information security governance, risk management, and program development."
    }
  ];

  const result = await db.insert(certifications).values(certificationsData).returning();
  console.log(`Inserted ${result.length} certifications`);
}

// Insert sample language skills
async function insertLanguageSkills() {
  const date = new Date();
  const lastWeek = new Date(date);
  lastWeek.setDate(date.getDate() - 7);
  
  const languageSkillsData = [
    {
      userId,
      language: "french",
      readingTimeSpent: 7200, // 2 hours in seconds
      listeningTimeSpent: 14400, // 4 hours in seconds
      proficiencyLevel: "Intermediate",
      lastActivity: date
    },
    {
      userId,
      language: "spanish",
      readingTimeSpent: 3600, // 1 hour in seconds
      listeningTimeSpent: 1800, // 30 minutes in seconds
      proficiencyLevel: "Beginner",
      lastActivity: lastWeek
    },
    {
      userId,
      language: "german",
      readingTimeSpent: 10800, // 3 hours in seconds
      listeningTimeSpent: 5400, // 1.5 hours in seconds
      proficiencyLevel: "Advanced",
      lastActivity: date
    }
  ];

  const result = await db.insert(languageSkills).values(languageSkillsData).returning();
  console.log(`Inserted ${result.length} language skills`);
}

// Main function to run the script
async function main() {
  try {
    await clearExistingData();
    await insertCertifications();
    await insertLanguageSkills();
    console.log("Sample data created successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error creating sample data:", error);
    process.exit(1);
  }
}

main();