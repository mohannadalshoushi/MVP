# Learnfy.AI Deployment Guide

This document provides step-by-step instructions for properly deploying the Learnfy.AI application on Replit.

## TL;DR Quick Steps

1. Create a PostgreSQL database (e.g., on Neon.tech)
2. Set `DATABASE_URL` in Replit Deployment Secrets
3. Run `npm run db:push` once to set up the database schema
4. Deploy your application via the Replit Dashboard

## Prerequisites

Before deploying the application, ensure you have:

1. A PostgreSQL database (we recommend Neon.tech for serverless PostgreSQL)
2. OpenAI API key for AI features

## Required Environment Variables

The application requires the following environment variables to be set in your **Replit Deployment Secrets**:

| Variable | Description | Required | Example |
|----------|-------------|----------|---------|
| `DATABASE_URL` | PostgreSQL connection string | **Required** | `postgresql://user:pass@db.example.com:5432/mydb` |
| `OPENAI_API_KEY` | OpenAI API key for AI features | **Required** | `sk-...` |
| `SESSION_SECRET` | Secret for session encryption | **Required** | `mysecretkey` |

## Step-by-Step Deployment Guide

### 1. Create a PostgreSQL Database

We recommend using [Neon.tech](https://neon.tech) for its serverless PostgreSQL capabilities:

1. Sign up for a Neon account
2. Create a new project
3. Within your project, create a new branch (typically "main")
4. Navigate to the "Connection Details" section
5. Copy the connection string that looks like: `postgresql://username:password@endpoint:5432/database`

### 2. Set Environment Variables in Replit

1. In your Replit project, click on "Secrets" (lock icon) in the Tools panel
2. Add a new secret with:
   - Key: `DATABASE_URL`
   - Value: Your PostgreSQL connection string

3. Add additional required secrets:
   - `OPENAI_API_KEY` with your OpenAI API key
   - `SESSION_SECRET` with a secure random string

### 3. Set Up Database Schema

Run the following command to synchronize the database schema:

```bash
npm run db:push
```

This will create all necessary tables based on the schema defined in `shared/schema.ts`. You only need to do this once or whenever you update your schema.

### 4. Deploy Your Application

1. Click on the "Deploy" button in your Replit project
2. Follow the prompts to deploy your application
3. Your application will now be available at your Replit deployment URL

## Troubleshooting Common Deployment Issues

### Application Fails to Start

If your application fails to start with the error "Missing DATABASE_URL environment variable":

1. **Verify Environment Variable**: Double-check that `DATABASE_URL` is correctly set in your Replit Deployment Secrets, not just in the regular Secrets
2. **Check Connection String Format**: Ensure the connection string follows the format: `postgresql://username:password@host:port/database`
3. **Verify Database Access**: Make sure your database allows connections from Replit's IP addresses

### Database Schema Mismatch Errors

If you see errors like "column 'is_shared' does not exist":

1. Run `npm run db:push` again to update the database schema
2. If that doesn't work, you may need to reset your database and run `npm run db:push` again

### Database Connection Issues

If the application can't connect to the database:

1. **Check Credentials**: Verify username and password in the connection string
2. **Network Access**: Ensure your database allows connections from Replit's IP addresses
3. **Database Status**: Check if your database service is active and not in maintenance mode

## Monitoring and Maintenance

- Monitor the application logs for any database-related errors
- Periodically check the database connection status
- Back up your database regularly to prevent data loss

## Need Further Help?

If you're still experiencing deployment issues:

1. Check the application logs for specific error messages
2. Verify all environment variables are set correctly
3. Ensure your database is accessible from Replit's network

For additional support, contact the Learnfy.AI development team.