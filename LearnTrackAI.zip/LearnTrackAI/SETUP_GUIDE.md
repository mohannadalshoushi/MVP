# LearnTrack AI Chrome Extension - Setup Guide

## Overview

LearnTrack AI is a Chrome extension that automatically tracks and documents your professional learning activities. When you browse educational content, the extension captures and analyzes it based on your professional sector. After consuming content, the extension shows a popup quiz to test your understanding. All learning activities are tracked through a dashboard, and the knowledge gained is summarized to serve as a "Live CV" for your professional development.

## Requirements

- Chrome browser (version 88 or later)
- Node.js (version 16 or later)
- An OpenAI API key with access to the gpt-4o model

## Installation

### Server Setup

1. Clone this repository to your local machine.
2. Navigate to the project root directory.
3. Install the required dependencies:
   ```
   npm install
   ```
4. Create a `.env` file in the project root with the following content:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```
5. Start the server:
   ```
   npm run dev
   ```
   This will start the server on port 5000.

### Extension Setup

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" by toggling the switch in the top right corner.
3. Click "Load unpacked" and select the `client/public` directory from this project.
4. The LearnTrack AI extension should now appear in your Chrome extensions.

## Using the Extension

1. **Browse Learning Content**: The extension automatically activates when you visit educational websites or content that appears to be learning material.

2. **Track Learning**: When active, the extension will track your time spent on the content and analyze what you're learning.

3. **Take Quizzes**: When you finish reading an article or watching a video, you'll be presented with a quiz to test your understanding.

4. **View Your Learning Portfolio**: Open the LearnTrack AI dashboard to see your learning history, analytics, and your "Live CV" which summarizes your learning by category.

## Features

- **Automatic Content Detection**: Identifies when you're consuming educational content.
- **Content Analysis**: Uses AI to categorize and summarize what you're learning.
- **Learning Quizzes**: Tests your understanding of the material you've consumed.
- **Time Tracking**: Monitors how much time you spend on different learning topics.
- **Live CV Generation**: Creates professional summaries of your learning by category.
- **Learning Dashboard**: View analytics about your learning habits and progress.

## Troubleshooting

- **Extension Not Tracking**: Make sure you're on a supported website and that the content is educational in nature.
- **Server Connection Issues**: Verify that the server is running on port 5000 and that your network allows the connection.
- **OpenAI API Errors**: Check that your API key is valid and has access to the required models.

## Development

To modify the extension:

1. Make changes to the files in the `client/public` directory for extension frontend changes.
2. Modify server-side logic in the `server` directory.
3. For changes to the data model, update `shared/schema.ts`.
4. After making changes, refresh the extension in Chrome by clicking the refresh icon on the extensions page.

## License

This project is licensed under the MIT License.