// Background script for LearnTrack AI Chrome Extension
// Handles tracking, monitoring tabs, and communicating with server

// Configuration
const API_URL = "http://localhost:5000/api";
let isTracking = true;
let currentTabId = null;
let learningActivities = {};
let userSettings = {
  autoTrack: true,
  alwaysShowQuiz: true,
  trackTime: true,
  useAI: true
};
let currentUser = null;

// Initialize extension
(async function init() {
  // Load user settings from storage
  try {
    const data = await chrome.storage.local.get(['user', 'settings']);
    if (data.user) {
      currentUser = data.user;
    }
    if (data.settings) {
      userSettings = { ...userSettings, ...data.settings };
    }
  } catch (error) {
    console.error("Error loading settings:", error);
  }

  // Set up tab tracking
  setupTabTracking();
})();

// Set up tab tracking to monitor learning activity
function setupTabTracking() {
  // Track active tab changes
  chrome.tabs.onActivated.addListener(activeInfo => {
    updateCurrentTab(activeInfo.tabId);
  });

  // Track tab updates (URL changes, page loads)
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.active) {
      updateCurrentTab(tabId);
    }
  });

  // Track tab closures (potential quiz opportunity)
  chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
    if (tabId === currentTabId && learningActivities[tabId]) {
      const activity = learningActivities[tabId];
      
      // If user has spent significant time on the page and quiz setting is enabled
      if (activity.timeSpent > 60 && userSettings.alwaysShowQuiz) {
        // Save activity before showing quiz
        saveActivity(activity)
          .then(() => {
            // Notify popup to display the quiz
            chrome.runtime.sendMessage({
              action: "showQuiz", 
              contentId: activity.id,
              contentTitle: activity.title
            });
          })
          .catch(err => {
            console.error("Failed to save activity before quiz:", err);
          });
      }
      
      // Clean up
      delete learningActivities[tabId];
    }
  });
}

// Update current tab information
async function updateCurrentTab(tabId) {
  try {
    currentTabId = tabId;
    
    const tab = await chrome.tabs.get(tabId);
    
    // Check if this is a learning content URL
    if (isLearningContent(tab.url)) {
      // Start tracking if not already tracking this tab
      if (!learningActivities[tabId]) {
        // Determine content type and source
        const urlData = preprocessUrl(tab.url);
        
        learningActivities[tabId] = {
          url: tab.url,
          title: tab.title,
          source: urlData.source,
          contentType: urlData.contentType,
          startTime: Date.now(),
          timeSpent: 0,
          lastUpdated: Date.now()
        };
        
        // Send message to content script to extract content
        chrome.tabs.sendMessage(tabId, { action: "extractContent" });
      } else {
        // Update timeSpent for existing activity
        updateTimeSpent(tabId);
      }
      
      // Notify popup that we're tracking this tab
      chrome.runtime.sendMessage({
        action: "updateTracking",
        isTracking: true,
        content: learningActivities[tabId]
      });
    } else {
      // Not learning content, notify popup
      chrome.runtime.sendMessage({
        action: "updateTracking",
        isTracking: false
      });
    }
  } catch (error) {
    console.error("Error updating current tab:", error);
  }
}

// Check if URL is likely learning content
function isLearningContent(url) {
  if (!url) return false;
  
  // Skip browser specific pages, extension pages, etc.
  if (url.startsWith('chrome://') || 
      url.startsWith('chrome-extension://') || 
      url.startsWith('about:') ||
      url.startsWith('edge://') || 
      url.startsWith('brave://')) {
    return false;
  }
  
  // Check for common learning platforms
  const learningDomains = [
    'youtube.com', 'medium.com', 'dev.to', 'stackoverflow.com', 
    'github.com', 'udemy.com', 'coursera.org', 'edx.org',
    'pluralsight.com', 'freecodecamp.org', 'w3schools.com',
    'hackernoon.com', 'towardsdatascience.com', 'blog.', 'docs.'
  ];
  
  const urlObj = new URL(url);
  return learningDomains.some(domain => urlObj.hostname.includes(domain));
}

// Preprocess URL to determine content type and source
function preprocessUrl(url) {
  const urlObj = new URL(url);
  const hostname = urlObj.hostname;
  
  // Check for YouTube
  if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
    return {
      contentType: 'video',
      source: 'youtube.com'
    };
  }
  
  // Default to article and extract domain
  return {
    contentType: 'article',
    source: hostname.replace('www.', '')
  };
}

// Update time spent on the current tab
function updateTimeSpent(tabId) {
  if (learningActivities[tabId]) {
    const now = Date.now();
    const activity = learningActivities[tabId];
    
    // Only count time if less than 5 minutes have passed since last update
    // (prevents counting time when the user is away)
    if (now - activity.lastUpdated < 5 * 60 * 1000) {
      activity.timeSpent += Math.floor((now - activity.lastUpdated) / 1000);
    }
    
    activity.lastUpdated = now;
  }
}

// Save learning activity to server
async function saveActivity(activity) {
  if (!currentUser) {
    console.error("Cannot save activity: No user logged in");
    return;
  }
  
  try {
    // 1. Save the learning activity
    const response = await fetch(`${API_URL}/learning-activities`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: currentUser.id,
        title: activity.title,
        url: activity.url,
        source: activity.source,
        categoryId: activity.categoryId || 1, // Default to first category if not set
        contentType: activity.contentType,
        timeSpent: activity.timeSpent,
        summary: activity.summary
      })
    });
    
    if (!response.ok) {
      throw new Error(`Failed to save activity: ${response.status}`);
    }
    
    const savedActivity = await response.json();
    
    // 2. If language was detected, track language skill
    if (activity.language) {
      try {
        await fetch(`${API_URL}/track-language`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            userId: currentUser.id,
            language: activity.language,
            contentType: activity.contentType,
            timeSpent: activity.timeSpent
          })
        });
        
        console.log(`Language tracked: ${activity.language} (${activity.contentType})`);
      } catch (langError) {
        console.error("Error tracking language:", langError);
        // Don't throw here - we still want to return the saved activity
      }
    }
    
    return savedActivity;
  } catch (error) {
    console.error("Error saving activity:", error);
    throw error;
  }
}

// Generate quiz for activity
async function generateQuiz(activityId, content) {
  try {
    const response = await fetch(`${API_URL}/generate-quiz`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        activityId,
        content,
        numQuestions: 3
      })
    });
    
    if (!response.ok) {
      throw new Error(`Failed to generate quiz: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error generating quiz:", error);
    throw error;
  }
}

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle message based on action
  switch (message.action) {
    case "getTrackingStatus":
      if (currentTabId) {
        sendResponse({
          isTracking: !!learningActivities[currentTabId],
          content: learningActivities[currentTabId]
        });
      } else {
        sendResponse({ isTracking: false });
      }
      break;
      
    case "toggleTracking":
      isTracking = message.value;
      if (!isTracking && currentTabId && learningActivities[currentTabId]) {
        delete learningActivities[currentTabId];
      } else if (isTracking && currentTabId) {
        updateCurrentTab(currentTabId);
      }
      sendResponse({ isTracking });
      break;
      
    case "setCategory":
      if (currentTabId && learningActivities[currentTabId]) {
        learningActivities[currentTabId].categoryId = message.categoryId;
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "No active learning activity" });
      }
      break;
      
    case "contentExtracted":
      if (currentTabId && learningActivities[currentTabId]) {
        learningActivities[currentTabId].content = message.content;
        
        // Store detected language (if available)
        if (message.language) {
          learningActivities[currentTabId].language = message.language;
        }
        
        // Analyze content to determine category
        analyzeContent(message.content)
          .then(result => {
            if (result.category && result.summary) {
              learningActivities[currentTabId].categoryId = result.categoryId;
              learningActivities[currentTabId].summary = result.summary;
              
              // Update popup with new info
              chrome.runtime.sendMessage({
                action: "contentAnalyzed",
                category: result.category,
                summary: result.summary
              });
            }
          })
          .catch(err => {
            console.error("Failed to analyze content:", err);
          });
        
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "No active learning activity" });
      }
      break;
      
    case "saveActivity":
      if (currentTabId && learningActivities[currentTabId]) {
        saveActivity(learningActivities[currentTabId])
          .then(savedActivity => {
            sendResponse({ success: true, activity: savedActivity });
          })
          .catch(err => {
            sendResponse({ success: false, error: err.message });
          });
        return true; // Will respond asynchronously
      } else {
        sendResponse({ success: false, error: "No active learning activity" });
      }
      break;
      
    case "updateSettings":
      userSettings = { ...userSettings, ...message.settings };
      chrome.storage.local.set({ settings: userSettings });
      sendResponse({ success: true });
      break;
      
    case "login":
      currentUser = message.user;
      chrome.storage.local.set({ user: currentUser });
      sendResponse({ success: true });
      break;
      
    case "logout":
      currentUser = null;
      chrome.storage.local.remove('user');
      sendResponse({ success: true });
      break;
  }
  
  return true;
});

// Analyze content to determine category and generate summary
async function analyzeContent(content) {
  try {
    const response = await fetch(`${API_URL}/analyze-content`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ content })
    });
    
    if (!response.ok) {
      throw new Error(`Failed to analyze content: ${response.status}`);
    }
    
    const analysis = await response.json();
    
    // Find category ID based on name
    const categoryResponse = await fetch(`${API_URL}/categories`);
    if (!categoryResponse.ok) {
      throw new Error(`Failed to fetch categories: ${categoryResponse.status}`);
    }
    
    const categories = await categoryResponse.json();
    const matchedCategory = categories.find(cat => 
      cat.name.toLowerCase() === analysis.category.toLowerCase()
    );
    
    return {
      categoryId: matchedCategory ? matchedCategory.id : 1,
      category: matchedCategory || { name: analysis.category, color: "#3B82F6" },
      summary: analysis.summary
    };
  } catch (error) {
    console.error("Error analyzing content:", error);
    throw error;
  }
}
