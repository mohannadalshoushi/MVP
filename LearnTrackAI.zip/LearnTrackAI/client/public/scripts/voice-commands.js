/**
 * Voice Commands for Learnfy.AI Chrome Extension
 * Implements voice control for extension functionality
 */
class VoiceCommandHandler {
  constructor(voiceControlService) {
    this.voiceControl = voiceControlService;
    
    // Register all commands
    this.registerCommands();
  }

  /**
   * Register all voice commands for the extension
   */
  registerCommands() {
    // Activation command - this is a special command that will be recognized
    // even when voice control is not active
    this.voiceControl.registerCommand('(hey|hi|hello) learn(fy|fee)', () => {
      this.voiceControl.activate();
      this.voiceControl.speak('Learnfy voice assistant is ready. How can I help you?');
    });
    
    // Extension navigation commands
    this.registerNavigationCommands();
    
    // Learning tracking commands
    this.registerTrackingCommands();
    
    // Content interaction commands
    this.registerContentCommands();
    
    // Quiz interaction commands
    this.registerQuizCommands();
    
    // Dashboard commands
    this.registerDashboardCommands();
    
    // General commands
    this.registerGeneralCommands();
  }

  /**
   * Register navigation commands
   */
  registerNavigationCommands() {
    // Open dashboard
    this.voiceControl.registerCommand('(open|show|go to) dashboard', () => {
      window.location.href = '/dashboard';
    });
    
    // Open settings
    this.voiceControl.registerCommand('(open|show|go to) settings', () => {
      window.location.href = '/settings';
    });
    
    // Open specific page
    this.voiceControl.registerCommand('(open|show|go to) (my )?(certifications|certificates)', () => {
      window.location.href = '/certifications';
    });
    
    this.voiceControl.registerCommand('(open|show|go to) (my )?(language skills|languages)', () => {
      window.location.href = '/language-skills';
    });
    
    this.voiceControl.registerCommand('(open|show|go to) (my )?(knowledge base|resources)', () => {
      window.location.href = '/knowledge-base';
    });
    
    this.voiceControl.registerCommand('(open|show|go to) (my )?(cv|resume|live cv)', () => {
      window.location.href = '/live-cv';
    });
    
    this.voiceControl.registerCommand('(open|show|go to) (my )?(learning history|history)', () => {
      window.location.href = '/learning-history';
    });
    
    // Go back
    this.voiceControl.registerCommand('(go )back', () => {
      window.history.back();
    });
  }

  /**
   * Register learning tracking commands
   */
  registerTrackingCommands() {
    // Start tracking
    this.voiceControl.registerCommand('(start|begin) tracking', () => {
      if (document.getElementById('resume-btn')) {
        document.getElementById('resume-btn').click();
      }
      this.voiceControl.speak('Started tracking your learning activity');
    });
    
    // Pause tracking
    this.voiceControl.registerCommand('(pause|stop) tracking', () => {
      if (document.getElementById('pause-btn')) {
        document.getElementById('pause-btn').click();
      }
      this.voiceControl.speak('Paused learning activity tracking');
    });
    
    // Change category
    this.voiceControl.registerCommand('change category', () => {
      if (document.getElementById('change-category-btn')) {
        document.getElementById('change-category-btn').click();
      }
      this.voiceControl.speak('Select a category for this content');
    });
    
    // Select a specific category by name
    this.voiceControl.registerCommand('(set|select|choose) category (to )?([a-z ]+)', (match) => {
      const categoryName = match[3].trim().toLowerCase();
      
      // Try to find the category in the list
      if (document.getElementById('categories-list')) {
        const categoryLabels = document.querySelectorAll('#categories-list label');
        
        for (let i = 0; i < categoryLabels.length; i++) {
          const label = categoryLabels[i];
          if (label.textContent.toLowerCase().includes(categoryName)) {
            // Find the associated radio input and select it
            const radioId = label.getAttribute('for');
            const radio = document.getElementById(radioId);
            if (radio) {
              radio.checked = true;
              
              // Save the category
              if (document.getElementById('save-category-btn')) {
                document.getElementById('save-category-btn').click();
              }
              
              this.voiceControl.speak(`Category set to ${label.textContent}`);
              return;
            }
          }
        }
        
        this.voiceControl.speak(`Couldn't find category ${categoryName}`);
      }
    });
    
    // Add a note
    this.voiceControl.registerCommand('add (a )?note', () => {
      if (document.getElementById('add-note-btn')) {
        document.getElementById('add-note-btn').click();
      }
      this.voiceControl.speak('What would you like to note about this content?');
    });
    
    // Save the note with dictation
    this.voiceControl.registerCommand('(note|write down|save note) (that )?([a-z0-9 ,.!?]+)', (match) => {
      const noteText = match[3].trim();
      
      if (document.getElementById('note-content')) {
        document.getElementById('note-content').value = noteText;
        
        // If there's a submit button in the note form, click it
        const noteForm = document.getElementById('note-form');
        if (noteForm) {
          const submitBtn = noteForm.querySelector('button[type="submit"]');
          if (submitBtn) {
            submitBtn.click();
            this.voiceControl.speak('Note saved');
          }
        }
      }
    });
  }

  /**
   * Register content interaction commands
   */
  registerContentCommands() {
    // Read the current content
    this.voiceControl.registerCommand('read (this )?(content|page|article)', () => {
      let content = '';
      
      // Try to find the main content
      const contentTitle = document.getElementById('content-title');
      if (contentTitle) {
        content += contentTitle.textContent + '. ';
      }
      
      // In a real extension, we'd extract the main content from the page
      // For this demo, we'll use a placeholder message
      content += 'This is the article content. In the actual extension, the content of the current page would be extracted and read aloud.';
      
      this.voiceControl.speak(content);
    });
    
    // Summarize content
    this.voiceControl.registerCommand('(summarize|summary of) (this )?(content|page|article)', () => {
      // In a real extension, we'd generate a summary of the content
      // For this demo, we'll use a placeholder message
      const summary = 'This article discusses machine learning fundamentals, covering supervised and unsupervised learning approaches, common algorithms, and practical applications in various industries.';
      
      this.voiceControl.speak('Here is a summary of this content: ' + summary);
    });
  }

  /**
   * Register quiz interaction commands
   */
  registerQuizCommands() {
    // Answer quiz question with option number
    this.voiceControl.registerCommand('(select|choose|answer) (option|answer) (number )?(\\d)', (match) => {
      const optionNumber = parseInt(match[4]);
      
      if (document.getElementById('quiz-container')) {
        const options = document.querySelectorAll('.quiz-option');
        if (options && optionNumber > 0 && optionNumber <= options.length) {
          options[optionNumber - 1].click();
          this.voiceControl.speak(`Selected option ${optionNumber}`);
        } else {
          this.voiceControl.speak(`Invalid option number. Please choose between 1 and ${options.length}`);
        }
      }
    });
    
    // Go to next quiz question
    this.voiceControl.registerCommand('next (question)', () => {
      if (document.getElementById('quiz-next-btn')) {
        document.getElementById('quiz-next-btn').click();
      }
    });
    
    // Go to previous quiz question
    this.voiceControl.registerCommand('(previous|back) (question)', () => {
      if (document.getElementById('quiz-back-btn')) {
        document.getElementById('quiz-back-btn').click();
      }
    });
    
    // Finish quiz
    this.voiceControl.registerCommand('finish quiz', () => {
      if (document.getElementById('finish-quiz-btn')) {
        document.getElementById('finish-quiz-btn').click();
      }
    });
  }

  /**
   * Register dashboard commands
   */
  registerDashboardCommands() {
    // Open specific dashboard section
    this.voiceControl.registerCommand('show (my )?(learning )?progress', () => {
      if (window.location.pathname === '/dashboard') {
        // Scroll to learning progress section
        const progressSection = document.querySelector('.learning-progress');
        if (progressSection) {
          progressSection.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.location.href = '/dashboard';
      }
    });
    
    this.voiceControl.registerCommand('show (my )?(learning )?timeline', () => {
      if (window.location.pathname === '/dashboard') {
        // Scroll to timeline section
        const timelineSection = document.querySelector('.learning-timeline');
        if (timelineSection) {
          timelineSection.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.location.href = '/dashboard';
      }
    });
    
    this.voiceControl.registerCommand('show (my )?(recent )?activities', () => {
      if (window.location.pathname === '/dashboard') {
        // Scroll to recent activities section
        const activitiesSection = document.querySelector('.recent-activities');
        if (activitiesSection) {
          activitiesSection.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.location.href = '/dashboard';
      }
    });
    
    this.voiceControl.registerCommand('show recommendations', () => {
      if (window.location.pathname === '/dashboard') {
        // Scroll to recommendations section
        const recommendationsSection = document.querySelector('.recommended-content');
        if (recommendationsSection) {
          recommendationsSection.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.location.href = '/dashboard';
      }
    });
    
    // Change time period/timeframe
    this.voiceControl.registerCommand('(show|set) (time ?frame|period) (to )?([a-z0-9 ]+)', (match) => {
      const timeframeText = match[4].trim().toLowerCase();
      
      // Map spoken timeframes to values in the UI
      const timeframeMap = {
        'week': '7days',
        'month': '30days',
        'last week': '7days',
        'last month': '30days',
        'last four weeks': '30days',
        'all time': 'all',
        'all': 'all',
        'today': 'today',
        'yesterday': 'yesterday'
      };
      
      const timeframeValue = timeframeMap[timeframeText] || timeframeText;
      
      // Try to find timeframe selectors and set the value
      const timeframeSelects = document.querySelectorAll('select[data-timeframe]');
      if (timeframeSelects.length) {
        let found = false;
        
        timeframeSelects.forEach(select => {
          for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].value.toLowerCase() === timeframeValue || 
                select.options[i].textContent.toLowerCase() === timeframeText) {
              select.value = select.options[i].value;
              select.dispatchEvent(new Event('change'));
              found = true;
              break;
            }
          }
        });
        
        if (found) {
          this.voiceControl.speak(`Timeframe set to ${timeframeText}`);
        } else {
          this.voiceControl.speak(`Couldn't find timeframe ${timeframeText}`);
        }
      }
    });
  }

  /**
   * Register general commands
   */
  registerGeneralCommands() {
    // Help command
    this.voiceControl.registerCommand('(what can you do|help|commands|voice commands)', () => {
      const helpText = `
        You can control Learnfy with voice commands.
        
        Try saying things like:
        "Open dashboard"
        "Start tracking" or "Pause tracking"
        "Change category"
        "Add a note"
        "Read this content"
        "Show my learning progress"
        
        For accessibility settings, say "Open accessibility"
      `;
      
      this.voiceControl.speak(helpText);
    });
    
    // Exit/quit voice control
    this.voiceControl.registerCommand('(exit|quit|disable|turn off) (voice (control|assistant))', () => {
      this.voiceControl.speak('Voice assistant turning off. Say "Hey Learnfy" to activate again.');
      this.voiceControl.deactivate();
    });
    
    // Repeat last action or text
    this.voiceControl.registerCommand('(repeat|say again)', () => {
      // This would be implemented to repeat the last spoken text
      this.voiceControl.speak('Repeat functionality is available in the full version.');
    });
  }
}

// Export the handler
// Note: Will be initialized after voiceControl service is loaded