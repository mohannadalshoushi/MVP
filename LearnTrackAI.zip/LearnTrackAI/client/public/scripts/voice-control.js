/**
 * Voice Control Service for Learnfy.AI
 * Provides voice recognition and text-to-speech functionality
 */
class VoiceControlService {
  constructor() {
    this.isVoiceActivated = false;
    this.recognition = null;
    this.synthesis = window.speechSynthesis;
    this.commands = new Map();
    this.isListening = false;
    this.commandCallbacks = {};
    this.settings = {
      voiceActivation: true,
      textToSpeech: true,
      commandFeedback: true,
      voiceSpeed: 1,
      voicePitch: 1,
      preferredVoice: null,
      language: 'en-US',
      accessibilityMode: false
    };

    // Load settings from storage
    this.loadSettings();
    
    // Initialize speech recognition if supported
    this.initSpeechRecognition();
  }

  /**
   * Initialize speech recognition if the browser supports it
   */
  initSpeechRecognition() {
    // Check for browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      console.warn('Speech recognition not supported in this browser');
      return false;
    }
    
    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = false;
    this.recognition.lang = this.settings.language;
    
    // Set up recognition event handlers
    this.recognition.onstart = () => {
      this.isListening = true;
      this.triggerEvent('voiceStatusChange', { isListening: true });
      console.log('Voice recognition started');
    };
    
    this.recognition.onend = () => {
      this.isListening = false;
      this.triggerEvent('voiceStatusChange', { isListening: false });
      console.log('Voice recognition ended');
      
      // Restart if voice activation is still on
      if (this.isVoiceActivated) {
        this.recognition.start();
      }
    };
    
    this.recognition.onerror = (event) => {
      console.error('Voice recognition error:', event.error);
      this.triggerEvent('voiceError', event);
      
      // Restart on most errors
      if (event.error !== 'aborted' && event.error !== 'no-speech' && this.isVoiceActivated) {
        setTimeout(() => {
          if (this.isVoiceActivated) this.recognition.start();
        }, 1000);
      }
    };
    
    this.recognition.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
      console.log('Voice command recognized:', transcript);
      
      this.triggerEvent('voiceCommand', transcript);
      this.processCommand(transcript);
    };
    
    return true;
  }

  /**
   * Start voice recognition
   */
  activate() {
    if (!this.recognition) return false;
    
    try {
      this.isVoiceActivated = true;
      if (!this.isListening) {
        this.recognition.start();
      }
      this.speak('Voice control activated');
      return true;
    } catch (error) {
      console.error('Error activating voice control:', error);
      return false;
    }
  }

  /**
   * Stop voice recognition
   */
  deactivate() {
    if (!this.recognition) return false;
    
    try {
      this.isVoiceActivated = false;
      this.recognition.stop();
      this.speak('Voice control deactivated');
      return true;
    } catch (error) {
      console.error('Error deactivating voice control:', error);
      return false;
    }
  }

  /**
   * Toggle voice activation on/off
   */
  toggle() {
    return this.isVoiceActivated ? this.deactivate() : this.activate();
  }

  /**
   * Process a recognized voice command
   */
  processCommand(transcript) {
    // Check if the transcript matches any registered command
    let commandExecuted = false;
    
    this.commands.forEach((handlers, commandPattern) => {
      const regex = new RegExp(commandPattern, 'i');
      const match = transcript.match(regex);
      
      if (match) {
        handlers.forEach(handler => {
          handler(match);
          commandExecuted = true;
        });
      }
    });
    
    // Provide feedback if a command was executed
    if (commandExecuted && this.settings.commandFeedback) {
      this.provideFeedback();
    }
    
    return commandExecuted;
  }

  /**
   * Play a sound or speak to confirm command was recognized
   */
  provideFeedback() {
    // Short beep or speech feedback
    if (this.settings.commandFeedback) {
      // Play a short beep sound or just speak "OK"
      this.speak('Ok');
    }
  }

  /**
   * Register a voice command with a callback
   */
  registerCommand(commandPattern, callback) {
    if (!this.commands.has(commandPattern)) {
      this.commands.set(commandPattern, []);
    }
    
    this.commands.get(commandPattern).push(callback);
    console.log(`Registered command pattern: ${commandPattern}`);
  }

  /**
   * Convert text to speech
   */
  speak(text, options = {}) {
    if (!this.synthesis || !this.settings.textToSpeech) return false;
    
    // Stop any current speech
    this.synthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice properties
    utterance.rate = options.rate || this.settings.voiceSpeed;
    utterance.pitch = options.pitch || this.settings.voicePitch;
    utterance.lang = options.language || this.settings.language;
    
    // Set preferred voice if available
    if (this.settings.preferredVoice) {
      const voices = this.synthesis.getVoices();
      const preferredVoice = voices.find(voice => voice.name === this.settings.preferredVoice);
      if (preferredVoice) utterance.voice = preferredVoice;
    }
    
    // Events
    utterance.onstart = () => this.triggerEvent('speechStart', { text });
    utterance.onend = () => this.triggerEvent('speechEnd', { text });
    utterance.onerror = (event) => this.triggerEvent('speechError', event);
    
    // Speak the text
    this.synthesis.speak(utterance);
    return true;
  }

  /**
   * Read content from a given element or text
   */
  readContent(contentOrElement) {
    let textToRead;
    
    if (typeof contentOrElement === 'string') {
      textToRead = contentOrElement;
    } else if (contentOrElement instanceof HTMLElement) {
      textToRead = contentOrElement.textContent;
    } else {
      console.error('Invalid content for reading');
      return false;
    }
    
    return this.speak(textToRead);
  }

  /**
   * Get available voices for speech synthesis
   */
  getAvailableVoices() {
    if (!this.synthesis) return [];
    return this.synthesis.getVoices();
  }

  /**
   * Update voice control settings
   */
  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    
    // Apply relevant settings
    if (this.recognition) {
      this.recognition.lang = this.settings.language;
    }
    
    // Save settings
    this.saveSettings();
    
    // Trigger settings change event
    this.triggerEvent('settingsChange', this.settings);
    
    return this.settings;
  }

  /**
   * Save settings to storage
   */
  saveSettings() {
    try {
      localStorage.setItem('learnfy_voice_settings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('Error saving voice settings:', error);
    }
  }

  /**
   * Load settings from storage
   */
  loadSettings() {
    try {
      const savedSettings = localStorage.getItem('learnfy_voice_settings');
      if (savedSettings) {
        this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
      }
    } catch (error) {
      console.error('Error loading voice settings:', error);
    }
  }

  /**
   * Register event listener
   */
  on(event, callback) {
    if (!this.commandCallbacks[event]) {
      this.commandCallbacks[event] = [];
    }
    
    this.commandCallbacks[event].push(callback);
  }

  /**
   * Trigger an event for all listeners
   */
  triggerEvent(event, data) {
    if (this.commandCallbacks[event]) {
      this.commandCallbacks[event].forEach(callback => callback(data));
    }
  }
}

// Export the service
const voiceControl = new VoiceControlService();