/**
 * Accessibility Settings Panel for Learnfy.AI
 * Provides UI for controlling voice and accessibility features
 */
class AccessibilityPanel {
  constructor(voiceControlService) {
    this.voiceControl = voiceControlService;
    this.isOpen = false;
    this.panel = null;
    this.voices = [];
    
    // Initialize the panel
    this.initPanel();
    
    // Register voice commands
    this.registerVoiceCommands();
    
    // Listen for voice status changes
    this.voiceControl.on('voiceStatusChange', (data) => {
      this.updateVoiceStatus(data.isListening);
    });
    
    // Get available voices once they're loaded
    if (window.speechSynthesis) {
      if (speechSynthesis.getVoices().length > 0) {
        this.voices = speechSynthesis.getVoices();
      }
      
      speechSynthesis.onvoiceschanged = () => {
        this.voices = speechSynthesis.getVoices();
        this.updateVoiceList();
      };
    }
  }

  /**
   * Initialize the accessibility panel
   */
  initPanel() {
    // Create panel container
    this.panel = document.createElement('div');
    this.panel.id = 'accessibility-panel';
    this.panel.className = 'accessibility-panel';
    this.panel.style.display = 'none';
    
    // Populate panel with HTML
    this.panel.innerHTML = `
      <div class="panel-header">
        <h3 class="text-lg font-semibold text-gray-800">Accessibility Settings</h3>
        <button id="close-a11y-panel" class="close-btn">
          <span class="material-icons">close</span>
        </button>
      </div>
      
      <div class="panel-body">
        <div class="setting-group">
          <h4 class="text-md font-medium text-gray-700 mb-2">Voice Control</h4>
          
          <div class="setting-item">
            <label class="flex items-center cursor-pointer">
              <div class="relative">
                <input type="checkbox" id="voice-activation-toggle" class="sr-only">
                <div class="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full"></div>
                <div class="dot absolute left-0 top-0 bg-white w-6 h-6 rounded-full transition"></div>
              </div>
              <div class="ml-3 text-gray-700 font-medium">Voice Activation</div>
            </label>
            <p class="text-xs text-gray-500 mt-1">Enable voice commands (say "Hey Learnfy" to activate)</p>
          </div>
          
          <div class="voice-status-container flex items-center mt-3 mb-3" style="display: none;">
            <div id="voice-indicator" class="voice-indicator"></div>
            <span id="voice-status-text" class="text-sm ml-2">Voice recognition inactive</span>
          </div>
          
          <div class="setting-item mt-4">
            <label class="flex items-center cursor-pointer">
              <div class="relative">
                <input type="checkbox" id="text-to-speech-toggle" class="sr-only">
                <div class="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full"></div>
                <div class="dot absolute left-0 top-0 bg-white w-6 h-6 rounded-full transition"></div>
              </div>
              <div class="ml-3 text-gray-700 font-medium">Text to Speech</div>
            </label>
            <p class="text-xs text-gray-500 mt-1">Read content and feedback aloud</p>
          </div>
          
          <div class="setting-item mt-4">
            <label class="flex items-center cursor-pointer">
              <div class="relative">
                <input type="checkbox" id="command-feedback-toggle" class="sr-only">
                <div class="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full"></div>
                <div class="dot absolute left-0 top-0 bg-white w-6 h-6 rounded-full transition"></div>
              </div>
              <div class="ml-3 text-gray-700 font-medium">Command Feedback</div>
            </label>
            <p class="text-xs text-gray-500 mt-1">Play sound when command is recognized</p>
          </div>
        </div>
        
        <div class="setting-group mt-6">
          <h4 class="text-md font-medium text-gray-700 mb-2">Voice Settings</h4>
          
          <div class="setting-item">
            <label for="language-select" class="text-sm text-gray-700 block mb-1">Language</label>
            <select id="language-select" class="form-input">
              <option value="en-US">English (US)</option>
              <option value="en-GB">English (UK)</option>
              <option value="es-ES">Spanish</option>
              <option value="fr-FR">French</option>
              <option value="de-DE">German</option>
              <option value="it-IT">Italian</option>
              <option value="ja-JP">Japanese</option>
              <option value="zh-CN">Chinese (Simplified)</option>
              <option value="ru-RU">Russian</option>
            </select>
          </div>
          
          <div class="setting-item mt-4">
            <label for="voice-select" class="text-sm text-gray-700 block mb-1">Voice</label>
            <select id="voice-select" class="form-input">
              <option value="">Default Voice</option>
              <!-- Voice options will be added dynamically -->
            </select>
          </div>
          
          <div class="setting-item mt-4">
            <label for="voice-speed" class="text-sm text-gray-700 block mb-1">Voice Speed: <span id="speed-value">1.0</span>x</label>
            <input type="range" id="voice-speed" min="0.5" max="2" step="0.1" value="1" class="w-full">
          </div>
          
          <div class="setting-item mt-4">
            <label for="voice-pitch" class="text-sm text-gray-700 block mb-1">Voice Pitch: <span id="pitch-value">1.0</span></label>
            <input type="range" id="voice-pitch" min="0.5" max="1.5" step="0.1" value="1" class="w-full">
          </div>
        </div>
        
        <div class="setting-group mt-6">
          <h4 class="text-md font-medium text-gray-700 mb-2">Accessibility Features</h4>
          
          <div class="setting-item">
            <label class="flex items-center cursor-pointer">
              <div class="relative">
                <input type="checkbox" id="accessibility-mode-toggle" class="sr-only">
                <div class="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full"></div>
                <div class="dot absolute left-0 top-0 bg-white w-6 h-6 rounded-full transition"></div>
              </div>
              <div class="ml-3 text-gray-700 font-medium">High Contrast Mode</div>
            </label>
            <p class="text-xs text-gray-500 mt-1">Enhance visual contrast for better readability</p>
          </div>
          
          <div class="mt-4">
            <button id="test-voice" class="secondary-button w-full">
              <span class="material-icons mr-1 text-sm">record_voice_over</span>
              Test Voice
            </button>
          </div>
        </div>
      </div>
    `;
    
    // Add custom styles for the panel
    this.addStyles();
    
    // Append panel to body when DOM is ready
    if (document.body) {
      document.body.appendChild(this.panel);
      this.bindEvents();
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        document.body.appendChild(this.panel);
        this.bindEvents();
      });
    }
    
    // Add accessibility button to the interface
    this.addAccessibilityButton();
  }

  /**
   * Add custom styles for the accessibility panel
   */
  addStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .accessibility-panel {
        position: fixed;
        top: 70px;
        right: 20px;
        width: 320px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        z-index: 9999;
        max-height: 80vh;
        overflow-y: auto;
        font-family: 'Inter', sans-serif;
      }
      
      .panel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px;
        border-bottom: 1px solid #e5e7eb;
      }
      
      .panel-body {
        padding: 16px;
      }
      
      .setting-group {
        margin-bottom: 20px;
      }
      
      .setting-item {
        margin-bottom: 12px;
      }
      
      .close-btn {
        background: none;
        border: none;
        cursor: pointer;
        color: #6b7280;
      }
      
      .close-btn:hover {
        color: #374151;
      }
      
      /* Toggle switch styles */
      .toggle-bg {
        transition: background-color 0.2s;
      }
      
      .dot {
        transition: transform 0.2s;
      }
      
      input:checked ~ .toggle-bg {
        background-color: #4f46e5;
        border-color: #4f46e5;
      }
      
      input:checked ~ .toggle-bg + .dot {
        transform: translateX(100%);
      }
      
      /* Voice indicator styles */
      .voice-indicator {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: #ef4444;
      }
      
      .voice-indicator.active {
        background-color: #10b981;
        box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        animation: pulse 1.5s infinite;
      }
      
      @keyframes pulse {
        0% {
          box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
        }
        70% {
          box-shadow: 0 0 0 6px rgba(16, 185, 129, 0);
        }
        100% {
          box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
        }
      }
      
      /* Accessibility button */
      .accessibility-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: #4f46e5;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        z-index: 999;
        transition: background-color 0.2s;
      }
      
      .accessibility-btn:hover {
        background: #4338ca;
      }
      
      .accessibility-btn.active {
        background: #10b981;
      }
      
      /* High contrast mode styles */
      .high-contrast {
        filter: contrast(1.4);
      }
      
      .high-contrast .accessibility-panel {
        filter: contrast(0.9);
      }
    `;
    
    document.head.appendChild(style);
  }

  /**
   * Add accessibility button to the interface
   */
  addAccessibilityButton() {
    const button = document.createElement('div');
    button.className = 'accessibility-btn';
    button.id = 'accessibility-btn';
    button.innerHTML = '<span class="material-icons">accessibility_new</span>';
    button.title = 'Accessibility Settings';
    
    // Add button to body when DOM is ready
    if (document.body) {
      document.body.appendChild(button);
      button.addEventListener('click', () => this.toggle());
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        document.body.appendChild(button);
        button.addEventListener('click', () => this.toggle());
      });
    }
  }

  /**
   * Bind event listeners
   */
  bindEvents() {
    // Close button
    const closeBtn = document.getElementById('close-a11y-panel');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.close());
    }
    
    // Voice activation toggle
    const voiceToggle = document.getElementById('voice-activation-toggle');
    if (voiceToggle) {
      voiceToggle.checked = this.voiceControl.settings.voiceActivation;
      voiceToggle.addEventListener('change', (e) => {
        const isEnabled = e.target.checked;
        this.voiceControl.updateSettings({ voiceActivation: isEnabled });
        
        if (isEnabled) {
          this.voiceControl.activate();
          document.querySelector('.voice-status-container').style.display = 'flex';
        } else {
          this.voiceControl.deactivate();
          document.querySelector('.voice-status-container').style.display = 'none';
        }
      });
    }
    
    // Text to speech toggle
    const ttsToggle = document.getElementById('text-to-speech-toggle');
    if (ttsToggle) {
      ttsToggle.checked = this.voiceControl.settings.textToSpeech;
      ttsToggle.addEventListener('change', (e) => {
        this.voiceControl.updateSettings({ textToSpeech: e.target.checked });
      });
    }
    
    // Command feedback toggle
    const feedbackToggle = document.getElementById('command-feedback-toggle');
    if (feedbackToggle) {
      feedbackToggle.checked = this.voiceControl.settings.commandFeedback;
      feedbackToggle.addEventListener('change', (e) => {
        this.voiceControl.updateSettings({ commandFeedback: e.target.checked });
      });
    }
    
    // Language select
    const languageSelect = document.getElementById('language-select');
    if (languageSelect) {
      languageSelect.value = this.voiceControl.settings.language;
      languageSelect.addEventListener('change', (e) => {
        this.voiceControl.updateSettings({ language: e.target.value });
        this.updateVoiceList();
      });
    }
    
    // Voice select
    const voiceSelect = document.getElementById('voice-select');
    if (voiceSelect) {
      this.updateVoiceList();
      voiceSelect.addEventListener('change', (e) => {
        this.voiceControl.updateSettings({ preferredVoice: e.target.value });
      });
    }
    
    // Voice speed slider
    const speedSlider = document.getElementById('voice-speed');
    const speedValue = document.getElementById('speed-value');
    if (speedSlider && speedValue) {
      speedSlider.value = this.voiceControl.settings.voiceSpeed;
      speedValue.textContent = this.voiceControl.settings.voiceSpeed.toFixed(1);
      
      speedSlider.addEventListener('input', (e) => {
        const speed = parseFloat(e.target.value);
        speedValue.textContent = speed.toFixed(1);
        this.voiceControl.updateSettings({ voiceSpeed: speed });
      });
    }
    
    // Voice pitch slider
    const pitchSlider = document.getElementById('voice-pitch');
    const pitchValue = document.getElementById('pitch-value');
    if (pitchSlider && pitchValue) {
      pitchSlider.value = this.voiceControl.settings.voicePitch;
      pitchValue.textContent = this.voiceControl.settings.voicePitch.toFixed(1);
      
      pitchSlider.addEventListener('input', (e) => {
        const pitch = parseFloat(e.target.value);
        pitchValue.textContent = pitch.toFixed(1);
        this.voiceControl.updateSettings({ voicePitch: pitch });
      });
    }
    
    // Accessibility mode toggle
    const a11yToggle = document.getElementById('accessibility-mode-toggle');
    if (a11yToggle) {
      a11yToggle.checked = this.voiceControl.settings.accessibilityMode;
      a11yToggle.addEventListener('change', (e) => {
        const isEnabled = e.target.checked;
        this.voiceControl.updateSettings({ accessibilityMode: isEnabled });
        
        if (isEnabled) {
          document.body.classList.add('high-contrast');
        } else {
          document.body.classList.remove('high-contrast');
        }
      });
      
      // Apply high contrast mode if enabled
      if (this.voiceControl.settings.accessibilityMode) {
        document.body.classList.add('high-contrast');
      }
    }
    
    // Test voice button
    const testVoiceBtn = document.getElementById('test-voice');
    if (testVoiceBtn) {
      testVoiceBtn.addEventListener('click', () => {
        this.voiceControl.speak('This is a test of the Learnfy voice system. Your current settings are working correctly.');
      });
    }
    
    // Show voice status if voice is activated
    if (this.voiceControl.settings.voiceActivation) {
      document.querySelector('.voice-status-container').style.display = 'flex';
    }
  }

  /**
   * Update the list of available voices in the settings panel
   */
  updateVoiceList() {
    const voiceSelect = document.getElementById('voice-select');
    const currentLang = this.voiceControl.settings.language;
    
    if (!voiceSelect || !this.voices.length) return;
    
    // Clear current options except default
    while (voiceSelect.options.length > 1) {
      voiceSelect.remove(1);
    }
    
    // Filter voices by current language
    const langVoices = this.voices.filter(voice => voice.lang.startsWith(currentLang.split('-')[0]));
    
    // Add filtered voices as options
    langVoices.forEach(voice => {
      const option = document.createElement('option');
      option.value = voice.name;
      option.textContent = `${voice.name} (${voice.lang})`;
      voiceSelect.appendChild(option);
    });
    
    // Set selected voice if there's a preferred one
    if (this.voiceControl.settings.preferredVoice) {
      voiceSelect.value = this.voiceControl.settings.preferredVoice;
    }
  }

  /**
   * Update the voice status indicator
   */
  updateVoiceStatus(isListening) {
    const indicator = document.getElementById('voice-indicator');
    const statusText = document.getElementById('voice-status-text');
    
    if (!indicator || !statusText) return;
    
    if (isListening) {
      indicator.classList.add('active');
      statusText.textContent = 'Voice recognition active';
    } else {
      indicator.classList.remove('active');
      statusText.textContent = 'Voice recognition inactive';
    }
    
    // Also update the accessibility button
    const accessibilityBtn = document.getElementById('accessibility-btn');
    if (accessibilityBtn) {
      if (isListening) {
        accessibilityBtn.classList.add('active');
      } else {
        accessibilityBtn.classList.remove('active');
      }
    }
  }

  /**
   * Register voice commands for the accessibility panel
   */
  registerVoiceCommands() {
    // Open accessibility panel
    this.voiceControl.registerCommand('(open|show) accessibility', () => {
      this.open();
    });
    
    // Close accessibility panel
    this.voiceControl.registerCommand('(close|hide) accessibility', () => {
      this.close();
    });
    
    // Toggle voice activation
    this.voiceControl.registerCommand('(enable|disable|toggle) voice', () => {
      const voiceToggle = document.getElementById('voice-activation-toggle');
      if (voiceToggle) {
        voiceToggle.checked = !voiceToggle.checked;
        voiceToggle.dispatchEvent(new Event('change'));
      }
    });
    
    // Toggle high contrast mode
    this.voiceControl.registerCommand('(enable|disable|toggle) (high contrast|contrast mode)', () => {
      const contrastToggle = document.getElementById('accessibility-mode-toggle');
      if (contrastToggle) {
        contrastToggle.checked = !contrastToggle.checked;
        contrastToggle.dispatchEvent(new Event('change'));
      }
    });
    
    // Test voice
    this.voiceControl.registerCommand('test (voice|speech)', () => {
      this.voiceControl.speak('This is a test of the Learnfy voice system. Your current settings are working correctly.');
    });
  }

  /**
   * Open the accessibility panel
   */
  open() {
    if (!this.panel) return;
    
    this.panel.style.display = 'block';
    this.isOpen = true;
  }

  /**
   * Close the accessibility panel
   */
  close() {
    if (!this.panel) return;
    
    this.panel.style.display = 'none';
    this.isOpen = false;
  }

  /**
   * Toggle the accessibility panel
   */
  toggle() {
    if (this.isOpen) {
      this.close();
    } else {
      this.open();
    }
  }
}

// Export the panel
// Note: Will be initialized after voiceControl service is loaded