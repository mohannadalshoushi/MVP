// LearnTrack AI Extension Popup Script
// Handles the popup UI and interactions

// State management
let currentState = {
  isLoggedIn: false,
  isTracking: false,
  currentContent: null,
  categories: [],
  currentCategoryId: null,
  startTime: null,
  timeElapsed: 0,
  quizQuestions: [],
  quizAnswers: [],
  activeTab: null
};

// Elements
const loadingContainer = document.getElementById('loading-container');
const trackingContainer = document.getElementById('tracking-container');
const notTrackingContainer = document.getElementById('not-tracking-container');
const quizContainer = document.getElementById('quiz-container');
const loginContainer = document.getElementById('login-container');

const contentTitleEl = document.getElementById('content-title');
const contentSourceEl = document.getElementById('content-source');
const contentIconEl = document.getElementById('content-icon');
const timeElapsedEl = document.getElementById('time-elapsed');
const categoryTagEl = document.getElementById('category-tag');
const categoryListEl = document.getElementById('category-list');
const changeCategoryBtn = document.getElementById('change-category-btn');
const toggleTrackingBtn = document.getElementById('toggle-tracking-btn');
const addNoteBtn = document.getElementById('add-note-btn');
const skipQuizBtn = document.getElementById('skip-quiz-btn');
const submitQuizBtn = document.getElementById('submit-quiz-btn');
const quizSubtitleEl = document.getElementById('quiz-subtitle');
const quizQuestionsEl = document.getElementById('quiz-questions');
const loginBtn = document.getElementById('login-btn');
const signupBtn = document.getElementById('signup-btn');
const dashboardBtn = document.getElementById('dashboard-btn');

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Check login status
    const userData = await chrome.storage.local.get(['user']);
    if (userData.user) {
      currentState.isLoggedIn = true;
      // Load categories
      await loadCategories();
      // Get current tab
      await getCurrentTab();
      // Check tracking status
      await checkTrackingStatus();
    } else {
      // Show login screen
      showLoginScreen();
    }
  } catch (error) {
    console.error('Initialization error:', error);
    showError('Failed to initialize popup');
  }
});

// Load categories from API
async function loadCategories() {
  try {
    const response = await fetch('http://localhost:5000/api/categories');
    if (!response.ok) {
      throw new Error('Failed to load categories');
    }
    
    currentState.categories = await response.json();
  } catch (error) {
    console.error('Error loading categories:', error);
    currentState.categories = [
      { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
      { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
      { id: 3, name: "Design", icon: "brush", color: "#10B981" },
      { id: 4, name: "Sales", icon: "sell", color: "#EF4444" },
      { id: 5, name: "Data Science", icon: "analytics", color: "#F59E0B" }
    ];
  }
}

// Get the active tab
async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length > 0) {
    currentState.activeTab = tabs[0];
  }
}

// Check if the extension is tracking the current page
async function checkTrackingStatus() {
  showLoading();
  
  try {
    const response = await chrome.runtime.sendMessage({ action: "getTrackingStatus" });
    
    if (response.isTracking && response.content) {
      currentState.isTracking = true;
      currentState.currentContent = response.content;
      currentState.currentCategoryId = response.content.categoryId || findDefaultCategoryId(response.content.url);
      currentState.startTime = response.content.startTime;
      currentState.timeElapsed = response.content.timeSpent || 0;
      
      // Update UI with tracking information
      updateTrackingUI();
      showTrackingUI();
    } else {
      currentState.isTracking = false;
      showNotTrackingUI();
    }
  } catch (error) {
    console.error('Error checking tracking status:', error);
    showNotTrackingUI();
  }
}

// Find a default category ID based on the URL
function findDefaultCategoryId(url) {
  // Simple logic to guess category from URL
  const urlLower = url.toLowerCase();
  
  if (urlLower.includes('dev.to') || urlLower.includes('github.com') || 
      urlLower.includes('stackoverflow.com') || urlLower.includes('code')) {
    return findCategoryIdByName('Web Development');
  } else if (urlLower.includes('design') || urlLower.includes('ux') || urlLower.includes('ui')) {
    return findCategoryIdByName('Design');
  } else if (urlLower.includes('marketing') || urlLower.includes('seo') || urlLower.includes('content')) {
    return findCategoryIdByName('Marketing');
  } else if (urlLower.includes('sales') || urlLower.includes('customer') || urlLower.includes('lead')) {
    return findCategoryIdByName('Sales');
  } else if (urlLower.includes('data') || urlLower.includes('analytics') || urlLower.includes('ml')) {
    return findCategoryIdByName('Data Science');
  }
  
  // Default to the first category
  return currentState.categories.length > 0 ? currentState.categories[0].id : 1;
}

// Find category ID by name
function findCategoryIdByName(name) {
  const category = currentState.categories.find(cat => cat.name.toLowerCase() === name.toLowerCase());
  return category ? category.id : 1;
}

// Find category by ID
function findCategoryById(id) {
  return currentState.categories.find(cat => cat.id === id) || currentState.categories[0];
}

// Update tracking UI with current content information
function updateTrackingUI() {
  if (!currentState.currentContent) return;
  
  // Update content information
  contentTitleEl.textContent = currentState.currentContent.title || 'Unknown Content';
  contentSourceEl.textContent = `${currentState.currentContent.source || 'unknown'} • ${formatTime(currentState.timeElapsed)} elapsed`;
  
  // Set content type icon
  if (currentState.currentContent.contentType === 'video') {
    contentIconEl.textContent = 'play_circle';
    contentIconEl.classList.add('video-icon');
  } else {
    contentIconEl.textContent = 'article';
    contentIconEl.classList.remove('video-icon');
  }
  
  // Update category information
  const category = findCategoryById(currentState.currentCategoryId);
  updateCategoryTag(category);
  
  // Start updating elapsed time
  startTimeUpdater();
}

// Update the category tag display
function updateCategoryTag(category) {
  categoryTagEl.textContent = category.name;
  categoryTagEl.style.backgroundColor = `${hexToRGBA(category.color, 0.1)}`;
  categoryTagEl.style.color = category.color;
}

// Convert hex color to rgba
function hexToRGBA(hex, alpha = 1) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// Format seconds into MM:SS
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Start updating the elapsed time counter
function startTimeUpdater() {
  // Clear any existing interval
  stopTimeUpdater();
  
  // Set up interval to update time elapsed
  window.timeUpdateInterval = setInterval(() => {
    currentState.timeElapsed++;
    timeElapsedEl.textContent = formatTime(currentState.timeElapsed);
  }, 1000);
}

// Stop updating the elapsed time counter
function stopTimeUpdater() {
  if (window.timeUpdateInterval) {
    clearInterval(window.timeUpdateInterval);
    window.timeUpdateInterval = null;
  }
}

// Show loading UI
function showLoading() {
  loadingContainer.style.display = 'block';
  trackingContainer.style.display = 'none';
  notTrackingContainer.style.display = 'none';
  quizContainer.style.display = 'none';
  loginContainer.style.display = 'none';
}

// Show tracking UI
function showTrackingUI() {
  loadingContainer.style.display = 'none';
  trackingContainer.style.display = 'block';
  notTrackingContainer.style.display = 'none';
  quizContainer.style.display = 'none';
  loginContainer.style.display = 'none';
}

// Show not tracking UI
function showNotTrackingUI() {
  loadingContainer.style.display = 'none';
  trackingContainer.style.display = 'none';
  notTrackingContainer.style.display = 'block';
  quizContainer.style.display = 'none';
  loginContainer.style.display = 'none';
  stopTimeUpdater();
}

// Show quiz UI
function showQuizUI() {
  loadingContainer.style.display = 'none';
  trackingContainer.style.display = 'none';
  notTrackingContainer.style.display = 'none';
  quizContainer.style.display = 'block';
  loginContainer.style.display = 'none';
  stopTimeUpdater();
}

// Show login screen
function showLoginScreen() {
  loadingContainer.style.display = 'none';
  trackingContainer.style.display = 'none';
  notTrackingContainer.style.display = 'none';
  quizContainer.style.display = 'none';
  loginContainer.style.display = 'block';
  stopTimeUpdater();
}

// Show error message
function showError(message) {
  loadingContainer.style.display = 'none';
  
  const errorContainer = document.createElement('div');
  errorContainer.style.padding = '20px';
  errorContainer.style.textAlign = 'center';
  errorContainer.style.color = '#EF4444';
  
  const errorIcon = document.createElement('span');
  errorIcon.className = 'material-icons';
  errorIcon.textContent = 'error';
  errorIcon.style.fontSize = '32px';
  errorIcon.style.marginBottom = '8px';
  
  const errorText = document.createElement('p');
  errorText.textContent = message;
  
  errorContainer.appendChild(errorIcon);
  errorContainer.appendChild(errorText);
  
  document.body.appendChild(errorContainer);
}

// Toggle category selection list
changeCategoryBtn.addEventListener('click', () => {
  // Toggle category list visibility
  const categoryList = document.getElementById('category-list');
  categoryList.classList.toggle('visible');
  
  // Populate category list if not already done
  if (categoryList.children.length === 0) {
    currentState.categories.forEach(category => {
      const option = document.createElement('div');
      option.className = 'category-option';
      option.dataset.categoryId = category.id;
      
      const icon = document.createElement('span');
      icon.className = 'material-icons';
      icon.textContent = category.icon;
      icon.style.color = category.color;
      
      const name = document.createElement('span');
      name.textContent = category.name;
      
      option.appendChild(icon);
      option.appendChild(name);
      
      // Add click event to select this category
      option.addEventListener('click', () => {
        selectCategory(category.id);
        categoryList.classList.remove('visible');
      });
      
      categoryList.appendChild(option);
    });
  }
});

// Select a category
async function selectCategory(categoryId) {
  currentState.currentCategoryId = categoryId;
  const category = findCategoryById(categoryId);
  updateCategoryTag(category);
  
  // Send message to background script to update category
  try {
    await chrome.runtime.sendMessage({ 
      action: "setCategory", 
      categoryId: categoryId 
    });
  } catch (error) {
    console.error('Error setting category:', error);
  }
}

// Toggle tracking
toggleTrackingBtn.addEventListener('click', async () => {
  const newTrackingState = !currentState.isTracking;
  
  try {
    await chrome.runtime.sendMessage({ 
      action: "toggleTracking", 
      value: newTrackingState 
    });
    
    currentState.isTracking = newTrackingState;
    
    if (newTrackingState) {
      toggleTrackingBtn.textContent = 'Pause Tracking';
      // Re-check tracking status to get latest content
      await checkTrackingStatus();
    } else {
      toggleTrackingBtn.textContent = 'Resume Tracking';
      stopTimeUpdater();
    }
  } catch (error) {
    console.error('Error toggling tracking:', error);
  }
});

// Add note functionality
addNoteBtn.addEventListener('click', () => {
  // Open a note taking dialog in a future version
  alert('Note taking feature will be available in the next version!');
});

// Setup quiz
async function setupQuiz(contentTitle, activityId) {
  // Update quiz title
  quizSubtitleEl.textContent = `Let's check what you've learned from "${contentTitle}"`;
  
  // Clear previous questions
  quizQuestionsEl.innerHTML = '';
  currentState.quizAnswers = [];
  
  try {
    // Get content from current tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    
    // Extract content if needed
    const contentResponse = await chrome.tabs.sendMessage(tab.id, { action: 'getPageContent' });
    
    // Generate quiz questions
    const response = await fetch('http://localhost:5000/api/generate-quiz', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        activityId: activityId || 1,
        content: contentResponse.content || contentTitle,
        numQuestions: 3
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to generate quiz');
    }
    
    const quizData = await response.json();
    currentState.quizQuestions = quizData.questions;
    currentState.quizAnswers = new Array(quizData.questions.length).fill(-1);
    
    // Build quiz UI
    quizData.questions.forEach((question, index) => {
      const questionDiv = document.createElement('div');
      questionDiv.className = 'quiz-question';
      
      const questionText = document.createElement('div');
      questionText.className = 'question-text';
      questionText.textContent = `${index + 1}. ${question.question}`;
      
      questionDiv.appendChild(questionText);
      
      // Add options
      question.options.forEach((option, optionIndex) => {
        const optionDiv = document.createElement('label');
        optionDiv.className = 'quiz-option';
        
        const radioButton = document.createElement('input');
        radioButton.type = 'radio';
        radioButton.name = `question-${index}`;
        radioButton.value = optionIndex;
        
        radioButton.addEventListener('change', () => {
          // Update answers array
          currentState.quizAnswers[index] = optionIndex;
          
          // Enable submit button if at least one question is answered
          if (currentState.quizAnswers.some(answer => answer !== -1)) {
            submitQuizBtn.disabled = false;
          }
        });
        
        const optionText = document.createElement('span');
        optionText.textContent = option;
        
        optionDiv.appendChild(radioButton);
        optionDiv.appendChild(optionText);
        questionDiv.appendChild(optionDiv);
      });
      
      quizQuestionsEl.appendChild(questionDiv);
    });
    
    showQuizUI();
  } catch (error) {
    console.error('Error setting up quiz:', error);
    showError('Failed to generate quiz. Please try again.');
  }
}

// Skip quiz
skipQuizBtn.addEventListener('click', () => {
  showTrackingUI();
});

// Submit quiz
submitQuizBtn.addEventListener('click', async () => {
  if (currentState.quizQuestions.length === 0) return;
  
  try {
    submitQuizBtn.disabled = true;
    submitQuizBtn.textContent = 'Submitting...';
    
    // Get question IDs
    const questionIds = currentState.quizQuestions.map(q => q.id);
    
    // Submit answers
    const response = await fetch('http://localhost:5000/api/evaluate-quiz', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        questionIds: questionIds,
        userAnswers: currentState.quizAnswers,
        activityId: currentState.currentContent?.id || 1
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to evaluate quiz');
    }
    
    const result = await response.json();
    
    // Show result
    alert(`Quiz completed! Your score: ${result.score}%`);
    
    // Go back to tracking view
    showTrackingUI();
  } catch (error) {
    console.error('Error submitting quiz:', error);
    alert('Failed to submit quiz. Please try again.');
    submitQuizBtn.disabled = false;
    submitQuizBtn.textContent = 'Submit Quiz';
  }
});

// Open login page
loginBtn.addEventListener('click', () => {
  // Open the proper login page in the extension folder
  chrome.tabs.create({ url: chrome.runtime.getURL('extension/login.html') });
});

// Open signup page
signupBtn.addEventListener('click', () => {
  // Open the signup page in the extension folder
  chrome.tabs.create({ url: chrome.runtime.getURL('extension/signup.html') });
});

// Open dashboard
dashboardBtn.addEventListener('click', () => {
  // Open the main web application dashboard
  chrome.tabs.create({ url: 'http://localhost:5000' });
});

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle showing quiz
  if (message.action === 'showQuiz' && message.contentTitle) {
    setupQuiz(message.contentTitle, message.contentId);
  }
  
  // Handle content analyzed
  if (message.action === 'contentAnalyzed' && message.category) {
    const category = message.category;
    currentState.currentCategoryId = category.id;
    updateCategoryTag(category);
  }
  
  // Handle tracking updates
  if (message.action === 'updateTracking') {
    currentState.isTracking = message.isTracking;
    
    if (message.isTracking && message.content) {
      currentState.currentContent = message.content;
      updateTrackingUI();
      showTrackingUI();
    } else {
      showNotTrackingUI();
    }
  }
  
  return true;
});

// Close button handler
document.querySelector('.close-btn').addEventListener('click', () => {
  window.close();
});

// Handle visibility changes
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    stopTimeUpdater();
  } else if (currentState.isTracking) {
    startTimeUpdater();
  }
});
