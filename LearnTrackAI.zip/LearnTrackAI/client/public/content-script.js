// Content script for LearnTrack AI Chrome Extension
// Handles extracting content from web pages and tracking user interaction

// Track if the script has already run on this page
let hasExtractedContent = false;
let pageContent = '';
let isTracking = true;
let startTime = Date.now();
let idleTimeout = null;
let lastActivity = Date.now();
const IDLE_THRESHOLD = 60000; // 60 seconds of inactivity

// Set up listeners for user activity to track engagement
function setupActivityTracking() {
  // Track scrolling, mouse movement, clicks, and keypresses
  window.addEventListener('scroll', updateActivity, { passive: true });
  window.addEventListener('mousemove', updateActivity, { passive: true });
  window.addEventListener('click', updateActivity, { passive: true });
  window.addEventListener('keydown', updateActivity, { passive: true });
  
  // Check for visibility changes (tab switching, window minimizing)
  document.addEventListener('visibilitychange', handleVisibilityChange);
  
  // Start idle detection
  resetIdleTimer();
}

// Update last activity timestamp
function updateActivity() {
  lastActivity = Date.now();
  resetIdleTimer();
}

// Reset the idle detection timer
function resetIdleTimer() {
  if (idleTimeout) {
    clearTimeout(idleTimeout);
  }
  
  idleTimeout = setTimeout(() => {
    // User is considered idle if no activity for IDLE_THRESHOLD milliseconds
    if (Date.now() - lastActivity >= IDLE_THRESHOLD) {
      // Notify background script that user is idle
      chrome.runtime.sendMessage({ action: 'userIdle' });
    }
  }, IDLE_THRESHOLD);
}

// Handle visibility changes (tab switching)
function handleVisibilityChange() {
  if (document.hidden) {
    // Page is hidden (user switched tabs or minimized)
    chrome.runtime.sendMessage({ action: 'pageHidden' });
  } else {
    // Page is visible again
    chrome.runtime.sendMessage({ action: 'pageVisible' });
    updateActivity();
  }
}

// Extract main content from the page
function extractContent() {
  if (hasExtractedContent) return;
  
  try {
    // For articles: Get the main content
    if (isArticle()) {
      pageContent = extractArticleContent();
    } 
    // For YouTube videos: Get the title, description, and transcript if available
    else if (isYouTubeVideo()) {
      pageContent = extractYouTubeContent();
    }
    // For other pages: extract what we can
    else {
      pageContent = extractGenericContent();
    }
    
    // Detect the language of the content
    const detectedLanguage = detectContentLanguage(pageContent);
    
    // Send the extracted content to the background script
    if (pageContent && pageContent.length > 100) {
      chrome.runtime.sendMessage({
        action: 'contentExtracted',
        content: pageContent,
        language: detectedLanguage
      });
      hasExtractedContent = true;
    }
  } catch (error) {
    console.error('Error extracting content:', error);
  }
}

// Determine if current page is an article
function isArticle() {
  // Look for common article indicators
  const hasArticleTag = document.querySelector('article') !== null;
  const hasContentClass = document.querySelector('.content, .post, .article, .entry, .blog-post') !== null;
  const hasHeaderAndParagraphs = document.querySelector('h1, h2') !== null && document.querySelectorAll('p').length > 5;
  
  return hasArticleTag || hasContentClass || hasHeaderAndParagraphs;
}

// Determine if current page is a YouTube video
function isYouTubeVideo() {
  return window.location.hostname.includes('youtube.com') && window.location.pathname.includes('watch');
}

// Extract content from an article page
function extractArticleContent() {
  let content = '';
  
  // Try to find the main article element
  const articleElement = document.querySelector('article') || 
                         document.querySelector('.content, .post, .article, .entry, .blog-post');
  
  if (articleElement) {
    // Get the title
    const titleElement = articleElement.querySelector('h1') || document.querySelector('h1');
    if (titleElement) {
      content += titleElement.textContent.trim() + '\n\n';
    }
    
    // Get paragraphs from the article
    const paragraphs = articleElement.querySelectorAll('p');
    paragraphs.forEach(p => {
      content += p.textContent.trim() + '\n\n';
    });
  } else {
    // Fallback: try to find the main content
    const title = document.querySelector('h1');
    if (title) {
      content += title.textContent.trim() + '\n\n';
    }
    
    // Get all paragraphs that seem to be part of the main content
    const paragraphs = Array.from(document.querySelectorAll('p'))
      .filter(p => {
        const text = p.textContent.trim();
        return text.length > 40 && text.includes(' ');
      });
    
    paragraphs.forEach(p => {
      content += p.textContent.trim() + '\n\n';
    });
  }
  
  return content.trim();
}

// Extract content from a YouTube video page
function extractYouTubeContent() {
  let content = '';
  
  // Get the video title
  const titleElement = document.querySelector('h1.title');
  if (titleElement) {
    content += titleElement.textContent.trim() + '\n\n';
  }
  
  // Get the video description
  const descriptionElement = document.querySelector('#description-text');
  if (descriptionElement) {
    content += 'Description: ' + descriptionElement.textContent.trim() + '\n\n';
  }
  
  // For transcript, we'd ideally access it through the UI
  // but this is difficult without user interaction
  // The extension background script will handle this with the YouTube API if needed
  
  return content.trim();
}

// Extract content from a generic page
function extractGenericContent() {
  let content = '';
  
  // Get the page title
  const title = document.title;
  content += title + '\n\n';
  
  // Get headings and their content
  const headings = document.querySelectorAll('h1, h2, h3');
  headings.forEach(heading => {
    content += heading.textContent.trim() + '\n';
    
    // Get paragraphs that follow this heading until the next heading
    let element = heading.nextElementSibling;
    while (element && !['H1', 'H2', 'H3'].includes(element.tagName)) {
      if (element.tagName === 'P' && element.textContent.trim().length > 20) {
        content += element.textContent.trim() + '\n\n';
      }
      element = element.nextElementSibling;
      if (!element) break;
    }
  });
  
  // If we still don't have much content, get all substantial paragraphs
  if (content.length < 200) {
    const paragraphs = Array.from(document.querySelectorAll('p'))
      .filter(p => p.textContent.trim().length > 40);
    
    if (paragraphs.length > 0) {
      content += paragraphs.map(p => p.textContent.trim()).join('\n\n');
    }
  }
  
  return content.trim();
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'extractContent') {
    extractContent();
    sendResponse({ success: true });
  } else if (message.action === 'getPageContent') {
    sendResponse({ content: pageContent, hasContent: hasExtractedContent });
  }
  return true;
});

// Initialize content script
(function init() {
  // Set up activity tracking
  setupActivityTracking();
  
  // Wait for page to fully load before extracting content
  if (document.readyState === 'complete') {
    setTimeout(extractContent, 1000); // Slight delay to ensure dynamic content is loaded
  } else {
    window.addEventListener('load', () => {
      setTimeout(extractContent, 1000);
    });
  }
})();

// Detect the language of content based on text analysis
function detectContentLanguage(text) {
  // Default to English
  let detectedLanguage = 'english';
  
  if (!text || text.length < 20) return detectedLanguage;
  
  // Simple language detection based on common words and patterns
  // This is a basic implementation - for production, consider using a language detection library
  
  // Get a sample of the text for analysis (first 1000 characters)
  const sample = text.toLowerCase().substring(0, 1000);
  
  // Language patterns (common words/characters)
  const languages = {
    english: ['the', 'and', 'is', 'in', 'to', 'for', 'that', 'with'],
    spanish: ['el', 'la', 'los', 'las', 'de', 'en', 'que', 'por', 'con'],
    french: ['le', 'la', 'les', 'un', 'une', 'des', 'et', 'est', 'en', 'dans'],
    german: ['der', 'die', 'das', 'und', 'ist', 'für', 'mit', 'auf', 'sind'],
    italian: ['il', 'la', 'i', 'e', 'ed', 'un', 'che', 'per', 'con'],
    portuguese: ['o', 'a', 'os', 'as', 'um', 'uma', 'e', 'é', 'em', 'de'],
    chinese: ['的', '是', '了', '在', '和', '有', '我', '不', '这', '个'],
    japanese: ['は', 'を', 'に', 'の', 'が', 'で', 'と', 'た', 'から'],
    korean: ['은', '는', '이', '가', '을', '를', '에', '의', '로', '고']
  };
  
  // Calculate scores for each language
  const scores = {};
  for (const [language, words] of Object.entries(languages)) {
    // For character-based languages, check for character presence
    if (['chinese', 'japanese', 'korean'].includes(language)) {
      scores[language] = words.filter(char => sample.includes(char)).length;
    } else {
      // For word-based languages, check for word boundaries
      const wordRegexes = words.map(word => new RegExp(`\\b${word}\\b`, 'g'));
      scores[language] = wordRegexes.reduce((sum, regex) => {
        const matches = sample.match(regex);
        return sum + (matches ? matches.length : 0);
      }, 0);
    }
  }
  
  // Find language with highest score
  let maxScore = 0;
  for (const [language, score] of Object.entries(scores)) {
    if (score > maxScore) {
      maxScore = score;
      detectedLanguage = language;
    }
  }
  
  return detectedLanguage;
}

// Handle beforeunload event to capture when user is leaving the page
window.addEventListener('beforeunload', function() {
  // Send a message that the user is about to leave the page
  // This could trigger quiz generation in the background script
  chrome.runtime.sendMessage({ action: 'leavingPage' });
});
