document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const loadingView = document.getElementById('loading-view');
  const dashboardView = document.getElementById('dashboard-view');
  
  // Stats elements
  const learningTimeElement = document.getElementById('learning-time');
  const learningTimeChangeElement = document.getElementById('learning-time-change');
  const articlesReadElement = document.getElementById('articles-read');
  const articlesReadChangeElement = document.getElementById('articles-read-change');
  const videosWatchedElement = document.getElementById('videos-watched');
  const videosWatchedChangeElement = document.getElementById('videos-watched-change');
  const quizAccuracyElement = document.getElementById('quiz-accuracy');
  const quizAccuracyChangeElement = document.getElementById('quiz-accuracy-change');
  
  // Progress elements
  const progressTimeframeSelector = document.getElementById('progress-timeframe');
  const categoriesProgressContainer = document.getElementById('categories-progress');
  
  // Tools elements
  const toolsTimeframeSelector = document.getElementById('tools-timeframe');
  const toolsUsageContainer = document.getElementById('tools-usage');
  
  // Activities elements
  const recentActivitiesContainer = document.getElementById('recent-activities');
  const viewAllActivitiesLink = document.getElementById('view-all-activities');
  
  // Other elements
  const openWebDashboardBtn = document.getElementById('open-web-dashboard');
  
  // State
  let progressTimeframe = '7';
  let toolsTimeframe = '7';
  let userId = null;
  
  // Initialize
  initialize();
  
  async function initialize() {
    // Show loading
    showView(loadingView);
    
    try {
      // Check authentication
      if (!localStorage.getItem('is_authenticated')) {
        window.location.href = './login.html';
        return;
      }
      
      // Get user data
      const userData = JSON.parse(localStorage.getItem('user'));
      if (!userData || !userData.id) {
        throw new Error('User data not found');
      }
      
      userId = userData.id;
      
      // Fetch all data
      await Promise.all([
        fetchDashboardStats(),
        fetchCategoriesProgress(),
        fetchToolsUsage(),
        fetchRecentActivities()
      ]);
      
      // Show dashboard
      showView(dashboardView);
      
    } catch (error) {
      console.error('Failed to initialize dashboard:', error);
      alert('Failed to load dashboard data. Please try again.');
    }
  }
  
  async function fetchDashboardStats() {
    try {
      // Get dashboard stats from API
      const response = await fetch(`/api/dashboard-stats/${userId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard stats');
      }
      
      const stats = await response.json();
      
      // Update UI
      learningTimeElement.textContent = stats.learningTime.total;
      updateChangeElement(learningTimeChangeElement, stats.learningTime.change);
      
      articlesReadElement.textContent = stats.articlesRead.total;
      updateChangeElement(articlesReadChangeElement, stats.articlesRead.change);
      
      videosWatchedElement.textContent = stats.videosWatched.total;
      updateChangeElement(videosWatchedChangeElement, stats.videosWatched.change);
      
      quizAccuracyElement.textContent = stats.quizAccuracy.total;
      updateChangeElement(quizAccuracyChangeElement, stats.quizAccuracy.change);
      
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw error;
    }
  }
  
  async function fetchCategoriesProgress() {
    try {
      // Get categories progress from API
      const response = await fetch(`/api/categories-progress/${userId}?timeframe=${progressTimeframe}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch categories progress');
      }
      
      const categories = await response.json();
      
      // Update UI
      renderCategoriesProgress(categories);
      
    } catch (error) {
      console.error('Error fetching categories progress:', error);
      throw error;
    }
  }
  
  async function fetchToolsUsage() {
    try {
      // Get tools usage from API
      const response = await fetch(`/api/tool-usages/${userId}?timeframe=${toolsTimeframe}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch tools usage');
      }
      
      const toolsUsage = await response.json();
      
      // Update UI
      renderToolsUsage(toolsUsage);
      
    } catch (error) {
      console.error('Error fetching tools usage:', error);
      throw error;
    }
  }
  
  async function fetchRecentActivities() {
    try {
      // Get recent activities from API
      const response = await fetch(`/api/learning-activities/${userId}?limit=5`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch recent activities');
      }
      
      const activities = await response.json();
      
      // Update UI
      renderRecentActivities(activities);
      
    } catch (error) {
      console.error('Error fetching recent activities:', error);
      throw error;
    }
  }
  
  function renderCategoriesProgress(categories) {
    // Create categories progress HTML
    let html = '';
    
    if (categories.length === 0) {
      html = '<p class="text-tertiary text-center py-4">No learning data available for this timeframe</p>';
    } else {
      categories.forEach(category => {
        html += `
          <div class="mb-3">
            <div class="flex-between mb-1">
              <div class="flex-center">
                <div class="category-tag" style="background-color: ${category.color}25; color: ${category.color};">
                  <span class="material-icons mr-1" style="font-size: 1rem;">${category.icon}</span>
                  ${category.name}
                </div>
              </div>
              <div class="text-sm font-medium">${category.hoursSpent}h</div>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${category.percentage}%; background-color: ${category.color};"></div>
            </div>
          </div>
        `;
      });
    }
    
    categoriesProgressContainer.innerHTML = html;
  }
  
  function renderToolsUsage(toolsUsage) {
    // Create tools usage HTML
    let html = '';
    
    if (toolsUsage.length === 0) {
      html = '<p class="text-tertiary text-center py-4">No tool usage data available for this timeframe</p>';
    } else {
      toolsUsage.forEach(tool => {
        html += `
          <div class="mb-3">
            <div class="flex-between mb-1">
              <div class="flex-center">
                <div class="category-tag" style="background-color: ${tool.color}25; color: ${tool.color};">
                  <span class="material-icons mr-1" style="font-size: 1rem;">${tool.icon}</span>
                  ${tool.toolName}
                </div>
              </div>
              <div class="text-sm font-medium">${tool.hoursSpent}h</div>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${tool.percentage}%; background-color: ${tool.color};"></div>
            </div>
          </div>
        `;
      });
    }
    
    toolsUsageContainer.innerHTML = html;
  }
  
  function renderRecentActivities(activities) {
    // Create recent activities HTML
    let html = '';
    
    if (activities.length === 0) {
      html = '<p class="text-tertiary text-center py-4">No recent activities</p>';
    } else {
      activities.forEach(activity => {
        const activityDate = new Date(activity.learningDate);
        const formattedDate = formatDate(activityDate);
        
        html += `
          <div class="activity-item">
            <div class="activity-icon" style="background-color: ${activity.category.color}25; color: ${activity.category.color};">
              <span class="material-icons">${activity.contentType === 'article' ? 'article' : 'play_circle'}</span>
            </div>
            <div class="activity-details">
              <div class="activity-title">${activity.title}</div>
              <div class="activity-meta">
                <span class="badge badge-primary mr-2">${activity.category.name}</span>
                <span>${activity.source}</span>
                ${activity.quizScore ? `<span class="badge badge-success ml-2">Quiz: ${activity.quizScore}%</span>` : ''}
              </div>
            </div>
            <div class="activity-time">
              ${formattedDate}
            </div>
          </div>
        `;
      });
    }
    
    recentActivitiesContainer.innerHTML = html;
  }
  
  function updateChangeElement(element, changeValue) {
    // Parse change value
    const isPositive = !changeValue.startsWith('-');
    
    // Update element
    element.className = `stat-change ${isPositive ? 'positive' : 'negative'}`;
    element.innerHTML = `
      <span class="material-icons">${isPositive ? 'arrow_upward' : 'arrow_downward'}</span>
      <span>${changeValue}</span>
    `;
  }
  
  function formatDate(date) {
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) {
      return 'Just now';
    } else if (diff < 3600) {
      const mins = Math.floor(diff / 60);
      return `${mins} min${mins > 1 ? 's' : ''} ago`;
    } else if (diff < 86400) {
      const hours = Math.floor(diff / 3600);
      return `${hours} hr${hours > 1 ? 's' : ''} ago`;
    } else if (diff < 604800) {
      const days = Math.floor(diff / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }
  
  function showView(viewToShow) {
    // Hide all views
    loadingView.style.display = 'none';
    dashboardView.style.display = 'none';
    
    // Show the requested view
    viewToShow.style.display = 'block';
  }
  
  // Event Listeners
  progressTimeframeSelector.addEventListener('click', async event => {
    const option = event.target.closest('.timeframe-option');
    if (!option) return;
    
    // Update timeframe
    progressTimeframe = option.dataset.value;
    
    // Update UI
    progressTimeframeSelector.querySelectorAll('.timeframe-option').forEach(opt => {
      opt.classList.toggle('active', opt === option);
    });
    
    // Fetch new data
    try {
      await fetchCategoriesProgress();
    } catch (error) {
      console.error('Failed to update categories progress:', error);
    }
  });
  
  toolsTimeframeSelector.addEventListener('click', async event => {
    const option = event.target.closest('.timeframe-option');
    if (!option) return;
    
    // Update timeframe
    toolsTimeframe = option.dataset.value;
    
    // Update UI
    toolsTimeframeSelector.querySelectorAll('.timeframe-option').forEach(opt => {
      opt.classList.toggle('active', opt === option);
    });
    
    // Fetch new data
    try {
      await fetchToolsUsage();
    } catch (error) {
      console.error('Failed to update tools usage:', error);
    }
  });
  
  viewAllActivitiesLink.addEventListener('click', () => {
    // Open full dashboard with activities tab
    window.open('/learning-history', '_blank');
  });
  
  openWebDashboardBtn.addEventListener('click', () => {
    // Open full dashboard
    window.open('/', '_blank');
  });
});