/**
 * Gamification Hooks for Level-Up Animation
 * This file provides the interface between the debug controls and the level-up animation
 */

// Function to create a level-up animation overlay
function createLevelUpAnimation(level) {
  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'level-up-overlay';
  document.body.appendChild(overlay);
  
  // Create stars container
  const starsContainer = document.createElement('div');
  starsContainer.className = 'level-up-stars';
  overlay.appendChild(starsContainer);
  
  // Create confetti container
  const confettiContainer = document.createElement('div');
  confettiContainer.className = 'confetti-container';
  overlay.appendChild(confettiContainer);
  
  // Create main content container
  const container = document.createElement('div');
  container.className = 'level-up-container';
  overlay.appendChild(container);
  
  // Add badge
  const badge = document.createElement('div');
  badge.className = 'level-up-badge';
  container.appendChild(badge);
  
  const badgeInner = document.createElement('div');
  badgeInner.className = 'level-up-badge-inner';
  badge.appendChild(badgeInner);
  
  const badgeIcon = document.createElement('span');
  badgeIcon.className = 'material-icons level-up-badge-icon';
  badgeIcon.textContent = 'military_tech';
  badgeInner.appendChild(badgeIcon);
  
  // Add title
  const title = document.createElement('h2');
  title.className = 'level-up-title';
  title.textContent = 'Level Up!';
  container.appendChild(title);
  
  // Add level info
  const levelInfo = document.createElement('div');
  levelInfo.className = 'level-up-level';
  levelInfo.textContent = level;
  container.appendChild(levelInfo);
  
  // Add message
  const message = document.createElement('p');
  message.className = 'level-up-message';
  message.textContent = `Congratulations! You've reached level ${level}. Keep learning to unlock more achievements and features.`;
  container.appendChild(message);
  
  // Add continue button
  const continueBtn = document.createElement('button');
  continueBtn.className = 'level-up-continue';
  continueBtn.textContent = 'Continue Learning';
  container.appendChild(continueBtn);
  
  // Handle continue button click
  continueBtn.addEventListener('click', () => {
    // Remove the animation with a fade out
    overlay.style.opacity = '0';
    setTimeout(() => {
      document.body.removeChild(overlay);
    }, 300);
  });
  
  // Create stars
  for (let i = 0; i < 20; i++) {
    createStar(starsContainer);
  }
  
  // Create confetti
  for (let i = 0; i < 100; i++) {
    createConfetti(confettiContainer);
  }
  
  // Display animation with a slight delay
  setTimeout(() => {
    overlay.classList.add('visible');
  }, 100);
  
  // Play a sound effect
  const audio = new Audio('https://freesound.org/data/previews/270/270402_5123851-lq.mp3');
  audio.volume = 0.5;
  audio.play().catch(e => console.log('Audio play failed:', e));
}

// Create a single star element
function createStar(container) {
  const star = document.createElement('div');
  star.className = 'star';
  
  // Random position
  const top = Math.random() * 100;
  const left = Math.random() * 100;
  star.style.top = `${top}%`;
  star.style.left = `${left}%`;
  
  // Random size
  const size = 5 + Math.random() * 10;
  star.style.width = `${size}px`;
  star.style.height = `${size}px`;
  
  // Random color
  const colors = ['#ffeb3b', '#ffc107', '#ff9800', '#f44336', '#e91e63'];
  star.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
  
  container.appendChild(star);
  
  // Animate the star
  setTimeout(() => {
    star.style.animation = `starAnimation ${1 + Math.random() * 2}s forwards`;
  }, Math.random() * 1000);
}

// Create a confetti element
function createConfetti(container) {
  const confetti = document.createElement('div');
  confetti.className = 'confetti';
  
  // Random shape
  const shapes = ['square', 'rectangle', 'circle'];
  const shape = shapes[Math.floor(Math.random() * shapes.length)];
  confetti.classList.add(shape);
  
  // Random position
  confetti.style.left = `${Math.random() * 100}%`;
  confetti.style.top = `-10px`;
  
  // Random color
  const colors = [
    '#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5',
    '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50',
    '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800'
  ];
  confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
  
  // Append to container
  container.appendChild(confetti);
  
  // Animate
  confetti.style.animation = `confettiDrop ${3 + Math.random() * 5}s ease-out forwards`;
  
  // Clean up after animation
  setTimeout(() => {
    container.removeChild(confetti);
  }, 8000);
}

// Function to show level up animation (called from debug button)
function showLevelUpAnimation(newLevel) {
  // Use current level + 1 if newLevel not provided
  const level = newLevel || (parseInt(document.getElementById('level-display')?.textContent) + 1 || 2);
  createLevelUpAnimation(level);
}