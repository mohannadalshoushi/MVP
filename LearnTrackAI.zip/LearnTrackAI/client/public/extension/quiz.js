document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const loadingView = document.getElementById('loading-view');
  const quizView = document.getElementById('quiz-view');
  const quizResultsView = document.getElementById('quiz-results-view');
  const quizReviewView = document.getElementById('quiz-review-view');
  
  const contentTitleSpan = document.getElementById('content-title');
  const quizContainer = document.getElementById('quiz-container');
  const quizBackBtn = document.getElementById('quiz-back-btn');
  const quizNextBtn = document.getElementById('quiz-next-btn');
  
  const quizScore = document.getElementById('quiz-score');
  const quizScoreText = document.getElementById('quiz-score-text');
  const viewAnswersBtn = document.getElementById('view-answers-btn');
  const finishQuizBtn = document.getElementById('finish-quiz-btn');
  const pointsEarnedSpan = document.getElementById('points-earned');
  
  const reviewContainer = document.getElementById('review-container');
  const backToResultsBtn = document.getElementById('back-to-results-btn');
  
  const quizProgressIndicator = document.getElementById('quiz-progress-indicator');
  const quizFeedback = document.getElementById('quiz-feedback');
  const streakText = document.querySelector('.quiz-streak-text');
  
  // State
  let activityId = null;
  let questions = [];
  let currentQuestionIndex = 0;
  let userAnswers = [];
  let contentTitle = '';
  let totalXpEarned = 0;
  let streak = 0;
  let lastAnswerCorrect = false;
  let consecutiveCorrect = 0;
  let answeredCurrentQuestion = false;
  
  // Gamification values
  const XP_FOR_COMPLETION = 25;
  const XP_PER_CORRECT = 10;
  const XP_STREAK_BONUS = 5;   // Extra points for correct streak
  
  // Initialize
  initialize();
  
  async function initialize() {
    // Show loading
    showView(loadingView);
    
    try {
      // Get activity ID and content title from query params
      const urlParams = new URLSearchParams(window.location.search);
      activityId = parseInt(urlParams.get('activityId'));
      contentTitle = urlParams.get('title') || 'this content';
      
      if (!activityId) {
        throw new Error('Activity ID is required');
      }
      
      // Update content title
      contentTitleSpan.textContent = contentTitle;
      
      // Try to get user streak from gamification system
      if (window.gamification) {
        streak = window.gamification.getStreak() || 0;
        
        // Update streak display
        if (streak > 0) {
          streakText.textContent = `${streak} day streak! Keep it up!`;
        } else {
          streakText.textContent = 'Start a streak by learning daily!';
        }
      }
      
      // Fetch quiz questions
      await fetchQuizQuestions();
      
      // Update progress indicator
      updateProgressIndicator();
      
      // Show quiz
      showQuizQuestion();
      showView(quizView);
      
    } catch (error) {
      console.error('Failed to initialize quiz:', error);
      alert('Failed to load quiz questions. Please try again.');
    }
  }
  
  async function fetchQuizQuestions() {
    try {
      // Get quiz questions from the API
      const response = await fetch(`/api/quiz-questions/${activityId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch quiz questions');
      }
      
      const data = await response.json();
      questions = data;
      
      // Initialize user answers array with null values
      userAnswers = Array(questions.length).fill(null);
      
    } catch (error) {
      console.error('Error fetching quiz questions:', error);
      throw error;
    }
  }
  
  function updateProgressIndicator() {
    // Clear existing progress items
    quizProgressIndicator.innerHTML = '';
    
    // Create progress items
    for (let i = 0; i < questions.length; i++) {
      const progressItem = document.createElement('div');
      progressItem.className = 'quiz-progress-item';
      
      if (i < currentQuestionIndex) {
        progressItem.classList.add('completed');
      } else if (i === currentQuestionIndex) {
        progressItem.classList.add('current');
      }
      
      quizProgressIndicator.appendChild(progressItem);
    }
  }
  
  function showQuizQuestion() {
    const question = questions[currentQuestionIndex];
    
    // Hide feedback from previous question
    quizFeedback.style.display = 'none';
    
    // Reset answer state for new question
    answeredCurrentQuestion = false;
    
    // Update navigation buttons
    quizBackBtn.disabled = currentQuestionIndex === 0;
    quizNextBtn.textContent = currentQuestionIndex === questions.length - 1 ? 'Finish' : 'Next';
    
    // Update progress indicator
    updateProgressIndicator();
    
    // Create question element
    const questionElement = document.createElement('div');
    questionElement.className = 'question';
    questionElement.innerHTML = `
      <div class="question-text mb-4">
        <div class="text-sm text-gray-500 mb-2">Question ${currentQuestionIndex + 1} of ${questions.length}</div>
        <p class="text-lg font-medium">${question.question}</p>
      </div>
      <div class="options space-y-3">
        ${question.options.map((option, index) => `
          <div class="quiz-option ${userAnswers[currentQuestionIndex] === index ? 'selected' : ''}" data-index="${index}">
            <div class="flex items-center">
              <div class="option-letter flex items-center justify-center w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-medium mr-3">
                ${String.fromCharCode(65 + index)}
              </div>
              <div class="option-text">${option}</div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    
    // Clear container and add new question
    quizContainer.innerHTML = '';
    quizContainer.appendChild(questionElement);
    
    // Add event listeners to options
    const options = questionElement.querySelectorAll('.quiz-option');
    options.forEach(option => {
      option.addEventListener('click', () => {
        // Only allow selecting if we haven't already answered this question
        if (answeredCurrentQuestion) return;
        
        const optionIndex = parseInt(option.dataset.index);
        userAnswers[currentQuestionIndex] = optionIndex;
        
        // Mark this question as answered
        answeredCurrentQuestion = true;
        
        // Update UI
        options.forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');
        
        // Check if answer is correct
        const isCorrect = optionIndex === question.correctOption;
        lastAnswerCorrect = isCorrect;
        
        // Update consecutive correct counter
        if (isCorrect) {
          consecutiveCorrect++;
        } else {
          consecutiveCorrect = 0;
        }
        
        // Apply visual feedback
        if (isCorrect) {
          option.classList.add('correct');
          
          // Show feedback
          quizFeedback.className = 'quiz-feedback correct';
          quizFeedback.innerHTML = `
            <div class="flex items-center justify-center">
              <span class="material-icons mr-2">check_circle</span>
              <span>Correct! +${XP_PER_CORRECT} XP</span>
            </div>
          `;
          
          // Add bonus XP for streak
          let bonusXP = 0;
          if (consecutiveCorrect >= 3) {
            bonusXP = XP_STREAK_BONUS;
            quizFeedback.innerHTML = `
              <div class="flex items-center justify-center">
                <span class="material-icons mr-2">check_circle</span>
                <span>Correct! +${XP_PER_CORRECT + bonusXP} XP (streak bonus!)</span>
              </div>
            `;
          }
          
          // Award points via gamification system
          if (window.gamification) {
            const pointsEarned = XP_PER_CORRECT + bonusXP;
            totalXpEarned += pointsEarned;
            window.gamification.addPoints(pointsEarned, 'Correct answer');
          }
        } else {
          option.classList.add('incorrect');
          
          // Show correct answer
          options.forEach(opt => {
            if (parseInt(opt.dataset.index) === question.correctOption) {
              opt.classList.add('correct');
            }
          });
          
          // Show feedback
          quizFeedback.className = 'quiz-feedback incorrect';
          quizFeedback.innerHTML = `
            <div class="flex items-center justify-center">
              <span class="material-icons mr-2">cancel</span>
              <span>Incorrect. Keep learning!</span>
            </div>
          `;
        }
        
        // Show feedback
        quizFeedback.style.display = 'block';
        
        // Auto-advance to next question after delay if not the last question
        if (currentQuestionIndex < questions.length - 1) {
          setTimeout(() => {
            if (currentQuestionIndex < questions.length - 1) {
              currentQuestionIndex++;
              showQuizQuestion();
            }
          }, 2000);
        }
      });
    });
  }
  
  function showQuizResults() {
    // Calculate score
    let correctAnswers = 0;
    
    questions.forEach((question, index) => {
      if (userAnswers[index] === question.correctOption) {
        correctAnswers++;
      }
    });
    
    const scorePercentage = Math.round((correctAnswers / questions.length) * 100);
    
    // Add completion XP
    if (window.gamification) {
      totalXpEarned += XP_FOR_COMPLETION;
      window.gamification.addPoints(XP_FOR_COMPLETION, 'Quiz completion');
      
      // Check if user earned achievements
      if (scorePercentage >= 80) {
        // Show achievement notification for high score
        showAchievementNotification("Quiz Master", "Scored 80% or higher on a quiz");
        
        // Trigger confetti celebration
        if (window.confetti) {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
          });
        }
      }
      
      // Check for perfect score
      if (scorePercentage === 100) {
        setTimeout(() => {
          showAchievementNotification("Perfect Score", "Answered all questions correctly!");
          
          // More elaborate confetti for perfect score
          if (window.confetti) {
            const end = Date.now() + 2000;
            const colors = ['#4F46E5', '#7C3AED', '#2563EB'];
            
            (function frame() {
              confetti({
                particleCount: 3,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors
              });
              confetti({
                particleCount: 3,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors
              });
              
              if (Date.now() < end) {
                requestAnimationFrame(frame);
              }
            }());
          }
        }, 1000);
      }
    }
    
    // Update UI
    quizScore.textContent = `${scorePercentage}%`;
    
    // Update points earned display
    pointsEarnedSpan.textContent = `You earned ${totalXpEarned} XP!`;
    
    // Set score text based on performance
    if (scorePercentage >= 80) {
      quizScoreText.textContent = 'Excellent! You have a strong understanding of this content.';
    } else if (scorePercentage >= 60) {
      quizScoreText.textContent = 'Good job! You have a solid grasp of the material.';
    } else if (scorePercentage >= 40) {
      quizScoreText.textContent = 'You\'re making progress. Consider reviewing the material again.';
    } else {
      quizScoreText.textContent = 'It seems you need more time with this content. We recommend reviewing it again.';
    }
    
    // Show results view
    showView(quizResultsView);
  }
  
  // Show achievement notification with custom styling
  function showAchievementNotification(title, message) {
    const notification = document.createElement('div');
    notification.className = 'notification achievement-notification';
    notification.innerHTML = `
      <span class="material-icons achievement-icon">emoji_events</span>
      <div>
        <div class="achievement-title">${title}</div>
        <div class="achievement-message">${message}</div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animation
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    // Remove after duration
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 5000); // Longer duration for achievements
  }
  
  function showQuizReview() {
    // Create review elements
    let reviewHTML = '';
    
    questions.forEach((question, index) => {
      const userAnswerIndex = userAnswers[index];
      const isCorrect = userAnswerIndex === question.correctOption;
      
      reviewHTML += `
        <div class="question mb-6 pb-4 border-b border-gray-200">
          <div class="question-text mb-3">
            <div class="text-sm text-gray-500 mb-1">Question ${index + 1}</div>
            <p class="font-medium">${question.question}</p>
          </div>
          <div class="options space-y-2">
            ${question.options.map((option, optIndex) => `
              <div class="quiz-option ${userAnswerIndex === optIndex ? (isCorrect ? 'correct' : 'incorrect') : ''} ${question.correctOption === optIndex && userAnswerIndex !== optIndex ? 'correct' : ''}">
                <div class="flex items-center justify-between">
                  <div class="flex items-center">
                    <div class="option-letter flex items-center justify-center w-8 h-8 rounded-full ${getOptionColorClass(optIndex, userAnswerIndex, question.correctOption)} mr-3">
                      ${String.fromCharCode(65 + optIndex)}
                    </div>
                    <div class="option-text">${option}</div>
                  </div>
                  ${getOptionIconHTML(optIndex, userAnswerIndex, question.correctOption)}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    });
    
    reviewContainer.innerHTML = reviewHTML;
    
    // Show review view
    showView(quizReviewView);
  }
  
  function getOptionColorClass(optIndex, userAnswerIndex, correctOptionIndex) {
    if (optIndex === correctOptionIndex) {
      return 'bg-green-100 text-green-700';
    } else if (optIndex === userAnswerIndex && userAnswerIndex !== correctOptionIndex) {
      return 'bg-red-100 text-red-700';
    } else {
      return 'bg-gray-100 text-gray-700';
    }
  }
  
  function getOptionIconHTML(optIndex, userAnswerIndex, correctOptionIndex) {
    if (optIndex === correctOptionIndex) {
      return '<span class="material-icons text-green-500">check_circle</span>';
    } else if (optIndex === userAnswerIndex && userAnswerIndex !== correctOptionIndex) {
      return '<span class="material-icons text-red-500">cancel</span>';
    } else {
      return '';
    }
  }
  
  async function submitQuizResults() {
    try {
      // Calculate score
      let correctAnswers = 0;
      questions.forEach((question, index) => {
        if (userAnswers[index] === question.correctOption) {
          correctAnswers++;
        }
      });
      
      const score = Math.round((correctAnswers / questions.length) * 100);
      
      // Update questions with user answers
      const updatedQuestions = questions.map((question, index) => ({
        ...question,
        userAnswer: userAnswers[index]
      }));
      
      // Submit results to API
      const response = await fetch('/api/evaluate-quiz', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          activityId,
          questions: updatedQuestions,
          score,
          xpEarned: totalXpEarned
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit quiz results');
      }
      
      // Record quiz completion in gamification system
      if (window.gamification) {
        await window.gamification.recordActivity({
          type: 'quiz',
          correctAnswers,
          totalQuestions: questions.length,
          score
        });
      }
      
      // Close window (if in popup) or redirect to dashboard
      if (window.opener) {
        window.close();
      } else {
        window.location.href = '/dashboard.html';
      }
      
    } catch (error) {
      console.error('Error submitting quiz results:', error);
      alert('Failed to save quiz results. Please try again.');
    }
  }
  
  function showView(viewToShow) {
    // Hide all views
    loadingView.style.display = 'none';
    quizView.style.display = 'none';
    quizResultsView.style.display = 'none';
    quizReviewView.style.display = 'none';
    
    // Show the requested view
    viewToShow.style.display = 'block';
  }
  
  // Event Listeners
  quizBackBtn.addEventListener('click', () => {
    if (currentQuestionIndex > 0) {
      currentQuestionIndex--;
      showQuizQuestion();
    }
  });
  
  quizNextBtn.addEventListener('click', () => {
    if (currentQuestionIndex < questions.length - 1) {
      currentQuestionIndex++;
      showQuizQuestion();
    } else {
      showQuizResults();
    }
  });
  
  viewAnswersBtn.addEventListener('click', () => {
    showQuizReview();
  });
  
  finishQuizBtn.addEventListener('click', () => {
    submitQuizResults();
  });
  
  backToResultsBtn.addEventListener('click', () => {
    showView(quizResultsView);
  });
});