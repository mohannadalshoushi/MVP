document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const successMessage = document.getElementById('success-message');
  
  // Check if user just registered successfully
  if (localStorage.getItem('registration_success') === 'true') {
    successMessage.style.display = 'block';
    localStorage.removeItem('registration_success');
  }
  
  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Show loading state
    const submitButton = loginForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.innerHTML = '<div class="spinner"></div>';
    
    try {
      // Send login request to the API
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }
      
      // Store user data
      localStorage.setItem('user', JSON.stringify(data.user));
      localStorage.setItem('is_authenticated', 'true');
      
      // Redirect to popup.html (main extension interface)
      window.location.href = './popup.html';
      
    } catch (error) {
      console.error('Login error:', error);
      
      // Show error message
      alert(`Login failed: ${error.message}`);
      
      // Reset button
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  });
});