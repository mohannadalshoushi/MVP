document.addEventListener('DOMContentLoaded', () => {
  const signupForm = document.getElementById('signup-form');
  
  signupForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const sector = document.getElementById('sector').value;
    
    // Show loading state
    const submitButton = signupForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.innerHTML = '<div class="spinner"></div>';
    
    try {
      // Send registration request to the API
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, username, password, sector }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Registration failed');
      }
      
      // Registration successful, redirect to login
      localStorage.setItem('registration_success', 'true');
      window.location.href = './login.html';
      
    } catch (error) {
      console.error('Registration error:', error);
      
      // Show error message
      alert(`Registration failed: ${error.message}`);
      
      // Reset button
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  });
});