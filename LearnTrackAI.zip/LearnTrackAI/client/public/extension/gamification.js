/**
 * Learnfy.AI Gamification System
 * Inspired by Duolingo's engagement mechanics
 */

class GamificationSystem {
  constructor() {
    this.points = 0;
    this.streak = 0;
    this.level = 1;
    this.badges = [];
    this.xpToNextLevel = 100;
    this.initialized = false;
    
    // Element references
    this.xpDisplay = null;
    this.levelDisplay = null;
    this.streakDisplay = null;
    this.progressBar = null;
    
    // Initialize default point values
    this.pointValues = {
      contentRead: 10,       // Points for reading content
      quizComplete: 25,      // Base points for completing a quiz
      quizCorrect: 5,        // Points per correct answer
      categoryMastery: 50,   // Points for mastering a category
      dailyStreak: 15,       // Points for maintaining streak
      noteAdded: 5,          // Points for adding learning notes
      timeSpent: 1           // Points per minute spent learning
    };
  }
  
  // Initialize gamification system with user data
  async initialize() {
    if (this.initialized) return;
    
    try {
      // Fetch user gamification data
      const response = await fetch('/api/user/gamification');
      
      if (response.ok) {
        const data = await response.json();
        this.points = data.points || 0;
        this.streak = data.streak || 0;
        this.level = data.level || 1;
        this.badges = data.badges || [];
        this.xpToNextLevel = data.xpToNextLevel || 100;
      } else {
        // Use default values if fetch fails
        console.warn('Failed to fetch gamification data, using defaults');
      }
      
      // Find UI elements
      this.xpDisplay = document.getElementById('xp-display');
      this.levelDisplay = document.getElementById('level-display');
      this.streakDisplay = document.getElementById('streak-display');
      this.progressBar = document.getElementById('xp-progress-bar');
      
      // Update UI
      this.updateUI();
      this.initialized = true;
      
    } catch (error) {
      console.error('Failed to initialize gamification system:', error);
    }
  }
  
  // Update UI elements with current values
  updateUI() {
    if (this.xpDisplay) {
      this.xpDisplay.textContent = this.points;
    }
    
    if (this.levelDisplay) {
      this.levelDisplay.textContent = this.level;
    }
    
    if (this.streakDisplay) {
      this.streakDisplay.textContent = this.streak;
    }
    
    if (this.progressBar) {
      const percentage = Math.min(100, (this.points % 100) / this.xpToNextLevel * 100);
      this.progressBar.style.width = `${percentage}%`;
    }
  }
  
  // Add points and check for level up
  async addPoints(amount, reason) {
    this.points += amount;
    
    // Check for level up
    if (this.points >= this.level * this.xpToNextLevel) {
      this.levelUp();
    }
    
    // Update UI
    this.updateUI();
    
    // Show animation for points gained
    this.showPointsAnimation(amount, reason);
    
    // Save updated points to server
    try {
      await fetch('/api/user/gamification/points', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          points: this.points,
          level: this.level
        })
      });
    } catch (error) {
      console.error('Failed to save points:', error);
    }
    
    return this.points;
  }
  
  // Handle level up
  levelUp() {
    this.level += 1;
    
    // Show level up animation
    this.showLevelUpAnimation();
    
    // Check for new badges
    this.checkForBadges();
  }
  
  // Record activity completion
  async recordActivity(activity) {
    let pointsEarned = 0;
    let reason = '';
    
    // Calculate points based on activity type
    switch (activity.type) {
      case 'content':
        pointsEarned = this.pointValues.contentRead;
        reason = 'Content read';
        break;
        
      case 'quiz':
        // Base points for completing + bonus for correct answers
        const correctAnswers = activity.correctAnswers || 0;
        pointsEarned = this.pointValues.quizComplete + (correctAnswers * this.pointValues.quizCorrect);
        reason = 'Quiz completed';
        break;
        
      case 'streak':
        pointsEarned = this.pointValues.dailyStreak;
        reason = 'Daily streak maintained';
        this.streak += 1;
        break;
        
      case 'note':
        pointsEarned = this.pointValues.noteAdded;
        reason = 'Learning note added';
        break;
        
      case 'timeSpent':
        // Points for time spent (in minutes)
        const minutes = Math.floor(activity.timeSpent / 60);
        pointsEarned = minutes * this.pointValues.timeSpent;
        reason = 'Time spent learning';
        break;
    }
    
    // Add points
    await this.addPoints(pointsEarned, reason);
    
    return pointsEarned;
  }
  
  // Check for new badges based on achievements
  checkForBadges() {
    const newBadges = [];
    
    // Level-based badges
    if (this.level >= 5 && !this.hasBadge('master_learner')) {
      newBadges.push({
        id: 'master_learner',
        name: 'Master Learner',
        icon: 'school',
        description: 'Reached level 5'
      });
    }
    
    if (this.level >= 10 && !this.hasBadge('knowledge_expert')) {
      newBadges.push({
        id: 'knowledge_expert',
        name: 'Knowledge Expert',
        icon: 'psychology',
        description: 'Reached level 10'
      });
    }
    
    if (this.level >= 20 && !this.hasBadge('knowledge_grandmaster')) {
      newBadges.push({
        id: 'knowledge_grandmaster',
        name: 'Knowledge Grandmaster',
        icon: 'workspace_premium',
        description: 'Reached level 20'
      });
    }
    
    // Streak-based badges
    if (this.streak >= 3 && !this.hasBadge('consistent_learner')) {
      newBadges.push({
        id: 'consistent_learner',
        name: 'Consistent Learner',
        icon: 'local_fire_department',
        description: '3-day learning streak'
      });
    }
    
    if (this.streak >= 7 && !this.hasBadge('weekly_scholar')) {
      newBadges.push({
        id: 'weekly_scholar',
        name: 'Weekly Scholar',
        icon: 'calendar_today',
        description: '7-day learning streak'
      });
    }
    
    if (this.streak >= 30 && !this.hasBadge('learning_machine')) {
      newBadges.push({
        id: 'learning_machine',
        name: 'Learning Machine',
        icon: 'whatshot',
        description: '30-day learning streak'
      });
    }
    
    // Points-based badges
    if (this.points >= 500 && !this.hasBadge('knowledge_seeker')) {
      newBadges.push({
        id: 'knowledge_seeker',
        name: 'Knowledge Seeker',
        icon: 'search',
        description: 'Earned 500 XP'
      });
    }
    
    if (this.points >= 1000 && !this.hasBadge('wisdom_hunter')) {
      newBadges.push({
        id: 'wisdom_hunter',
        name: 'Wisdom Hunter',
        icon: 'emoji_objects',
        description: 'Earned 1000 XP'
      });
    }
    
    if (this.points >= 5000 && !this.hasBadge('learning_legend')) {
      newBadges.push({
        id: 'learning_legend',
        name: 'Learning Legend',
        icon: 'military_tech',
        description: 'Earned 5000 XP'
      });
    }
    
    // Quiz-specific badges
    const quizData = this.getStoredActivityData('quiz');
    
    if (quizData) {
      // Perfect Quiz badge
      if (quizData.perfectQuizzes >= 1 && !this.hasBadge('perfect_recall')) {
        newBadges.push({
          id: 'perfect_recall',
          name: 'Perfect Recall',
          icon: 'done_all',
          description: 'Scored 100% on a quiz'
        });
      }
      
      // Quiz Master badge
      if (quizData.quizzesCompleted >= 5 && !this.hasBadge('quiz_master')) {
        newBadges.push({
          id: 'quiz_master',
          name: 'Quiz Master',
          icon: 'quiz',
          description: 'Completed 5 quizzes'
        });
      }
      
      // Quiz Expert badge
      if (quizData.quizzesCompleted >= 20 && !this.hasBadge('quiz_expert')) {
        newBadges.push({
          id: 'quiz_expert',
          name: 'Quiz Expert',
          icon: 'grading',
          description: 'Completed 20 quizzes'
        });
      }
      
      // Accurate Learner badge
      if (quizData.totalCorrectAnswers >= 50 && !this.hasBadge('accurate_learner')) {
        newBadges.push({
          id: 'accurate_learner',
          name: 'Accurate Learner',
          icon: 'fact_check',
          description: 'Answered 50 questions correctly'
        });
      }
    }
    
    // Add new badges and show notification
    if (newBadges.length > 0) {
      this.badges = [...this.badges, ...newBadges];
      this.showBadgeNotification(newBadges);
      
      // Save badges to server
      this.saveBadges();
    }
    
    return newBadges;
  }
  
  // Get stored activity data for a specific activity type
  getStoredActivityData(activityType) {
    try {
      // We'll simulate this for now, but in a real extension,
      // this would fetch from localStorage or the server
      const mockData = {
        quiz: {
          quizzesCompleted: 5,
          perfectQuizzes: 1,
          totalCorrectAnswers: 52,
          averageScore: 85
        }
      };
      
      return mockData[activityType];
    } catch (error) {
      console.error(`Error fetching ${activityType} data:`, error);
      return null;
    }
  }
  
  // Check if user has a specific badge
  hasBadge(badgeId) {
    return this.badges.some(badge => badge.id === badgeId);
  }
  
  // Save badges to server
  async saveBadges() {
    try {
      await fetch('/api/user/gamification/badges', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          badges: this.badges
        })
      });
    } catch (error) {
      console.error('Failed to save badges:', error);
    }
  }
  
  // Show badge notification
  showBadgeNotification(newBadges) {
    newBadges.forEach(badge => {
      // Create badge notification element
      const notification = document.createElement('div');
      notification.className = 'badge-notification';
      notification.innerHTML = `
        <div class="badge-notification-content">
          <div class="badge-icon">
            <span class="material-icons">${badge.icon}</span>
          </div>
          <div class="badge-info">
            <div class="badge-name">${badge.name}</div>
            <div class="badge-description">${badge.description}</div>
          </div>
        </div>
      `;
      
      // Add to page
      document.body.appendChild(notification);
      
      // Remove after animation completes
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 4000);
    });
  }
  
  // Show animation for points gained
  showPointsAnimation(amount, reason) {
    // Create floating animation element
    const floatingPoints = document.createElement('div');
    floatingPoints.className = 'floating-points';
    floatingPoints.innerHTML = `
      <div class="points-content">
        <span class="points-amount">+${amount}</span>
        <span class="points-reason">${reason}</span>
      </div>
    `;
    
    // Add to page
    document.body.appendChild(floatingPoints);
    
    // Remove after animation completes
    setTimeout(() => {
      document.body.removeChild(floatingPoints);
    }, 2000);
  }
  
  // Show level up animation
  showLevelUpAnimation() {
    // Get the overlay element
    const levelUpOverlay = document.getElementById('level-up-overlay');
    const levelDisplay = document.getElementById('level-up-level');
    const continueButton = document.getElementById('level-up-continue');
    const starsContainer = document.getElementById('level-up-stars');
    
    if (!levelUpOverlay) {
      // Fallback to simple animation if the overlay doesn't exist
      this.showSimpleLevelUpAnimation();
      return;
    }
    
    // Update level display
    if (levelDisplay) {
      levelDisplay.textContent = this.level;
    }
    
    // Create the stars background
    if (starsContainer) {
      starsContainer.innerHTML = '';
      // Add 50 star elements
      for (let i = 0; i < 50; i++) {
        const star = document.createElement('div');
        star.className = 'level-up-star';
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        star.style.animationDelay = `${Math.random() * 3}s`;
        star.style.animationDuration = `${Math.random() * 2 + 1}s`;
        starsContainer.appendChild(star);
      }
    }
    
    // Add confetti animation effect
    if (typeof window.confetti === 'function') {
      const duration = 3 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };
      
      function randomInRange(min, max) {
        return Math.random() * (max - min) + min;
      }
      
      const interval = setInterval(function() {
        const timeLeft = animationEnd - Date.now();
        
        if (timeLeft <= 0) {
          return clearInterval(interval);
        }
        
        const particleCount = 50 * (timeLeft / duration);
        
        // since particles fall down, start a bit higher than random
        window.confetti(Object.assign({}, defaults, { 
          particleCount, 
          origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
          colors: ['#fde047', '#facc15', '#eab308'],
        }));
        window.confetti(Object.assign({}, defaults, { 
          particleCount, 
          origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
          colors: ['#4f46e5', '#6d28d9', '#8b5cf6'],
        }));
      }, 250);
    }
    
    // Show the overlay
    levelUpOverlay.classList.add('active');
    
    // Add click event to continue button
    if (continueButton) {
      continueButton.addEventListener('click', () => {
        levelUpOverlay.classList.remove('active');
      }, { once: true });
    }
    
    // Automatically hide after 10 seconds if user doesn't click continue
    setTimeout(() => {
      levelUpOverlay.classList.remove('active');
    }, 10000);
  }
  
  // Fallback simple level up animation
  showSimpleLevelUpAnimation() {
    // Create level up animation
    const levelUpEl = document.createElement('div');
    levelUpEl.className = 'level-up-animation';
    levelUpEl.innerHTML = `
      <div class="level-up-content">
        <span class="level-up-icon">🎉</span>
        <span class="level-up-text">Level Up!</span>
        <span class="level-up-level">Level ${this.level}</span>
      </div>
    `;
    
    // Add confetti animation effect
    if (typeof window.confetti === 'function') {
      window.confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
    
    // Add to page
    document.body.appendChild(levelUpEl);
    
    // Remove after animation completes
    setTimeout(() => {
      document.body.removeChild(levelUpEl);
    }, 3000);
  }
  
  // Show special achievement notification
  showSpecialAchievement(title, message) {
    // Create achievement notification
    const achievementEl = document.createElement('div');
    achievementEl.className = 'special-achievement-animation';
    achievementEl.innerHTML = `
      <div class="special-achievement-content">
        <div class="achievement-header">
          <span class="material-icons achievement-icon">emoji_events</span>
          <span class="achievement-title">${title}</span>
        </div>
        <p class="achievement-message">${message}</p>
      </div>
    `;
    
    // Add to page
    document.body.appendChild(achievementEl);
    
    // Remove after animation completes
    setTimeout(() => {
      document.body.removeChild(achievementEl);
    }, 4000);
  }
  
  // Get current streak
  getStreak() {
    return this.streak;
  }
  
  // Get current level
  getLevel() {
    return this.level;
  }
  
  // Get current points
  getPoints() {
    return this.points;
  }
  
  // Get badges
  getBadges() {
    return this.badges;
  }
}

// Create a singleton instance
const gamification = new GamificationSystem();

// Export for use in other scripts
window.gamification = gamification;