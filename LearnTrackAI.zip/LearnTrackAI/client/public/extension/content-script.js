/**
 * Learnfy.AI Content Script
 * 
 * This script is injected into web pages to detect educational content and track learning.
 * It also handles triggering the quiz popup when the user leaves or closes the page.
 */

// Track if we've detected educational content on this page
let isEducationalContent = false;
let contentData = {
  title: '',
  url: '',
  source: '',
  contentType: 'article', // Default type, can be 'article' or 'video'
  category: null
};
let trackingStartTime = null;
let activityId = null;

// Initialize content tracking when the page loads
window.addEventListener('DOMContentLoaded', () => {
  console.log('Learnfy.AI content script initialized');
  
  // Analyze the current page to determine if it's educational content
  analyzeContent();
  
  // Set up listeners for page visibility changes and unload
  setupPageListeners();
});

/**
 * Analyze the page content to determine if it's educational
 */
async function analyzeContent() {
  // Get page metadata
  contentData.title = document.title;
  contentData.url = window.location.href;
  contentData.source = window.location.hostname;
  
  // Check if the page has video content
  if (document.querySelector('video') || 
      window.location.hostname.includes('youtube.com') ||
      window.location.hostname.includes('coursera.org') ||
      window.location.hostname.includes('udemy.com')) {
    contentData.contentType = 'video';
  }
  
  // Extract main content for analysis
  const mainContent = extractMainContent();
  
  try {
    // Send content to background script for analysis
    // In a real extension, this would call the Learnfy.AI API
    // For demo, we'll determine educational content based on certain keywords or domains
    const educationalDomains = [
      'medium.com', 'dev.to', 'freecodecamp.org', 'coursera.org', 
      'udemy.com', 'edx.org', 'w3schools.com', 'mdn.mozilla.org',
      'github.com', 'stackoverflow.com', 'khanacademy.org'
    ];
    
    const isEducationalDomain = educationalDomains.some(domain => 
      window.location.hostname.includes(domain)
    );
    
    const educationalKeywords = [
      'tutorial', 'learn', 'course', 'programming', 'development',
      'guide', 'javascript', 'python', 'react', 'angular', 'vue',
      'code', 'coding', 'algorithm', 'function', 'data', 'api',
      'machine learning', 'AI', 'artificial intelligence', 'cloud',
      'devops', 'database', 'sql', 'aws', 'azure', 'engineering'
    ];
    
    const containsEducationalKeywords = educationalKeywords.some(keyword => 
      mainContent.toLowerCase().includes(keyword.toLowerCase()) ||
      contentData.title.toLowerCase().includes(keyword.toLowerCase())
    );
    
    isEducationalContent = isEducationalDomain || containsEducationalKeywords;
    
    if (isEducationalContent) {
      console.log('Learnfy.AI: Educational content detected');
      
      // Determine the most likely category
      // This would be done by the API in a real extension
      const programmingKeywords = ['javascript', 'python', 'java', 'coding', 'programming', 'framework', 'react', 'angular', 'vue'];
      const dataKeywords = ['data science', 'statistics', 'machine learning', 'ai', 'artificial intelligence', 'visualization', 'analytics'];
      const designKeywords = ['design', 'ui', 'ux', 'interface', 'usability', 'figma', 'sketch'];
      
      if (programmingKeywords.some(kw => mainContent.toLowerCase().includes(kw.toLowerCase()))) {
        contentData.category = 'Programming';
      } else if (dataKeywords.some(kw => mainContent.toLowerCase().includes(kw.toLowerCase()))) {
        contentData.category = 'Data Science';
      } else if (designKeywords.some(kw => mainContent.toLowerCase().includes(kw.toLowerCase()))) {
        contentData.category = 'Design';
      } else {
        contentData.category = 'Other';
      }
      
      // Start tracking time spent
      startTimeTracking();
      
      // Notify the user that Learnfy is tracking this content
      showTrackingNotification();
    }
  } catch (error) {
    console.error('Learnfy.AI: Error analyzing content', error);
  }
}

/**
 * Extract the main content text from the page
 */
function extractMainContent() {
  // A simple algorithm to extract the main content
  // In a real extension, we'd use a more sophisticated approach
  
  // Try to find the main article content
  const articleContent = document.querySelector('article');
  if (articleContent) {
    return articleContent.textContent;
  }
  
  // Try to find the main content container
  const mainContent = document.querySelector('main');
  if (mainContent) {
    return mainContent.textContent;
  }
  
  // Fallback to the body content, excluding script and style tags
  const bodyText = document.body.innerText;
  return bodyText;
}

/**
 * Start tracking time spent on this page
 */
function startTimeTracking() {
  trackingStartTime = new Date();
  
  // Create a placeholder activityId (would be returned from the API in a real extension)
  activityId = Math.floor(Math.random() * 1000000);
  
  // Send a message to the background script to start tracking
  // In a real extension, this would make an API call to create the activity
  console.log('Learnfy.AI: Started time tracking for', contentData.title);
}

/**
 * Setup listeners for page visibility and unload events
 */
function setupPageListeners() {
  // Track page visibility changes (tab switching, minimizing)
  document.addEventListener('visibilitychange', handleVisibilityChange);
  
  // Track page unload (closing tab, navigating away)
  window.addEventListener('beforeunload', handlePageUnload);
}

/**
 * Handle visibility changes (tab switching, minimizing)
 */
function handleVisibilityChange() {
  if (!isEducationalContent) return;
  
  if (document.hidden) {
    // Page is hidden, pause tracking
    console.log('Learnfy.AI: Page hidden, pausing tracking');
    // In a real extension, we would record the time spent so far
  } else {
    // Page is visible again, resume tracking
    console.log('Learnfy.AI: Page visible, resuming tracking');
  }
}

/**
 * Handle page unload (closing tab, navigating away)
 */
function handlePageUnload(event) {
  if (!isEducationalContent) return;
  
  // Calculate time spent
  const endTime = new Date();
  const timeSpentInSeconds = Math.floor((endTime - trackingStartTime) / 1000);
  
  console.log(`Learnfy.AI: User leaving page after ${timeSpentInSeconds} seconds`);
  
  // In a real extension, we would send this data to the server
  // For demo purposes, we'll just show a quiz popup if enough time was spent
  
  if (timeSpentInSeconds >= 30) { // Only show quiz if user spent at least 30 seconds
    // Store the learning activity information for other extension pages to access
    localStorage.setItem('learnfy_last_activity', JSON.stringify({
      activityId: activityId,
      title: contentData.title,
      url: contentData.url,
      source: contentData.source,
      contentType: contentData.contentType,
      category: contentData.category,
      timeSpent: timeSpentInSeconds
    }));
    
    // Trigger the quiz popup
    triggerQuizPopup();
  }
}

/**
 * Show a notification that Learnfy is tracking this content
 */
function showTrackingNotification() {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = 'learnfy-notification';
  notification.innerHTML = `
    <div class="learnfy-notification-content">
      <div class="learnfy-notification-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
        </svg>
      </div>
      <div class="learnfy-notification-message">
        <div class="learnfy-notification-title">Learnfy.AI is tracking your learning</div>
        <div class="learnfy-notification-text">Category: ${contentData.category || 'Auto-detected'}</div>
      </div>
    </div>
  `;
  
  // Add styles
  const style = document.createElement('style');
  style.textContent = `
    .learnfy-notification {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 10000;
      animation: learnfy-slide-in 0.5s ease-out forwards;
    }
    
    .learnfy-notification-content {
      display: flex;
      align-items: center;
      background-color: #4f46e5;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .learnfy-notification-icon {
      margin-right: 12px;
    }
    
    .learnfy-notification-title {
      font-weight: bold;
      margin-bottom: 4px;
    }
    
    .learnfy-notification-text {
      font-size: 0.875rem;
      opacity: 0.9;
    }
    
    @keyframes learnfy-slide-in {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `;
  
  document.head.appendChild(style);
  document.body.appendChild(notification);
  
  // Remove after 5 seconds
  setTimeout(() => {
    notification.style.animation = 'learnfy-slide-out 0.5s ease-in forwards';
    setTimeout(() => {
      notification.remove();
    }, 500);
  }, 5000);
}

/**
 * Trigger the quiz popup when the user leaves the page
 */
function triggerQuizPopup() {
  // In a real Chrome extension, we would use chrome.runtime.sendMessage
  // to tell the background script to open the quiz popup
  
  // For our demo, we'll use window.open with the quiz URL
  const quizUrl = `/extension/quiz?activityId=${activityId}&title=${encodeURIComponent(contentData.title)}`;
  
  try {
    // Open quiz in a new popup window
    const popupWindow = window.open(quizUrl, 'LearnfyQuiz', 'width=600,height=800');
    
    // If popup was blocked or failed to open, we can try other approaches
    if (!popupWindow || popupWindow.closed || typeof popupWindow.closed === 'undefined') {
      console.log('Learnfy.AI: Quiz popup was blocked. Storing info for next extension open');
      
      // Store a flag to show the quiz next time the user opens the extension
      localStorage.setItem('learnfy_show_quiz_on_open', 'true');
    }
  } catch (error) {
    console.error('Learnfy.AI: Error opening quiz popup', error);
  }
}