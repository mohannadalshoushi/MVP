import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import LearningHistory from "@/pages/learning-history";
import KnowledgeBase from "@/pages/knowledge-base";
import LiveCV from "@/pages/live-cv";
import Settings from "@/pages/settings";
import Certifications from "@/pages/certifications";
import LanguageSkills from "@/pages/language-skills";
import AchievementMilestones from "@/pages/achievement-milestones";
import SharedMilestone from "@/pages/shared-milestone";
import SharingDemos from "@/pages/sharing-demos";
import Community from "@/pages/community";
import AuthPage from "@/pages/auth-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "@/hooks/use-auth";

import { AppLayout } from "@/components/layout/app-layout";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/auth" component={AuthPage} />
      <Route path="/share/:shareUrl" component={SharedMilestone} />
      
      {/* Main dashboard routes */}
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/learning-history" component={LearningHistory} />
      <ProtectedRoute path="/knowledge-base" component={KnowledgeBase} />
      
      {/* Professional profile routes */}
      <ProtectedRoute path="/live-cv" component={LiveCV} />
      <ProtectedRoute path="/certifications" component={Certifications} />
      <ProtectedRoute path="/language-skills" component={LanguageSkills} />
      
      {/* Community and sharing routes */}
      <ProtectedRoute path="/community" component={Community} />
      <ProtectedRoute path="/achievement-milestones" component={AchievementMilestones} />
      
      {/* For backward compatibility - redirects to achievement-milestones */}
      <ProtectedRoute path="/public-milestones" component={AchievementMilestones} />
      
      {/* Demo and settings */}
      <ProtectedRoute path="/sharing-demos" component={SharingDemos} />
      <ProtectedRoute path="/settings" component={Settings} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Get the current location (pathname)
  const location = window.location.pathname;
  const isPublicRoute = location === "/auth" || location.startsWith("/share/");

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        {isPublicRoute ? (
          <Router />
        ) : (
          <AppLayout>
            <Router />
          </AppLayout>
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
