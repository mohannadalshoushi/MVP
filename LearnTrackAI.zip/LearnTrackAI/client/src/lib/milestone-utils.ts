import { LearningProgressEvent, LearningMilestone } from "@/lib/types";

/**
 * Format date for milestone display
 */
export function formatMilestoneDate(date: Date | string | null): string {
  if (!date) return "N/A";
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(dateObj);
}

/**
 * Get color class based on milestone type
 */
export function getMilestoneColor(milestoneType: string): string {
  switch (milestoneType) {
    case "time":
      return "bg-purple-500 text-white";
    case "content_count":
      return "bg-amber-500 text-white";
    case "quiz_score":
      return "bg-blue-500 text-white";
    case "streak":
      return "bg-red-500 text-white";
    case "category_mastery":
      return "bg-green-500 text-white";
    default:
      return "bg-primary text-white";
  }
}

/**
 * Get icon name based on event type
 */
export function getEventIcon(event: LearningProgressEvent): string {
  switch (event.eventType) {
    case "activity":
      return "book";
    case "milestone":
      return event.iconName || "award";
    case "quiz":
      return "question-mark";
    case "streak":
      return "fire";
    default:
      return "award";
  }
}

/**
 * Generate streak message based on streak days
 */
export function getStreakMessage(days: number): string {
  if (days === 1) return "First day of your learning streak! Keep it up!";
  if (days < 7) return `${days} day streak! You're building momentum!`;
  if (days === 7) return "One week streak! You're becoming consistent!";
  if (days < 14) return `${days} day streak! Great consistency!`;
  if (days === 14) return "Two week streak! Your dedication is impressive!";
  if (days < 30) return `${days} day streak! Amazing discipline!`;
  if (days === 30) return "One month streak! You're a learning machine!";
  if (days < 60) return `${days} day streak! Incredible commitment!`;
  if (days === 60) return "Two month streak! You're unstoppable!";
  return `${days} day streak! You're a learning legend!`;
}

/**
 * Check if a milestone should be celebrated (based on type and user preferences)
 */
export function shouldCelebrateMilestone(milestone: LearningMilestone, preferences?: { [key: string]: boolean }): boolean {
  // If no preferences are provided, celebrate all milestones
  if (!preferences) return true;
  
  // Otherwise, check the user's preferences for this milestone type
  return preferences[milestone.milestoneType] !== false;
}

/**
 * Group timeline events by date
 */
export function groupEventsByDate(events: LearningProgressEvent[]): { [date: string]: LearningProgressEvent[] } {
  const grouped: { [date: string]: LearningProgressEvent[] } = {};
  
  for (const event of events) {
    const dateStr = formatMilestoneDate(event.date);
    if (!grouped[dateStr]) {
      grouped[dateStr] = [];
    }
    grouped[dateStr].push(event);
  }
  
  return grouped;
}