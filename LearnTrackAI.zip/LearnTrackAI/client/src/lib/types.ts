export interface User {
  id: number;
  username: string;
  name?: string;
  email?: string;
  sector?: string;
}

export interface Category {
  id: number;
  name: string;
  icon: string;
  color: string;
}

export interface LearningActivity {
  id: number;
  userId: number;
  title: string;
  url: string;
  source: string;
  categoryId: number;
  contentType: "article" | "video";
  timeSpent: number; // in seconds
  quizScore?: number; // percentage (0-100)
  summary?: string;
  learningDate: Date;
}

export interface QuizQuestion {
  id: number;
  activityId: number;
  question: string;
  options: string[];
  correctOption?: number;
  userAnswer?: number;
}

export interface LearningSummary {
  id: number;
  userId: number;
  categoryId: number;
  content: string;
  createdAt: Date;
}

export interface DashboardStats {
  learningTime: {
    total: string;
    change: string;
  };
  articlesRead: {
    total: number;
    change: string;
  };
  videosWatched: {
    total: number;
    change: string;
  };
  quizAccuracy: {
    total: string;
    change: string;
  };
}

export interface CategoryProgress {
  id: number;
  name: string;
  icon: string;
  color: string;
  hoursSpent: number;
  percentage: number;
}

export interface ToolUsage {
  id: number;
  userId: number;
  toolName: string;
  toolCategory?: string;
  hoursSpent: number;
  lastUsedDate: Date;
  icon: string;
  color: string;
}

export interface ToolUsageChart {
  toolName: string;
  hoursSpent: number;
  icon: string;
  color: string;
  percentage: number;
}

export interface QuizPerformance {
  accuracy: number;
  correct: number;
  incorrect: number;
  skipped: number;
}

export interface RecentActivity extends LearningActivity {
  category: Category;
}

export interface RecommendedContent {
  id: number;
  title: string;
  description: string;
  category: Category;
  timeToRead: string;
  source: string;
  imageUrl: string;
  contentType: "article" | "video";
  url: string;
  relevanceScore?: number;
}

export interface LearningMilestone {
  id: number;
  userId: number;
  title: string;
  description: string;
  achievedAt: Date;
  milestoneType: "time" | "content_count" | "quiz_score" | "category_mastery" | "streak";
  iconName: string;
  celebratedAt: Date | null;
  isHidden: boolean;
  isShared?: boolean;
  privacyLevel?: string;
  shareUrl?: string;
  socialPlatforms?: string[];
}

export interface LearningProgressEvent {
  id: number;
  userId: number;
  date: Date; 
  eventType: "activity" | "milestone" | "quiz" | "streak";
  title: string;
  description: string;
  iconName: string;
  iconColor: string;
  metadata?: {
    activityId?: number;
    categoryId?: number;
    milestoneId?: number;
    quizScore?: number;
    streakDays?: number;
  };
}

export interface Certification {
  id: number;
  userId: number;
  name: string;
  issuingOrganization: string;
  issueDate: Date;
  expiryDate?: Date;
  credentialID?: string;
  credentialURL?: string;
  description?: string;
  createdAt: Date;
}

export interface LanguageSkill {
  id: number;
  userId: number;
  language: string;
  readingTimeSpent: number;
  listeningTimeSpent: number;
  proficiencyLevel?: string;
  lastActivity: Date;
}

export interface LearningGoal {
  id: number;
  title: string;
  description: string;
  creatorId: number;
  category: string;
  targetDate: Date;
  progress: number; // 0-100
  participants: number[]; // Array of user IDs
  createdAt: Date;
}

export interface MilestoneCelebration {
  id: number;
  milestoneId: number;
  userId: number;
  celebrationType: string;
  createdAt: Date;
}

export interface MilestoneComment {
  id: number;
  milestoneId: number;
  userId: number;
  content: string;
  createdAt: Date;
}
