import { useState } from "react";
import { RecommendedContent as RecommendedContentType } from "@/lib/types";
import { Link } from "wouter";
import { motion } from "framer-motion";

interface RecommendedContentProps {
  content: RecommendedContentType[];
}

export function RecommendedContent({ content }: RecommendedContentProps) {
  const [sortBy, setSortBy] = useState<"relevance" | "category">("relevance");
  
  // Sort the content based on the selected option
  const sortedContent = [...content].sort((a, b) => {
    if (sortBy === "relevance") {
      return (b.relevanceScore || 0) - (a.relevanceScore || 0);
    } else {
      return a.category.name.localeCompare(b.category.name);
    }
  });

  // Animation variants for cards
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  };

  return (
    <div className="mb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Recommended For You</h2>
        <div className="flex items-center mt-2 md:mt-0">
          <div className="mr-4 text-sm text-gray-500">Sort by:</div>
          <div className="flex bg-gray-100 rounded-md p-1">
            <button 
              className={`px-3 py-1 text-sm rounded ${sortBy === "relevance" ? "bg-white shadow-sm" : "text-gray-600"}`}
              onClick={() => setSortBy("relevance")}
            >
              Relevance
            </button>
            <button 
              className={`px-3 py-1 text-sm rounded ${sortBy === "category" ? "bg-white shadow-sm" : "text-gray-600"}`}
              onClick={() => setSortBy("category")}
            >
              Category
            </button>
          </div>
          <Link href="/knowledge-base">
            <div className="text-primary text-sm cursor-pointer ml-4">View all</div>
          </Link>
        </div>
      </div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {sortedContent.map(item => (
          <motion.div 
            key={item.id} 
            className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-200"
            variants={cardVariants}
          >
            <div className="h-40 bg-gray-200 relative">
              <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
              <div className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-sm">
                <span className="material-icons" style={{ 
                  color: item.contentType === 'article' ? '#8B5CF6' : '#EF4444' 
                }}>
                  {item.contentType === 'article' ? 'article' : 'play_circle'}
                </span>
              </div>
              {item.relevanceScore && (
                <div className="absolute top-2 left-2 bg-white rounded-full px-2 py-0.5 shadow-sm flex items-center text-xs font-medium">
                  <span className="material-icons text-yellow-500 text-sm mr-1">star</span>
                  <span>{Math.round(item.relevanceScore)}% match</span>
                </div>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-center mb-2">
                <span 
                  className="text-xs font-medium px-2 py-0.5 rounded"
                  style={{ 
                    backgroundColor: `${item.category.color}25`, 
                    color: item.category.color 
                  }}
                >
                  {item.category.name}
                </span>
                <span className="text-xs text-gray-500 ml-2">{item.timeToRead}</span>
              </div>
              <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">{item.title}</h3>
              <p className="text-gray-500 text-sm mb-3 line-clamp-3">{item.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">{item.source}</span>
                <div className="flex space-x-2">
                  <a 
                    href={item.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary text-sm flex items-center hover:underline"
                  >
                    <span className="material-icons mr-1 text-sm">open_in_new</span>
                    Open
                  </a>
                  <button className="text-primary text-sm flex items-center">
                    <span className="material-icons text-sm">bookmark_border</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
      
      {content.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-8 text-center">
          <span className="material-icons text-4xl text-gray-300 mb-2">recommendation</span>
          <h3 className="text-gray-700 font-medium mb-1">No Recommendations Yet</h3>
          <p className="text-gray-500 text-sm">
            Complete more learning activities to receive personalized content recommendations.
          </p>
        </div>
      )}
    </div>
  );
}
