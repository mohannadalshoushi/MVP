import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MilestoneCelebration } from "./milestone-celebration";
import { LearningMilestone } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MilestoneShareCard } from "@/components/learning/milestone-share-card";

export function MilestoneSimulator() {
  const [selectedMilestone, setSelectedMilestone] = useState<LearningMilestone | null>(null);
  const [celebratedMilestones, setCelebratedMilestones] = useState<LearningMilestone[]>([]);
  
  // Demo milestone data
  const demoMilestones: LearningMilestone[] = [
    {
      id: 101,
      userId: 1,
      title: "Learning Streak: 7 Days",
      description: "You've been learning consistently for 7 days in a row!",
      achievedAt: new Date(),
      milestoneType: "streak",
      iconName: "fire",
      celebratedAt: null,
      isHidden: false,
      isShared: false,
      privacyLevel: null,
      shareUrl: null,
      socialPlatforms: []
    },
    {
      id: 102,
      userId: 1,
      title: "10 Articles Read",
      description: "You've read 10 articles across various topics. Keep expanding your knowledge!",
      achievedAt: new Date(),
      milestoneType: "content_count",
      iconName: "book",
      celebratedAt: null,
      isHidden: false,
      isShared: false,
      privacyLevel: null,
      shareUrl: null,
      socialPlatforms: []
    },
    {
      id: 103,
      userId: 1,
      title: "Python Master",
      description: "Completed more than 20 learning activities in Python with excellent quiz scores!",
      achievedAt: new Date(),
      milestoneType: "category_mastery",
      iconName: "award",
      celebratedAt: null,
      isHidden: false,
      isShared: false,
      privacyLevel: null,
      shareUrl: null,
      socialPlatforms: []
    },
    {
      id: 104,
      userId: 1,
      title: "10 Hour Learning Journey",
      description: "You've spent 10 hours learning new skills. Your dedication is impressive!",
      achievedAt: new Date(),
      milestoneType: "time",
      iconName: "clock",
      celebratedAt: null,
      isHidden: false,
      isShared: false,
      privacyLevel: null,
      shareUrl: null,
      socialPlatforms: []
    },
    {
      id: 105,
      userId: 1,
      title: "Quiz Champion",
      description: "Scored 90%+ on 5 consecutive learning quizzes. Your retention is exceptional!",
      achievedAt: new Date(),
      milestoneType: "quiz_score",
      iconName: "quiz",
      celebratedAt: null,
      isHidden: false,
      isShared: false,
      privacyLevel: null,
      shareUrl: null,
      socialPlatforms: []
    }
  ];

  const handleMilestoneClick = (milestone: LearningMilestone) => {
    setSelectedMilestone(milestone);
  };

  const handleMilestoneCelebrated = (milestone: LearningMilestone) => {
    setCelebratedMilestones(prev => [...prev, milestone]);
  };

  const getIconBadge = (milestoneType: string) => {
    switch (milestoneType) {
      case "time":
        return <Badge className="bg-purple-500">Time</Badge>;
      case "content_count":
        return <Badge className="bg-amber-500">Content</Badge>;
      case "quiz_score":
        return <Badge className="bg-blue-500">Quiz</Badge>;
      case "streak":
        return <Badge className="bg-red-500">Streak</Badge>;
      case "category_mastery":
        return <Badge className="bg-green-500">Mastery</Badge>;
      default:
        return <Badge>Achievement</Badge>;
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Milestone Gallery</CardTitle>
          <CardDescription>
            Click on a milestone to trigger a celebration popup.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {demoMilestones.map(milestone => {
              const isCelebrated = celebratedMilestones.some(m => m.id === milestone.id);
              return (
                <div
                  key={milestone.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    isCelebrated ? 'bg-muted border-muted-foreground/20' : 'hover:bg-accent'
                  }`}
                  onClick={() => !isCelebrated && handleMilestoneClick(milestone)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium flex items-center gap-2">
                        {milestone.title}
                        {getIconBadge(milestone.milestoneType)}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {milestone.description}
                      </p>
                    </div>
                    {isCelebrated && (
                      <Badge variant="outline" className="ml-2 text-green-500 border-green-500">
                        Celebrated
                      </Badge>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Celebrated Milestones</CardTitle>
          <CardDescription>
            Milestones that have been celebrated will appear here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {celebratedMilestones.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="rounded-full bg-muted p-3 mb-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-muted-foreground"
                >
                  <path d="M12 2v8"></path>
                  <path d="m16 6-4 4-4-4"></path>
                  <rect width="20" height="8" x="2" y="14" rx="2"></rect>
                </svg>
              </div>
              <p className="text-sm text-muted-foreground">
                No milestones celebrated yet. Click on a milestone to celebrate it.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <Tabs defaultValue="list">
                <TabsList className="mb-4">
                  <TabsTrigger value="list">List View</TabsTrigger>
                  <TabsTrigger value="cards">Card View</TabsTrigger>
                </TabsList>
                
                <TabsContent value="list">
                  <div className="space-y-4">
                    {celebratedMilestones.map(milestone => (
                      <div
                        key={milestone.id}
                        className="border rounded-lg p-4 transition-colors"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium flex items-center gap-2">
                              {milestone.title}
                              {getIconBadge(milestone.milestoneType)}
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              {milestone.description}
                            </p>
                            {milestone.celebratedAt && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Celebrated on {new Date(milestone.celebratedAt).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="cards">
                  <div className="grid gap-4">
                    {celebratedMilestones.map(milestone => (
                      <MilestoneShareCard 
                        key={milestone.id} 
                        milestone={milestone} 
                        includeShareButton={true}
                      />
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </CardContent>
      </Card>
      
      {selectedMilestone && (
        <MilestoneCelebration 
          userId={1} 
          uncelebratedMilestones={[selectedMilestone]} 
          onMilestoneCelebrated={handleMilestoneCelebrated} 
        />
      )}
    </div>
  );
}