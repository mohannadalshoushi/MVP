import { CategoryProgress } from "@/lib/types";
import { Link } from "wouter";

interface LearningProgressProps {
  categories: CategoryProgress[];
  timeframe: string;
  onTimeframeChange: (timeframe: string) => void;
}

export function LearningProgress({ 
  categories,
  timeframe,
  onTimeframeChange
}: LearningProgressProps) {
  const timeframeOptions = [
    "Last 4 Weeks",
    "Last 3 Months",
    "Last Year",
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5 col-span-2">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Learning Progress by Category</h2>
        <select 
          className="text-sm border rounded p-1"
          value={timeframe}
          onChange={(e) => onTimeframeChange(e.target.value)}
        >
          {timeframeOptions.map(option => (
            <option key={option} value={option}>{option}</option>
          ))}
        </select>
      </div>
      
      {categories.map(category => (
        <div className="mb-4" key={category.id}>
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <span className="material-icons mr-2 text-sm" style={{ color: category.color }}>{category.icon}</span>
              <span className="text-sm font-medium">{category.name}</span>
            </div>
            <span className="text-sm text-gray-500">{category.hoursSpent} hours</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="h-2 rounded-full" 
              style={{ width: `${category.percentage}%`, backgroundColor: category.color }}
            ></div>
          </div>
        </div>
      ))}
      
      <Link href="/learning-history">
        <div className="text-primary text-sm font-medium flex items-center cursor-pointer">
          <span>View detailed breakdown</span>
          <span className="material-icons text-sm ml-1">arrow_forward</span>
        </div>
      </Link>
    </div>
  );
}
