import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Award, 
  BookOpen, 
  Clock, 
  FileQuestion, 
  Flame,
  X,
  Share2
} from "lucide-react";
import { Dialog, DialogContent, DialogClose, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { LearningMilestone } from "@/lib/types";
import { MilestoneSharing } from "./milestone-sharing";
import confetti from 'canvas-confetti';

interface MilestoneCelebrationProps {
  userId: number;
  uncelebratedMilestones?: LearningMilestone[];
  onMilestoneCelebrated?: (milestone: LearningMilestone) => void;
}

export function MilestoneCelebration({ 
  userId, 
  uncelebratedMilestones: propMilestones, 
  onMilestoneCelebrated 
}: MilestoneCelebrationProps) {
  const [uncelebratedMilestones, setUncelebratedMilestones] = useState<LearningMilestone[]>(propMilestones || []);
  const [currentMilestone, setCurrentMilestone] = useState<LearningMilestone | null>(null);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!propMilestones) {
      checkUncelebratedMilestones();
      
      // Check for new milestones every 5 minutes
      const intervalId = setInterval(() => {
        checkUncelebratedMilestones();
      }, 5 * 60 * 1000);
      
      return () => clearInterval(intervalId);
    }
  }, [userId, propMilestones]);

  useEffect(() => {
    if (propMilestones) {
      setUncelebratedMilestones(propMilestones);
    }
  }, [propMilestones]);

  useEffect(() => {
    if (uncelebratedMilestones.length > 0 && !currentMilestone) {
      // Show the first uncelebrated milestone
      setCurrentMilestone(uncelebratedMilestones[0]);
      setOpen(true);
    }
  }, [uncelebratedMilestones, currentMilestone]);

  useEffect(() => {
    if (open) {
      // Trigger confetti when the dialog opens
      const duration = 3 * 1000;
      const end = Date.now() + duration;

      (function frame() {
        confetti({
          particleCount: 2,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#6366F1']
        });
        
        confetti({
          particleCount: 2,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#6366F1']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      }());
    }
  }, [open]);

  const checkUncelebratedMilestones = async () => {
    try {
      // First, check for new milestones
      await fetch(`/api/learning-milestones/check/${userId}`, {
        method: 'POST'
      });
      
      // Then, fetch uncelebrated milestones
      const response = await fetch(`/api/learning-milestones/uncelebrated/${userId}`);
      if (response.ok) {
        const data = await response.json();
        setUncelebratedMilestones(data);
      }
    } catch (error) {
      console.error("Failed to check for uncelebrated milestones:", error);
    }
  };

  const handleCelebrate = async () => {
    if (!currentMilestone) return;
    
    try {
      setLoading(true);
      
      // If we're using simulated milestones from props, don't make the API call
      if (propMilestones) {
        // Just update the milestone locally with a celebrated date
        const celebratedMilestone = {
          ...currentMilestone,
          celebratedAt: new Date()
        };
        
        // Remove the celebrated milestone from the list
        setUncelebratedMilestones(prev => 
          prev.filter(m => m.id !== currentMilestone.id)
        );
        
        // Notify the parent component if needed
        if (onMilestoneCelebrated) {
          onMilestoneCelebrated(celebratedMilestone);
        }
        
        // Close the dialog after a brief delay to show confetti
        setTimeout(() => {
          setOpen(false);
          setCurrentMilestone(null);
        }, 500);
        
        return;
      }
      
      // Otherwise, if we're using real milestones from the API, make the API call
      const response = await fetch(`/api/learning-milestones/celebrate/${currentMilestone.id}`, {
        method: 'POST'
      });
      
      if (response.ok) {
        const celebratedMilestone = await response.json();
        
        // Remove the celebrated milestone from the list
        setUncelebratedMilestones(prev => 
          prev.filter(m => m.id !== currentMilestone.id)
        );
        
        // Notify the parent component if needed
        if (onMilestoneCelebrated) {
          onMilestoneCelebrated(celebratedMilestone);
        }
        
        // Close the dialog
        setOpen(false);
        setCurrentMilestone(null);
      }
    } catch (error) {
      console.error("Failed to celebrate milestone:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setOpen(false);
    setCurrentMilestone(null);
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "award":
      case "emoji_events":
        return <Award className="h-16 w-16" />;
      case "book":
      case "menu_book":
        return <BookOpen className="h-16 w-16" />;
      case "clock":
      case "schedule":
        return <Clock className="h-16 w-16" />;
      case "quiz":
      case "question_mark":
        return <FileQuestion className="h-16 w-16" />;
      case "fire":
      case "local_fire_department":
        return <Flame className="h-16 w-16" />;
      default:
        return <Award className="h-16 w-16" />;
    }
  };
  
  const getIconColorClass = (milestoneType: string) => {
    switch (milestoneType) {
      case "time":
        return "text-purple-500";
      case "content_count":
        return "text-amber-500";
      case "quiz_score":
        return "text-blue-500";
      case "streak":
        return "text-red-500";
      case "category_mastery":
        return "text-green-500";
      default:
        return "text-primary";
    }
  };

  return (
    <AnimatePresence>
      {open && currentMilestone && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl text-center">
                🎉 Milestone Achieved! 🎉
              </DialogTitle>
              <DialogClose 
                asChild 
                className="absolute right-4 top-4 opacity-70 hover:opacity-100"
                onClick={handleClose}
              >
                <Button variant="ghost" size="icon">
                  <X className="h-4 w-4" />
                </Button>
              </DialogClose>
            </DialogHeader>
            
            <div className="flex flex-col items-center text-center py-6 gap-4">
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{ 
                  type: "spring", 
                  stiffness: 260, 
                  damping: 20,
                  duration: 1 
                }}
                className={`p-6 rounded-full bg-background border-4 border-primary ${getIconColorClass(currentMilestone.milestoneType)}`}
              >
                {getIcon(currentMilestone.iconName)}
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <h3 className="text-xl font-bold tracking-tight mb-2">{currentMilestone.title}</h3>
                <p className="text-muted-foreground">{currentMilestone.description}</p>
              </motion.div>
            </div>
            
            <DialogFooter className="sm:justify-center gap-2 mt-2">
              <Button 
                variant="outline" 
                onClick={handleClose}
                disabled={loading}
              >
                Maybe Later
              </Button>
              <Button 
                onClick={handleCelebrate}
                disabled={loading}
                className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
              >
                {loading ? "Celebrating..." : "Celebrate Achievement!"}
              </Button>
              
              {currentMilestone.celebratedAt && (
                <MilestoneSharing milestone={currentMilestone} />
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  );
}