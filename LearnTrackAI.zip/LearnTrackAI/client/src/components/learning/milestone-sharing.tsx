import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Copy, Share, Twitter, Linkedin, Facebook } from "lucide-react";
import { LearningMilestone } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MilestoneSharingProps {
  milestone: LearningMilestone;
}

export function MilestoneSharing({ milestone }: MilestoneSharingProps) {
  const [privacyLevel, setPrivacyLevel] = useState<string>(milestone.privacyLevel || "private");
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isShared, setIsShared] = useState<boolean>(milestone.isShared || false);
  const { toast } = useToast();
  
  // In a real app, these would be API calls instead of simulated settings
  const handleShareClick = async () => {
    try {
      setIsSaving(true);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Update the milestone state locally (in a real app, this would be a state update after API response)
      setIsShared(true);
      
      toast({
        title: "Milestone shared!",
        description: `Your milestone is now visible to ${privacyLevel === "public" ? "everyone" : "your connections"}.`,
      });
    } catch (error) {
      toast({
        title: "Failed to share milestone",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handlePrivacyChange = (value: string) => {
    setPrivacyLevel(value);
  };
  
  const generateSocialShareUrl = (platform: string, milestone: LearningMilestone) => {
    const shareableUrl = `https://learnfy.ai/share/${milestone.shareUrl || 'demo-milestone'}`;
    const text = encodeURIComponent(`I just achieved "${milestone.title}" on my learning journey with Learnfy.AI! 🎓`);
    
    switch (platform) {
      case "twitter":
        return `https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(shareableUrl)}`;
      case "linkedin":
        return `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareableUrl)}`;
      case "facebook":
        return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareableUrl)}`;
      default:
        return shareableUrl;
    }
  };
  
  const shareToSocialMedia = (platform: string) => {
    const url = generateSocialShareUrl(platform, milestone);
    window.open(url, '_blank', 'width=600,height=400');
  };
  
  const copyShareableLink = () => {
    const shareableUrl = `https://learnfy.ai/share/${milestone.shareUrl || 'demo-milestone'}`;
    navigator.clipboard.writeText(shareableUrl);
    toast({
      title: "URL copied!",
      description: "Shareable URL has been copied to your clipboard.",
    });
  };

  return (
    <div className="flex flex-wrap gap-2">
      {!isShared ? (
        <>
          <Select value={privacyLevel} onValueChange={handlePrivacyChange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Privacy level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="private">Private</SelectItem>
              <SelectItem value="connections">Connections</SelectItem>
              <SelectItem value="public">Public</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleShareClick} disabled={isSaving}>
            {isSaving ? "Saving..." : "Share Achievement"}
          </Button>
        </>
      ) : (
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareToSocialMedia("twitter")}
            className="flex items-center gap-1 bg-[#1DA1F2] text-white hover:bg-[#1a94da]"
          >
            <Twitter className="h-4 w-4" />
            <span className="md:inline hidden">Twitter</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareToSocialMedia("linkedin")}
            className="flex items-center gap-1 bg-[#0A66C2] text-white hover:bg-[#095196]"
          >
            <Linkedin className="h-4 w-4" />
            <span className="md:inline hidden">LinkedIn</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareToSocialMedia("facebook")}
            className="flex items-center gap-1 bg-[#1877F2] text-white hover:bg-[#1668d1]"
          >
            <Facebook className="h-4 w-4" />
            <span className="md:inline hidden">Facebook</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={copyShareableLink}
            className="flex items-center gap-1"
          >
            <Copy className="h-4 w-4" />
            <span className="md:inline hidden">Copy Link</span>
          </Button>
        </>
      )}
    </div>
  );
}