import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ToolUsageChart as ToolUsageChartType } from "@/lib/types";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ToolUsageChartProps {
  toolUsages: ToolUsageChartType[];
  timeframe: string;
  onTimeframeChange: (timeframe: string) => void;
}

export function ToolUsageChart({ toolUsages, timeframe, onTimeframeChange }: ToolUsageChartProps) {
  // Format data for the BarChart
  const chartData = [...toolUsages].sort((a, b) => b.hoursSpent - a.hoursSpent);
  
  // Format hours for tooltip and axis
  const formatHours = (hours: number) => {
    if (hours < 1) {
      return `${Math.round(hours * 60)} min`;
    }
    return `${hours.toFixed(1)} hrs`;
  };

  return (
    <Card className="col-span-3">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle>Tool Usage</CardTitle>
          <CardDescription>
            Time spent using professional tools
          </CardDescription>
        </div>
        <Select
          value={timeframe}
          onValueChange={onTimeframeChange}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="Timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">7 days</SelectItem>
            <SelectItem value="30days">30 days</SelectItem>
            <SelectItem value="90days">90 days</SelectItem>
            <SelectItem value="all">All time</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
              <XAxis 
                type="number" 
                tickFormatter={formatHours}
                domain={[0, 'dataMax']}
              />
              <YAxis 
                type="category" 
                dataKey="toolName" 
                width={100}
                tick={{ fontSize: 12 }}
              />
              <Tooltip 
                formatter={(value: number) => [formatHours(value), "Time Spent"]}
                labelFormatter={(label: string) => `Tool: ${label}`}
                cursor={{ fill: 'rgba(0, 0, 0, 0.1)' }}
              />
              <Bar dataKey="hoursSpent" radius={[0, 4, 4, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color || "#8884d8"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}