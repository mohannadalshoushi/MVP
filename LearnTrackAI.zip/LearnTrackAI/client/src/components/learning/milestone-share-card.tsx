import React, { useState } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Award, BookOpen, Clock, FileQuestion, Flame, Share2 } from "lucide-react";
import { LearningMilestone } from "@/lib/types";
import { formatMilestoneDate } from "@/lib/milestone-utils";
import { Badge } from "@/components/ui/badge";
import { MilestoneSharing } from "./milestone-sharing";
import { useToast } from "@/hooks/use-toast";

interface MilestoneShareCardProps {
  milestone: LearningMilestone;
  includeShareButton?: boolean;
}

export function MilestoneShareCard({ milestone, includeShareButton = false }: MilestoneShareCardProps) {
  const [showSharingOptions, setShowSharingOptions] = useState(false);
  const { toast } = useToast();
  
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "award":
      case "emoji_events":
        return <Award className="h-10 w-10" />;
      case "book":
      case "menu_book":
        return <BookOpen className="h-10 w-10" />;
      case "clock":
      case "schedule":
        return <Clock className="h-10 w-10" />;
      case "quiz":
      case "question_mark":
        return <FileQuestion className="h-10 w-10" />;
      case "fire":
      case "local_fire_department":
        return <Flame className="h-10 w-10" />;
      default:
        return <Award className="h-10 w-10" />;
    }
  };
  
  const getIconColorClass = (milestoneType: string) => {
    switch (milestoneType) {
      case "time":
        return "text-purple-500";
      case "content_count":
        return "text-amber-500";
      case "quiz_score":
        return "text-blue-500";
      case "streak":
        return "text-red-500";
      case "category_mastery":
        return "text-green-500";
      default:
        return "text-primary";
    }
  };
  
  const copyShareUrl = () => {
    if (milestone.shareUrl) {
      const shareableUrl = `https://learnfy.ai/share/${milestone.shareUrl}`;
      navigator.clipboard.writeText(shareableUrl);
      toast({
        title: "URL copied!",
        description: "Shareable URL has been copied to your clipboard.",
      });
    } else {
      toast({
        title: "Share milestone first",
        description: "Set sharing options for this milestone to get a shareable URL.",
        variant: "destructive",
      });
    }
  };
  
  const handleShare = () => {
    setShowSharingOptions(!showSharingOptions);
  };

  return (
    <Card className="overflow-hidden border shadow-sm">
      <div className="flex border-b p-4">
        <div className={`mr-4 rounded-full p-2 ${getIconColorClass(milestone.milestoneType)} bg-background/10`}>
          {getIcon(milestone.iconName)}
        </div>
        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">{milestone.title}</h3>
            {milestone.privacyLevel && (
              <Badge variant="outline" className="ml-2">
                {milestone.privacyLevel.charAt(0).toUpperCase() + milestone.privacyLevel.slice(1)}
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">{milestone.description}</p>
          <p className="text-xs text-muted-foreground">
            Achieved on {formatMilestoneDate(milestone.achievedAt)}
          </p>
        </div>
      </div>
      
      <CardContent className="p-4 pt-3">
        <div className="flex flex-col gap-2">
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
            <span className="text-sm">From <span className="font-medium">Learnfy.AI</span> - Your Personal Learning Assistant</span>
          </div>
          {milestone.privacyLevel && (
            <div className="flex items-center">
              <div className="h-2 w-2 rounded-full bg-blue-500 mr-2"></div>
              <span className="text-sm">Visibility: <span className="font-medium">{milestone.privacyLevel.charAt(0).toUpperCase() + milestone.privacyLevel.slice(1)}</span></span>
            </div>
          )}
        </div>
      </CardContent>
      
      {(includeShareButton || showSharingOptions) && (
        <CardFooter className="flex justify-end gap-2 border-t p-4">
          {showSharingOptions ? (
            <MilestoneSharing milestone={milestone} />
          ) : (
            <>
              {milestone.shareUrl && (
                <Button variant="outline" size="sm" onClick={copyShareUrl}>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy URL
                </Button>
              )}
              <Button variant="default" size="sm" onClick={handleShare} className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </>
          )}
        </CardFooter>
      )}
    </Card>
  );
}