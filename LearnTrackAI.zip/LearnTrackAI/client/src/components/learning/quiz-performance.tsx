import { QuizPerformance as QuizPerformanceType } from "@/lib/types";

interface QuizPerformanceProps {
  performance: QuizPerformanceType;
}

export function QuizPerformance({ performance }: QuizPerformanceProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Quiz Performance</h2>
      <div className="relative pt-5">
        <div className="flex justify-center">
          <div className="relative w-36 h-36">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-28 h-28 rounded-full border-8 border-primary bg-white flex items-center justify-center">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900">{performance.accuracy}%</p>
                  <p className="text-xs text-gray-500">Accuracy</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-6 space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-sm">Correct</span>
            </div>
            <span className="text-sm font-medium">{performance.correct}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-red-400 mr-2"></div>
              <span className="text-sm">Incorrect</span>
            </div>
            <span className="text-sm font-medium">{performance.incorrect}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-300 mr-2"></div>
              <span className="text-sm">Skipped</span>
            </div>
            <span className="text-sm font-medium">{performance.skipped}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
