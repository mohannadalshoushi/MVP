interface StatsCardProps {
  title: string;
  value: string | number;
  change: string;
  icon: string;
  iconColor: string;
}

export function StatsCard({ title, value, change, icon, iconColor }: StatsCardProps) {
  return (
    <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
        <span className="material-icons" style={{ color: iconColor }}>{icon}</span>
      </div>
      <p className="text-2xl font-semibold">{value}</p>
      <p className="text-xs text-green-500 flex items-center">
        <span className="material-icons text-xs mr-1">arrow_upward</span>
        <span>{change}</span>
      </p>
    </div>
  );
}
