interface ExtensionPopupProps {
  currentContent: {
    title: string;
    source: string;
    timeElapsed: string;
  };
  category: {
    name: string;
    color: string;
  };
  isTracking: boolean;
  onPauseTracking: () => void;
  onResumeTracking: () => void;
  onAddNote: () => void;
  onChangeCategory: () => void;
}

export function ExtensionPopup({
  currentContent,
  category,
  isTracking,
  onPauseTracking,
  onResumeTracking,
  onAddNote,
  onChangeCategory
}: ExtensionPopupProps) {
  return (
    <div className="bg-white shadow-lg rounded-lg w-80 border border-gray-200 overflow-hidden">
      <div className="p-3 bg-primary text-white flex justify-between items-center">
        <div className="flex items-center">
          <span className="material-icons mr-2">school</span>
          <h3 className="font-medium">LearnTrack AI</h3>
        </div>
        <button className="focus:outline-none">
          <span className="material-icons text-white">close</span>
        </button>
      </div>
      <div className="p-4">
        <div className="mb-4">
          <p className="text-sm text-gray-700 mb-2">Currently tracking:</p>
          <div className="flex items-center">
            <span className="material-icons text-accent mr-2">
              {currentContent.title.includes('video') ? 'play_circle' : 'article'}
            </span>
            <div>
              <p className="text-sm font-medium">{currentContent.title}</p>
              <p className="text-xs text-gray-500">{currentContent.source} • {currentContent.timeElapsed} elapsed</p>
            </div>
          </div>
        </div>
        <div className="mb-4">
          <p className="text-sm text-gray-700 mb-2">Category:</p>
          <div className="flex">
            <span 
              className="px-2 py-1 text-xs rounded-full mr-2"
              style={{ 
                backgroundColor: `${category.color}25`, 
                color: category.color 
              }}
            >
              {category.name}
            </span>
            <button 
              className="text-xs text-primary"
              onClick={onChangeCategory}
            >
              Change
            </button>
          </div>
        </div>
        <div className="border-t pt-4 mt-4">
          <div className="flex justify-between mb-4">
            <button 
              className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100"
              onClick={isTracking ? onPauseTracking : onResumeTracking}
            >
              {isTracking ? "Pause Tracking" : "Resume Tracking"}
            </button>
            <button 
              className="px-3 py-1 bg-secondary text-white rounded text-sm hover:bg-green-600"
              onClick={onAddNote}
            >
              Add Note
            </button>
          </div>
          <p className="text-xs text-gray-500 text-center">A quiz will be generated when you finish this content</p>
        </div>
      </div>
    </div>
  );
}
