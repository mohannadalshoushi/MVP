import { Sidebar } from "./sidebar";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

interface AppLayoutProps {
  children: React.ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();
  const [location] = useLocation();
  
  // Don't render layout for auth page or shared milestone pages
  if (location === "/auth" || location.startsWith("/share/")) {
    return <>{children}</>;
  }
  
  // No layout for unauthenticated users
  if (!user) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen">
      {/* Desktop Sidebar */}
      <div className="w-64 bg-white shadow-md hidden md:block">
        <Sidebar user={user} />
      </div>

      {/* Mobile Sidebar (overlay) */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div 
            className="fixed inset-0 bg-black/50" 
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed w-64 top-0 bottom-0 left-0 bg-white shadow-lg">
            <Sidebar user={user} mobile onClose={() => setSidebarOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Mobile Header */}
        <div className="md:hidden bg-white p-4 shadow flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="material-icons text-white text-xl">school</span>
            </div>
            <h1 className="text-lg font-semibold text-gray-900">Learnfy.AI</h1>
          </div>
          <button 
            className="text-gray-500 focus:outline-none" 
            onClick={() => setSidebarOpen(true)}
          >
            <span className="material-icons">menu</span>
          </button>
        </div>

        {/* Page Content */}
        {children}
      </div>
    </div>
  );
}
