import { Link, useLocation } from "wouter";
import { User } from "@/lib/types";
import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  user: User;
  mobile?: boolean;
  onClose?: () => void;
}

export function Sidebar({ user, mobile, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  // Get link to Google Fonts for Material Icons
  useEffect(() => {
    if (typeof document !== 'undefined') {
      // Check if Material Icons is already loaded
      if (!document.querySelector('link[href="https://fonts.googleapis.com/icon?family=Material+Icons"]')) {
        const link = document.createElement('link');
        link.href = "https://fonts.googleapis.com/icon?family=Material+Icons";
        link.rel = "stylesheet";
        document.head.appendChild(link);
      }
      
      // Load voice control and accessibility scripts for the dashboard (if not already loaded)
      const scriptIds = ['voice-control-script', 'voice-commands-script', 'accessibility-panel-script', 'init-voice-script'];
      
      if (!document.getElementById(scriptIds[0])) {
        const voiceControlScript = document.createElement('script');
        voiceControlScript.id = scriptIds[0];
        voiceControlScript.src = "/voice-control.js";
        voiceControlScript.async = true;
        document.body.appendChild(voiceControlScript);
      }
      
      if (!document.getElementById(scriptIds[1])) {
        const voiceCommandsScript = document.createElement('script');
        voiceCommandsScript.id = scriptIds[1];
        voiceCommandsScript.src = "/voice-commands.js";
        voiceCommandsScript.async = true;
        document.body.appendChild(voiceCommandsScript);
      }
      
      if (!document.getElementById(scriptIds[2])) {
        const accessibilityScript = document.createElement('script');
        accessibilityScript.id = scriptIds[2];
        accessibilityScript.src = "/accessibility-panel.js";
        accessibilityScript.async = true;
        document.body.appendChild(accessibilityScript);
      }
      
      if (!document.getElementById(scriptIds[3])) {
        // Script to initialize voice control and accessibility panel
        const initScript = document.createElement('script');
        initScript.id = scriptIds[3];
        initScript.textContent = `
          document.addEventListener('DOMContentLoaded', () => {
            // Wait for voice-control.js to load
            setTimeout(() => {
              if (typeof voiceControl !== 'undefined' && 
                  !window.voiceCommandsInitialized && 
                  !window.accessibilityPanelInitialized) {
                // Set flags to prevent multiple initializations
                window.voiceCommandsInitialized = true;
                window.accessibilityPanelInitialized = true;
                
                // Initialize voice command handler
                const voiceCommands = new VoiceCommandHandler(voiceControl);
                
                // Initialize accessibility panel
                const accessibilityPanel = new AccessibilityPanel(voiceControl);
              }
            }, 1000);
          });
        `;
        document.body.appendChild(initScript);
      }
    }
  }, []);

  // Define nav item interface for type safety
  interface NavItem {
    path: string;
    icon: string;
    label: string;
  }
  
  // Organize navigation items into categories for better UX
  const dashboardItems: NavItem[] = [
    { path: "/", icon: "dashboard", label: "Dashboard" },
    { path: "/learning-history", icon: "history", label: "Learning History" },
    { path: "/knowledge-base", icon: "topic", label: "Knowledge Base" },
  ];
  
  const profileItems: NavItem[] = [
    { path: "/live-cv", icon: "badge", label: "Live CV" },
    { path: "/certifications", icon: "card_membership", label: "Certifications" },
    { path: "/language-skills", icon: "translate", label: "Language Skills" },
  ];
  
  const communityItems: NavItem[] = [
    { path: "/community", icon: "people", label: "Community" },
    { path: "/achievement-milestones", icon: "emoji_events", label: "Achievement Milestones" },
  ];
  
  // Define accessibility item interface for type safety
  interface AccessibilityItem {
    id: string;
    icon: string;
    label: string;
    action: () => void;
  }
  
  const accessibilityItems: AccessibilityItem[] = [
    { 
      id: "voice-control", 
      icon: "mic", 
      label: "Voice Control",
      action: () => {
        if (typeof window !== 'undefined' && (window as any).voiceControl) {
          (window as any).voiceControl.toggle();
        }
      }
    },
    { 
      id: "accessibility", 
      icon: "accessibility_new", 
      label: "Accessibility Settings",
      action: () => {
        const accessibilityBtn = document.getElementById('accessibility-btn');
        if (accessibilityBtn) {
          accessibilityBtn.click();
        }
      }
    }
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <div className="flex items-center space-x-2">
          {mobile && (
            <button 
              className="text-gray-500 mr-2" 
              onClick={onClose}
            >
              <span className="material-icons">close</span>
            </button>
          )}
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="material-icons text-white text-xl">school</span>
          </div>
          <h1 className="text-lg font-semibold text-gray-900">Learnfy.AI</h1>
        </div>
      </div>
      <nav className="p-2 flex-1">
        {/* Dashboard section */}
        <div className="mb-6">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Dashboard
          </h3>
          <ul>
            {dashboardItems.map((item) => (
              <li className="mb-1" key={item.path}>
                <Link href={item.path}>
                  <div 
                    className={`flex items-center p-3 rounded-lg cursor-pointer ${
                      location === item.path 
                        ? "text-primary bg-blue-50" 
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                    onClick={mobile ? onClose : undefined}
                  >
                    <span className="material-icons mr-3">{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Professional Profile section */}
        <div className="mb-6">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Professional Profile
          </h3>
          <ul>
            {profileItems.map((item) => (
              <li className="mb-1" key={item.path}>
                <Link href={item.path}>
                  <div 
                    className={`flex items-center p-3 rounded-lg cursor-pointer ${
                      location === item.path 
                        ? "text-primary bg-blue-50" 
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                    onClick={mobile ? onClose : undefined}
                  >
                    <span className="material-icons mr-3">{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Community section */}
        <div className="mb-6">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Community
          </h3>
          <ul>
            {communityItems.map((item) => (
              <li className="mb-1" key={item.path}>
                <Link href={item.path}>
                  <div 
                    className={`flex items-center p-3 rounded-lg cursor-pointer ${
                      location === item.path 
                        ? "text-primary bg-blue-50" 
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                    onClick={mobile ? onClose : undefined}
                  >
                    <span className="material-icons mr-3">{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Accessibility section */}
        <div className="mb-6">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Accessibility
          </h3>
          <ul>
            {accessibilityItems.map((item) => (
              <li className="mb-1" key={item.id}>
                <button
                  className="flex items-center p-3 rounded-lg cursor-pointer w-full text-left text-gray-600 hover:bg-gray-100"
                  onClick={() => {
                    if (mobile && onClose) onClose();
                    item.action();
                  }}
                >
                  <span className="material-icons mr-3">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Settings section */}
        <div>
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Settings
          </h3>
          <ul>
            <li className="mb-1">
              <Link href="/settings">
                <div
                  className={`flex items-center p-3 rounded-lg cursor-pointer ${
                    location === "/settings"
                      ? "text-primary bg-blue-50"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                  onClick={mobile ? onClose : undefined}
                >
                  <span className="material-icons mr-3">settings</span>
                  <span>Settings</span>
                </div>
              </Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="p-4 border-t mt-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
              <span className="material-icons text-gray-600">person</span>
            </div>
            <div>
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-gray-500">{user.username}</p>
            </div>
          </div>
          <button 
            onClick={(e) => {
              e.preventDefault();
              if (mobile && onClose) onClose();
              // Call the logout mutation from useAuth
              logoutMutation.mutate();
            }}
            className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg"
            title="Logout"
            aria-label="Logout"
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? (
              <span className="material-icons animate-spin">sync</span>
            ) : (
              <span className="material-icons">logout</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
