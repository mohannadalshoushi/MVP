import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertLanguageSkillSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { LanguageSkill } from "@/lib/types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Extend the language skill schema with validation
const formSchema = insertLanguageSkillSchema.extend({
  language: z.string().min(2, {
    message: "Language name is required",
  }),
  proficiencyLevel: z.string().optional().nullable(),
});

type FormValues = z.infer<typeof formSchema>;

interface LanguageSkillFormProps {
  userId: number;
  languageSkill?: LanguageSkill; // For edit mode
  onClose: () => void;
}

export function LanguageSkillForm({ userId, languageSkill, onClose }: LanguageSkillFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditMode = !!languageSkill;

  // Proficiency levels
  const proficiencyLevels = [
    "Beginner",
    "Elementary",
    "Intermediate",
    "Upper Intermediate",
    "Advanced",
    "Proficient",
    "Native"
  ];

  // Default values
  const defaultValues: Partial<FormValues> = {
    userId,
    language: languageSkill?.language || "",
    proficiencyLevel: languageSkill?.proficiencyLevel || null,
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  // Mutation for creating/updating language skill
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      // For a new language skill, we need to set initial reading/listening time to 0
      const dataToSend = {
        ...data,
        // Preserve existing times when updating, set to 0 when creating new
        readingTimeSpent: isEditMode ? languageSkill?.readingTimeSpent : 0,
        listeningTimeSpent: isEditMode ? languageSkill?.listeningTimeSpent : 0,
        lastActivity: isEditMode ? languageSkill?.lastActivity : new Date()
      };
      
      const url = isEditMode
        ? `/api/language-skills/${languageSkill.id}`
        : "/api/language-skills";
      
      const method = isEditMode ? "PUT" : "POST";
      
      const res = await apiRequest(method, url, dataToSend);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/language-skills', userId] });
      toast({
        title: isEditMode ? "Language Skill Updated" : "Language Skill Added",
        description: isEditMode 
          ? "Your language skill has been updated successfully" 
          : "Your language skill has been added to your profile",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: isEditMode 
          ? "Failed to update language skill. Please try again." 
          : "Failed to add language skill. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    // Ensure language is lowercase for consistency
    data.language = data.language.toLowerCase();
    mutation.mutate(data);
  };

  return (
    <Card className="w-full max-w-lg">
      <CardHeader className="relative">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute right-2 top-2" 
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        <CardTitle>{isEditMode ? "Edit Language Skill" : "Add Language Skill"}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="language"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Language*</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. French, Spanish, German" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="proficiencyLevel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Proficiency Level</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value || undefined}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your proficiency level" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {proficiencyLevels.map((level) => (
                        <SelectItem key={level} value={level}>
                          {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="mt-2 mb-2 p-3 bg-blue-50 rounded-md border border-blue-100 text-sm text-blue-700">
              <p className="flex items-center">
                <span className="flex-shrink-0 mr-2">ℹ️</span>
                <span>
                  Language reading and listening time is tracked automatically as you browse content in different languages.
                </span>
              </p>
            </div>
            
            <CardFooter className="px-0 pt-4">
              <div className="flex justify-end gap-2 w-full">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? "Saving..." : isEditMode ? "Update" : "Add"}
                </Button>
              </div>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}