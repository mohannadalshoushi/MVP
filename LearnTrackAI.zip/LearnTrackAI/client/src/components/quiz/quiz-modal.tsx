import { QuizQuestion } from "@/lib/types";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  contentTitle: string;
  questions: QuizQuestion[];
  activityId: number;
  onQuizComplete: (score: number) => void;
}

export function QuizModal({ 
  isOpen, 
  onClose, 
  contentTitle, 
  questions, 
  activityId,
  onQuizComplete 
}: QuizModalProps) {
  const [answers, setAnswers] = useState<number[]>(new Array(questions.length).fill(-1));
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleAnswerSelect = (questionIndex: number, optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[questionIndex] = optionIndex;
    setAnswers(newAnswers);
  };

  const handleSkip = () => {
    onClose();
  };

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      
      // Submit answers to API
      const response = await apiRequest("POST", "/api/evaluate-quiz", {
        questionIds: questions.map(q => q.id),
        userAnswers: answers,
        activityId
      });
      
      const result = await response.json();
      
      // Call the onQuizComplete callback with the score
      onQuizComplete(result.score);
      onClose();
    } catch (error) {
      console.error("Error submitting quiz:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md mx-4 max-h-[90vh] overflow-auto">
        <div className="p-5 border-b flex justify-between items-center bg-primary text-white rounded-t-lg">
          <h3 className="text-xl font-medium">Quick Knowledge Check</h3>
          <button className="focus:outline-none" onClick={onClose}>
            <span className="material-icons">close</span>
          </button>
        </div>
        <div className="p-5">
          <p className="mb-4 text-gray-600">Let's check what you've learned from "{contentTitle}"</p>
          
          {questions.map((question, questionIndex) => (
            <div key={question.id} className={`mb-6 ${questionIndex < questions.length - 1 ? 'pb-6 border-b' : ''}`}>
              <h4 className="font-medium mb-3">{questionIndex + 1}. {question.question}</h4>
              <div className="space-y-2">
                {question.options.map((option, optionIndex) => (
                  <label 
                    key={optionIndex} 
                    className="flex items-center p-3 border rounded hover:bg-gray-50 cursor-pointer"
                  >
                    <input 
                      type="radio" 
                      name={`q${questionIndex}`} 
                      className="mr-3"
                      checked={answers[questionIndex] === optionIndex}
                      onChange={() => handleAnswerSelect(questionIndex, optionIndex)}
                    />
                    <span>{option}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="p-5 border-t bg-gray-50 flex justify-between rounded-b-lg">
          <button 
            className="px-4 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
            onClick={handleSkip}
            disabled={isSubmitting}
          >
            Skip
          </button>
          <button 
            className="px-4 py-2 bg-primary text-white rounded hover:bg-blue-600 disabled:opacity-50"
            onClick={handleSubmit}
            disabled={isSubmitting || !answers.some(a => a !== -1)}
          >
            {isSubmitting ? "Submitting..." : "Submit Quiz"}
          </button>
        </div>
      </div>
    </div>
  );
}
