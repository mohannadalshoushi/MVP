import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertCertificationSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Certification } from "@/lib/types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";

// Extend the certification schema with validation
const formSchema = insertCertificationSchema.extend({
  issueDate: z.date({
    required_error: "Issue date is required",
  }),
  expiryDate: z.date().nullable().optional(),
  credentialID: z.string().optional(),
  credentialURL: z.string().optional(),
  description: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface CertificationFormProps {
  userId: number;
  certification?: Certification; // For edit mode
  onClose: () => void;
}

export function CertificationForm({ userId, certification, onClose }: CertificationFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditMode = !!certification;
  const [showExpiryDate, setShowExpiryDate] = useState<boolean>(
    isEditMode ? !!certification.expiryDate : false
  );

  // Transform dates for the form
  const defaultValues: Partial<FormValues> = {
    userId,
    name: certification?.name || "",
    issuingOrganization: certification?.issuingOrganization || "",
    issueDate: certification?.issueDate ? new Date(certification.issueDate) : new Date(),
    expiryDate: certification?.expiryDate ? new Date(certification.expiryDate) : null,
    credentialID: certification?.credentialID || "",
    credentialURL: certification?.credentialURL || "",
    description: certification?.description || "",
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  // Mutation for creating/updating certification
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const url = isEditMode
        ? `/api/certifications/${certification.id}`
        : "/api/certifications";
      
      const method = isEditMode ? "PUT" : "POST";
      
      const res = await apiRequest(method, url, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/certifications', userId] });
      toast({
        title: isEditMode ? "Certification Updated" : "Certification Added",
        description: isEditMode 
          ? "Your certification has been updated successfully" 
          : "Your certification has been added to your profile",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: isEditMode 
          ? "Failed to update certification. Please try again." 
          : "Failed to add certification. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    // If showExpiryDate is false, ensure expiryDate is null
    if (!showExpiryDate) {
      data.expiryDate = null;
    }
    
    mutation.mutate(data);
  };

  return (
    <Card className="w-full max-w-lg">
      <CardHeader className="relative">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute right-2 top-2" 
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        <CardTitle>{isEditMode ? "Edit Certification" : "Add Certification"}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Certification Name*</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Project Management Professional (PMP)" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="issuingOrganization"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Issuing Organization*</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Project Management Institute" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="issueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Issue Date*</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <FormLabel>Expiry Date</FormLabel>
                  <div className="flex items-center space-x-2">
                    <Switch 
                      checked={showExpiryDate} 
                      onCheckedChange={setShowExpiryDate} 
                      id="expiry-switch"
                    />
                    <label 
                      htmlFor="expiry-switch" 
                      className="text-sm text-gray-500 cursor-pointer"
                    >
                      {showExpiryDate ? "Has expiry" : "No expiry"}
                    </label>
                  </div>
                </div>
                
                {showExpiryDate && (
                  <FormField
                    control={form.control}
                    name="expiryDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className={cn(
                                  "pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="credentialID"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credential ID</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g. ABC123456789" 
                        {...field} 
                        value={field.value as string} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="credentialURL"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credential URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g. https://credential.verify.com/abc123" 
                        {...field} 
                        value={field.value as string}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Briefly describe what this certification covers" 
                      className="resize-none"
                      {...field} 
                      value={field.value as string}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <CardFooter className="px-0 pt-4">
              <div className="flex justify-end gap-2 w-full">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? "Saving..." : isEditMode ? "Update" : "Add"}
                </Button>
              </div>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}