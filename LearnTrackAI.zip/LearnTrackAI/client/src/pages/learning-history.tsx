import { useState, useEffect } from "react";
import { RecentActivities } from "@/components/learning/recent-activities";
import { RecentActivity } from "@/lib/types";

export default function LearningHistory() {
  const [isLoading, setIsLoading] = useState(true);
  const [activities, setActivities] = useState<RecentActivity[]>([]);
  const [filter, setFilter] = useState("all");
  const [dateRange, setDateRange] = useState("all-time");

  // Simulated data loading
  useEffect(() => {
    // Simulate API call delay
    const timer = setTimeout(() => {
      // This would be fetched from the API in a real app
      setActivities([
        {
          id: 1,
          userId: 1,
          title: "Content Marketing Strategies for 2023",
          url: "https://blog.marketingpro.com/strategies-2023",
          source: "blog.marketingpro.com",
          categoryId: 1,
          category: { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
          contentType: "article",
          timeSpent: 1380, // 23 minutes
          quizScore: 90,
          learningDate: new Date(),
          summary: "Overview of marketing strategies for 2023"
        },
        {
          id: 2,
          userId: 1,
          title: "Advanced React Hooks Tutorial",
          url: "https://youtube.com/watch?v=react-hooks",
          source: "youtube.com",
          categoryId: 2,
          category: { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
          contentType: "video",
          timeSpent: 2700, // 45 minutes
          quizScore: 75,
          learningDate: new Date(Date.now() - 86400000), // yesterday
          summary: "Tutorial on React hooks usage"
        },
        // Add more activities here...
      ]);
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  // Filter activities based on the selected filter
  const filteredActivities = activities.filter(activity => {
    if (filter === "all") return true;
    return activity.contentType === filter;
  });

  // Filter activities based on date range
  const dateFilteredActivities = filteredActivities.filter(activity => {
    const now = new Date();
    const activityDate = new Date(activity.learningDate);
    
    switch (dateRange) {
      case "today":
        return activityDate.toDateString() === now.toDateString();
      case "this-week":
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay());
        return activityDate >= weekStart;
      case "this-month":
        return activityDate.getMonth() === now.getMonth() && 
               activityDate.getFullYear() === now.getFullYear();
      default:
        return true;
    }
  });

  if (isLoading) {
    return (
      <div className="p-4 md:p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="h-32 bg-gray-200 rounded mb-8"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Learning History</h1>
        <p className="text-gray-500">Review your past learning activities</p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-6">
        <div className="flex flex-wrap gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Content Type</label>
            <select 
              className="border rounded p-2"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Types</option>
              <option value="article">Articles</option>
              <option value="video">Videos</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
            <select 
              className="border rounded p-2"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
            >
              <option value="all-time">All Time</option>
              <option value="today">Today</option>
              <option value="this-week">This Week</option>
              <option value="this-month">This Month</option>
            </select>
          </div>
        </div>
      </div>

      {dateFilteredActivities.length > 0 ? (
        <RecentActivities activities={dateFilteredActivities} />
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 text-center">
          <span className="material-icons text-gray-400 text-4xl mb-2">search_off</span>
          <h3 className="text-gray-700 font-medium mb-1">No learning activities found</h3>
          <p className="text-gray-500 text-sm">Try changing your filters or start learning something new!</p>
        </div>
      )}
    </div>
  );
}
