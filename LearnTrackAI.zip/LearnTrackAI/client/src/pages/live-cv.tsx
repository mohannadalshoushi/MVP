import { useState } from "react";
import { Category, LearningSummary, LearningActivity, ToolUsage, User, Certification, LanguageSkill } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Clock, Award, Code, Briefcase, FileText, GraduationCap, Terminal, ExternalLink, Globe, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function LiveCV() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  
  // Mock user ID until we have authentication
  const userId = 1;

  // Fetch categories
  const { data: categoriesData, isLoading: loadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  const categories = categoriesData || [];

  // Fetch summaries
  const { data: summariesData, isLoading: loadingSummaries } = useQuery<LearningSummary[]>({
    queryKey: ['/api/learning-summaries', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/learning-summaries/${userId}`);
      return res.json();
    },
  });
  const summaries = summariesData || [];
  
  // Fetch learning activities
  const { data: activitiesData, isLoading: loadingActivities } = useQuery<LearningActivity[]>({
    queryKey: ['/api/learning-activities', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/learning-activities/${userId}`);
      return res.json();
    },
  });
  const activities = activitiesData || [];
  
  // Fetch tool usages
  const { data: toolUsagesData, isLoading: loadingToolUsages } = useQuery<ToolUsage[]>({
    queryKey: ['/api/tool-usages', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/tool-usages/${userId}`);
      return res.json();
    },
  });
  const toolUsages = toolUsagesData || [];
  
  // Fetch certifications
  const { data: certificationsData, isLoading: loadingCertifications } = useQuery<Certification[]>({
    queryKey: ['/api/certifications', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/certifications/${userId}`);
      return res.json();
    },
  });
  const certifications = certificationsData || [];
  
  // Fetch language skills
  const { data: languageSkillsData, isLoading: loadingLanguageSkills } = useQuery<LanguageSkill[]>({
    queryKey: ['/api/language-skills', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/language-skills/${userId}`);
      return res.json();
    },
  });
  const languageSkills = languageSkillsData || [];

  // Generate CV summary mutation
  const generateSummaryMutation = useMutation({
    mutationFn: async (data: { userId: number; categoryId: number }) => {
      const res = await apiRequest("POST", "/api/generate-cv-summary", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/learning-summaries', userId] });
      toast({
        title: "Summary Generated",
        description: "Your CV summary has been created successfully.",
      });
      setGeneratingSummary(false);
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate CV summary. Please try again.",
        variant: "destructive",
      });
      setGeneratingSummary(false);
    }
  });

  // Handle summary generation for a specific category
  const handleGenerateSummary = (categoryId: number) => {
    if (categoryId) {
      setGeneratingSummary(true);
      setSelectedCategory(categoryId);
      generateSummaryMutation.mutate({ userId, categoryId });
    }
  };

  // Calculate totals
  const totalLearningTime = activities.reduce((total: number, activity: LearningActivity) => total + activity.timeSpent, 0);
  const totalLearningHours = Math.round(totalLearningTime / 3600);
  
  // Get category name from ID
  const getCategoryName = (categoryId: number): string => {
    const category = categories.find((c: Category) => c.id === categoryId);
    return category ? category.name : "Unknown";
  };
  
  // Convert seconds to hours:minutes
  const formatTimeSpent = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };
  
  // Get the appropriate summary based on the selected category
  const selectedSummary = selectedCategory 
    ? summaries.find((summary: LearningSummary) => summary.categoryId === selectedCategory)
    : null;
    
  // Get activities for a category
  const getActivitiesForCategory = (categoryId: number): LearningActivity[] => {
    return activities.filter((activity: LearningActivity) => activity.categoryId === categoryId);
  };
  
  // Get the selected category object
  const category = selectedCategory 
    ? categories.find((cat: Category) => cat.id === selectedCategory)
    : null;
    
  // Calculate average quiz score for a category
  const getAvgQuizScore = (categoryId: number): string => {
    const categoryActivities = activities.filter((a: LearningActivity) => a.categoryId === categoryId && a.quizScore !== undefined);
    if (categoryActivities.length === 0) return "N/A";
    const totalScore = categoryActivities.reduce((sum: number, a: LearningActivity) => sum + (a.quizScore || 0), 0);
    return `${Math.round(totalScore / categoryActivities.length)}%`;
  };
  
  // Loading state
  if (loadingCategories || loadingSummaries || loadingActivities || loadingToolUsages || 
      loadingCertifications || loadingLanguageSkills) {
    return (
      <div className="p-4 md:p-8">
        <div className="animate-pulse">
          <Skeleton className="h-8 w-1/4 mb-6" />
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-1">
          <span className="bg-gradient-to-r from-primary to-primary/80 text-transparent bg-clip-text">
            Learnfy.AI Live CV
          </span>
        </h1>
        <p className="text-gray-500">
          Your professional skills portfolio, automatically generated from your learning activities
        </p>
      </div>
      
      {/* Harvard-Style CV */}
      <div className="grid grid-cols-1 gap-6">
      
        {/* Personal Information */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-primary" />
              Personal Information
            </h2>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium text-gray-900">Name</h3>
                <p className="text-gray-700">Test User</p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Email</h3>
                <p className="text-gray-700">test@example.com</p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Industry</h3>
                <p className="text-gray-700">Software Development</p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Learning Profile</h3>
                <p className="text-gray-700">{totalLearningHours} hours of tracked learning</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Professional Summary */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Briefcase className="w-5 h-5 mr-2 text-primary" />
              Professional Summary
            </h2>
          </div>
          <div className="p-5">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Skill Category for Professional Summary
              </label>
              <div className="flex flex-wrap gap-2">
                {categories.map((category: Category) => (
                  <button
                    key={category.id}
                    className={`px-4 py-2 rounded-full flex items-center ${
                      selectedCategory === category.id
                        ? "bg-primary text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <div className="w-4 h-4 mr-2" style={{ backgroundColor: category.color, borderRadius: '50%' }}></div>
                    {category.name}
                  </button>
                ))}
              </div>
            </div>

            {selectedSummary ? (
              <div>
                <div className="flex items-center mb-4">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center mr-2"
                    style={{ backgroundColor: category?.color }}
                  >
                    <span className="text-white text-sm">{category?.icon}</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-900">{category?.name} Expertise</h3>
                </div>
                
                <div className="bg-gray-50 p-5 rounded-lg mb-4 border border-gray-100">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {selectedSummary.content}
                  </p>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Time: {formatTimeSpent(activities
                        .filter((a: LearningActivity) => a.categoryId === selectedCategory)
                        .reduce((total: number, a: LearningActivity) => total + a.timeSpent, 0))}
                    </Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Award className="w-3 h-3" />
                      Quiz: {selectedCategory ? getAvgQuizScore(selectedCategory) : "N/A"}
                    </Badge>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => selectedCategory && handleGenerateSummary(selectedCategory)}
                      disabled={generatingSummary || !selectedCategory}
                    >
                      {generatingSummary ? "Generating..." : "Regenerate"}
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(selectedSummary.content);
                        toast({
                          title: "Copied to clipboard",
                          description: "The summary has been copied to your clipboard",
                        });
                      }}
                    >
                      Copy to Clipboard
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                <div className="text-gray-400 mb-3">
                  <FileText className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-gray-700 font-medium mb-1">Select a category to view your professional summary</h3>
                <p className="text-gray-500 text-sm mb-4">Automatically generated from your learning activities</p>
                
                {selectedCategory && (
                  <Button 
                    onClick={() => selectedCategory && handleGenerateSummary(selectedCategory)}
                    disabled={generatingSummary || !selectedCategory}
                  >
                    {generatingSummary ? "Generating..." : "Generate Summary"}
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
        
        {/* Education & Skills */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <GraduationCap className="w-5 h-5 mr-2 text-primary" />
              Education & Skills
            </h2>
          </div>
          <div className="p-5">
            <div className="mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Key Skills</h3>
              <div className="flex flex-wrap gap-2">
                {categories.map((category: Category) => {
                  const catActivities = activities.filter((a: LearningActivity) => a.categoryId === category.id);
                  if (catActivities.length === 0) return null;
                  
                  return (
                    <Badge 
                      key={category.id} 
                      variant="secondary"
                      className="px-3 py-1.5 text-sm"
                    >
                      {category.name}
                    </Badge>
                  );
                })}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">Learning Activities</h3>
              <div className="space-y-5">
                {categories.map((category: Category) => {
                  const catActivities = activities.filter((a: LearningActivity) => a.categoryId === category.id);
                  if (catActivities.length === 0) return null;
                  
                  return (
                    <div key={category.id} className="border-l-2 pl-4" style={{ borderColor: category.color }}>
                      <h4 className="font-medium text-gray-900 mb-2">{category.name}</h4>
                      <ul className="space-y-2">
                        {catActivities.slice(0, 3).map((activity: LearningActivity) => (
                          <li key={activity.id} className="text-sm text-gray-700">
                            <div className="flex justify-between">
                              <span className="font-medium">{activity.title}</span>
                              <span className="text-gray-500 text-xs">
                                {activity.learningDate ? format(new Date(activity.learningDate), 'MMM yyyy') : ''}
                              </span>
                            </div>
                            <div className="flex items-center text-xs text-gray-500 mt-1">
                              <span className="mr-3">{activity.source}</span>
                              {activity.quizScore && (
                                <Badge variant="outline" className="text-xs">
                                  Quiz: {activity.quizScore}%
                                </Badge>
                              )}
                            </div>
                          </li>
                        ))}
                        {catActivities.length > 3 && (
                          <li className="text-sm text-primary">
                            + {catActivities.length - 3} more activities
                          </li>
                        )}
                      </ul>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        
        {/* Technical Proficiency */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Terminal className="w-5 h-5 mr-2 text-primary" />
              Technical Proficiency
            </h2>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3">Tools & Technologies</h3>
                <div className="space-y-4">
                  {toolUsages.map((tool: ToolUsage) => (
                    <div key={tool.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div 
                          className="w-8 h-8 rounded-full flex items-center justify-center mr-3"
                          style={{ backgroundColor: tool.color }}
                        >
                          <span className="text-white text-sm">{tool.icon}</span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{tool.toolName}</div>
                          <div className="text-xs text-gray-500">{tool.toolCategory || "Technology"}</div>
                        </div>
                      </div>
                      <div className="font-medium text-primary">{tool.hoursSpent} hours</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3">Learning Metrics</h3>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between mb-1">
                      <div className="font-medium text-gray-700">Time Investment</div>
                      <div className="text-primary font-medium">{totalLearningHours} hours</div>
                    </div>
                    <div className="text-sm text-gray-500">
                      Total tracked learning time across all technologies
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between mb-1">
                      <div className="font-medium text-gray-700">Resources Consumed</div>
                      <div className="text-primary font-medium">{activities.length} items</div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {activities.filter((a: LearningActivity) => a.contentType === 'article').length} articles, {' '}
                      {activities.filter((a: LearningActivity) => a.contentType === 'video').length} videos
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between mb-1">
                      <div className="font-medium text-gray-700">Knowledge Retention</div>
                      <div className="text-primary font-medium">
                        {activities.filter((a: LearningActivity) => a.quizScore !== undefined).length > 0 
                          ? `${Math.round(activities
                              .filter((a: LearningActivity) => a.quizScore !== undefined)
                              .reduce((sum: number, a: LearningActivity) => sum + (a.quizScore || 0), 0) / 
                              activities.filter((a: LearningActivity) => a.quizScore !== undefined).length)}%`
                          : 'N/A'
                        }
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      Average quiz performance across all topics
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Professional Certifications */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Award className="w-5 h-5 mr-2 text-primary" />
              Professional Certifications
            </h2>
          </div>
          <div className="p-5">
            {certifications.length > 0 ? (
              <div className="space-y-4">
                {certifications.map((cert: Certification) => (
                  <div key={cert.id} className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                    <div className="flex justify-between mb-2">
                      <h3 className="text-lg font-medium text-gray-900">{cert.name}</h3>
                      <Badge variant="outline" className="flex items-center gap-1">
                        {cert.expiryDate ? 
                          format(new Date(cert.expiryDate), 'MMM yyyy') : 
                          'No Expiry'}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-700 mb-2">
                      <span className="font-medium">{cert.issuingOrganization}</span> • Issued {format(new Date(cert.issueDate), 'MMM yyyy')}
                    </div>
                    {cert.description && (
                      <p className="text-sm text-gray-600 mb-2">{cert.description}</p>
                    )}
                    {(cert.credentialID || cert.credentialURL) && (
                      <div className="flex flex-wrap gap-3 mt-2">
                        {cert.credentialID && (
                          <Badge variant="secondary" className="text-xs">
                            ID: {cert.credentialID}
                          </Badge>
                        )}
                        {cert.credentialURL && (
                          <a 
                            href={cert.credentialURL} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs flex items-center text-primary hover:underline"
                          >
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Verify Credential
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                <div className="text-gray-400 mb-3">
                  <Award className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-gray-700 font-medium mb-1">No certifications added yet</h3>
                <p className="text-gray-500 text-sm">
                  Add your professional certifications to enhance your CV
                </p>
              </div>
            )}
          </div>
        </div>
        
        {/* Language Skills */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Globe className="w-5 h-5 mr-2 text-primary" />
              Language Skills
            </h2>
          </div>
          <div className="p-5">
            {languageSkills.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {languageSkills.map((lang: LanguageSkill) => (
                  <div key={lang.id} className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                    <div className="flex justify-between mb-2">
                      <h3 className="text-lg font-medium text-gray-900 capitalize">{lang.language}</h3>
                      {lang.proficiencyLevel && (
                        <Badge variant="secondary">{lang.proficiencyLevel}</Badge>
                      )}
                    </div>
                    <div className="mt-3 space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-white p-3 rounded border border-gray-100">
                          <div className="text-sm text-gray-600 mb-1 flex items-center">
                            <FileText className="w-3 h-3 mr-1" /> Reading
                          </div>
                          <div className="font-medium text-gray-900">
                            {Math.round(lang.readingTimeSpent / 3600)} hours
                          </div>
                        </div>
                        <div className="bg-white p-3 rounded border border-gray-100">
                          <div className="text-sm text-gray-600 mb-1 flex items-center">
                            <Languages className="w-3 h-3 mr-1" /> Listening
                          </div>
                          <div className="font-medium text-gray-900">
                            {Math.round(lang.listeningTimeSpent / 3600)} hours
                          </div>
                        </div>
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        Last activity: {format(new Date(lang.lastActivity), 'MMM d, yyyy')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                <div className="text-gray-400 mb-3">
                  <Globe className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-gray-700 font-medium mb-1">No language skills tracked yet</h3>
                <p className="text-gray-500 text-sm">
                  Your language learning activities will appear here
                </p>
              </div>
            )}
          </div>
        </div>
        
        {/* Export Options */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <ExternalLink className="w-5 h-5 mr-2 text-primary" />
            Export & Share
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="h-auto py-6 flex flex-col items-center justify-center border-gray-200"
            >
              <FileText className="text-primary w-8 h-8 mb-2" />
              <div className="text-gray-900 font-medium">Export as PDF</div>
              <div className="text-xs text-gray-500 mt-1">Harvard-style CV format</div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto py-6 flex flex-col items-center justify-center border-gray-200" 
            >
              <svg className="w-8 h-8 mb-2 text-[#0A66C2]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
              </svg>
              <div className="text-gray-900 font-medium">LinkedIn Profile</div>
              <div className="text-xs text-gray-500 mt-1">Update your LinkedIn</div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto py-6 flex flex-col items-center justify-center border-gray-200" 
            >
              <Code className="text-primary w-8 h-8 mb-2" />
              <div className="text-gray-900 font-medium">JSON Format</div>
              <div className="text-xs text-gray-500 mt-1">Developer-friendly</div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
