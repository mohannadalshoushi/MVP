import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, ThumbsUp, MessageSquare, Users, Calendar, BarChart } from "lucide-react";
import { formatMilestoneDate } from "@/lib/milestone-utils";
import { LearningProgressEvent, User, LearningMilestone, LearningGoal } from "@/lib/types";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function Community() {
  const [activeTab, setActiveTab] = useState("achievements");
  const [createGoalDialogOpen, setCreateGoalDialogOpen] = useState(false);
  const [selectedMilestone, setSelectedMilestone] = useState<LearningMilestone | null>(null);
  const [commentDialogOpen, setCommentDialogOpen] = useState(false);
  const [commenting, setCommenting] = useState(false);
  const { toast } = useToast();

  // Query for public milestones
  const {
    data: milestones,
    isLoading: isLoadingMilestones,
    error: milestonesError
  } = useQuery<LearningMilestone[]>({
    queryKey: ["/api/community/milestones"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Query for community members
  const {
    data: users,
    isLoading: isLoadingUsers,
    error: usersError
  } = useQuery<User[]>({
    queryKey: ["/api/community/users"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Query for learning goals
  const {
    data: goals,
    isLoading: isLoadingGoals,
    error: goalsError
  } = useQuery<LearningGoal[]>({
    queryKey: ["/api/community/goals"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Mutation to celebrate a milestone
  const celebrateMutation = useMutation({
    mutationFn: async ({ milestoneId, userId }: { milestoneId: number, userId: number }) => {
      const res = await apiRequest("POST", `/api/community/milestones/${milestoneId}/celebrate`, { userId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/milestones"] });
      toast({
        title: "Success",
        description: "You celebrated this achievement!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to celebrate milestone: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation to add a comment to a milestone
  const commentMutation = useMutation({
    mutationFn: async ({ milestoneId, userId, content }: { milestoneId: number, userId: number, content: string }) => {
      const res = await apiRequest("POST", `/api/community/milestones/${milestoneId}/comments`, { userId, content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/milestones"] });
      setCommentDialogOpen(false);
      setCommenting(false);
      toast({
        title: "Success",
        description: "Your comment was added!",
      });
    },
    onError: (error) => {
      setCommenting(false);
      toast({
        title: "Error",
        description: "Failed to add comment: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation to join a learning goal
  const joinGoalMutation = useMutation({
    mutationFn: async ({ goalId, userId }: { goalId: number, userId: number }) => {
      const res = await apiRequest("POST", `/api/community/goals/${goalId}/join`, { userId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/goals"] });
      toast({
        title: "Success",
        description: "You joined this learning goal!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to join goal: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation to create a new learning goal
  const createGoalMutation = useMutation({
    mutationFn: async (goalData: any) => {
      const res = await apiRequest("POST", "/api/community/goals", goalData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/goals"] });
      setCreateGoalDialogOpen(false);
      toast({
        title: "Success",
        description: "Your learning goal was created!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create goal: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Form for creating a new learning goal
  const form = useForm({
    defaultValues: {
      title: "",
      description: "",
      category: "",
      targetDate: "",
    },
  });

  const onSubmit = (data: any) => {
    // Assuming userId is 1 for now - in a real app, this would come from authentication
    createGoalMutation.mutate({
      ...data,
      userId: 1,
      targetDate: new Date(data.targetDate).toISOString(),
    });
  };

  // Helper function to get user by ID
  const getUserById = (userId: number): User | undefined => {
    return users?.find(user => user.id === userId);
  };

  // Helper to format date
  const formatDate = (date: Date | string): string => {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  // Handle celebrate click
  const handleCelebrate = (milestoneId: number) => {
    // Assuming userId is 1 for now - in a real app, this would come from authentication
    celebrateMutation.mutate({ milestoneId, userId: 1 });
  };

  // Open comment dialog
  const openCommentDialog = (milestone: LearningMilestone) => {
    setSelectedMilestone(milestone);
    setCommentDialogOpen(true);
  };

  // Submit a comment
  const submitComment = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedMilestone) return;
    
    const formData = new FormData(event.currentTarget);
    const content = formData.get('comment') as string;
    
    if (!content.trim()) {
      toast({
        title: "Error",
        description: "Comment cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    setCommenting(true);
    // Assuming userId is 1 for now - in a real app, this would come from authentication
    commentMutation.mutate({ 
      milestoneId: selectedMilestone.id, 
      userId: 1, 
      content 
    });
  };

  // Handle join goal click
  const handleJoinGoal = (goalId: number) => {
    // Assuming userId is 1 for now - in a real app, this would come from authentication
    joinGoalMutation.mutate({ goalId, userId: 1 });
  };

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900">Community</h1>
        <p className="text-slate-600 mt-2">Connect with other learners, share achievements, and collaborate on goals.</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="achievements">Community Achievements</TabsTrigger>
            <TabsTrigger value="goals">Collaborative Goals</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
          </TabsList>
          
          {activeTab === "goals" && (
            <Button onClick={() => setCreateGoalDialogOpen(true)}>
              Create Goal
            </Button>
          )}
        </div>

        {/* Community Achievements Tab */}
        <TabsContent value="achievements" className="space-y-4">
          {isLoadingMilestones ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : milestonesError ? (
            <div className="p-4 bg-red-50 text-red-500 rounded-md">
              Error loading community achievements. Please try again later.
            </div>
          ) : milestones && milestones.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {milestones.map((milestone) => (
                <Card key={milestone.id} className="overflow-hidden">
                  <CardHeader className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{milestone.title}</CardTitle>
                        <CardDescription className="text-white opacity-90 mt-1">
                          {formatMilestoneDate(milestone.achievedAt)}
                        </CardDescription>
                      </div>
                      <div className="bg-white bg-opacity-20 p-2 rounded-full">
                        <span className="material-icons">{milestone.iconName}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-sm text-gray-600">{milestone.description}</p>
                    
                    <div className="mt-4">
                      <div className="flex items-center">
                        <Avatar className="h-6 w-6 mr-2">
                          <AvatarFallback>{getUserById(milestone.userId)?.name?.charAt(0) || 'U'}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium">{getUserById(milestone.userId)?.name || 'User'}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t flex justify-between py-3 bg-gray-50">
                    <div className="flex space-x-3">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex items-center space-x-1 text-gray-500 hover:text-blue-500"
                        onClick={() => handleCelebrate(milestone.id)}
                      >
                        <ThumbsUp className="h-4 w-4" />
                        <span>Celebrate</span>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex items-center space-x-1 text-gray-500 hover:text-blue-500"
                        onClick={() => openCommentDialog(milestone)}
                      >
                        <MessageSquare className="h-4 w-4" />
                        <span>Comment</span>
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-md p-8 text-center">
              <div className="text-4xl mb-4 text-gray-300 flex justify-center">
                <span className="material-icons">emoji_events</span>
              </div>
              <h3 className="text-lg font-medium text-gray-900">No community achievements yet</h3>
              <p className="mt-1 text-gray-500">Be the first to share your learning milestones with the community!</p>
            </div>
          )}
        </TabsContent>

        {/* Collaborative Goals Tab */}
        <TabsContent value="goals" className="space-y-4">
          {isLoadingGoals ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : goalsError ? (
            <div className="p-4 bg-red-50 text-red-500 rounded-md">
              Error loading collaborative goals. Please try again later.
            </div>
          ) : goals && goals.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {goals.map((goal) => (
                <Card key={goal.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{goal.title}</CardTitle>
                        <CardDescription>
                          Created by {getUserById(goal.creatorId)?.name || 'User'} · Due {formatDate(goal.targetDate)}
                        </CardDescription>
                      </div>
                      <Badge>{goal.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{goal.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-sm">
                        <span>Progress</span>
                        <span className="font-semibold">{goal.progress}%</span>
                      </div>
                      <Progress value={goal.progress} className="h-2" />
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex -space-x-2 overflow-hidden">
                        {Array.isArray(goal.participants) && goal.participants.slice(0, 5).map((participantId, index) => (
                          <Avatar key={index} className="border-2 border-white">
                            <AvatarFallback>{getUserById(participantId as number)?.name?.charAt(0) || 'U'}</AvatarFallback>
                          </Avatar>
                        ))}
                        
                        {Array.isArray(goal.participants) && goal.participants.length > 5 && (
                          <div className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-white bg-gray-200 text-xs font-medium text-gray-500">
                            +{goal.participants.length - 5}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => handleJoinGoal(goal.id)}
                      disabled={Array.isArray(goal.participants) && goal.participants.includes(1)} // Assuming userId is 1
                    >
                      {Array.isArray(goal.participants) && goal.participants.includes(1) ? 'Joined' : 'Join Goal'}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-md p-8 text-center">
              <div className="text-4xl mb-4 text-gray-300 flex justify-center">
                <span className="material-icons">group_work</span>
              </div>
              <h3 className="text-lg font-medium text-gray-900">No collaborative goals yet</h3>
              <p className="mt-1 text-gray-500">Create a learning goal to collaborate with other community members!</p>
              <Button className="mt-4" onClick={() => setCreateGoalDialogOpen(true)}>
                Create First Goal
              </Button>
            </div>
          )}
        </TabsContent>

        {/* Members Tab */}
        <TabsContent value="members" className="space-y-4">
          {isLoadingUsers ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : usersError ? (
            <div className="p-4 bg-red-50 text-red-500 rounded-md">
              Error loading community members. Please try again later.
            </div>
          ) : users && users.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {users.map((user) => (
                <Card key={user.id}>
                  <CardContent className="pt-6 pb-6">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary text-white">{user.name?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{user.name || user.username}</h3>
                        <p className="text-sm text-gray-500">{user.sector || 'Learning Enthusiast'}</p>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex space-x-2">
                      <Badge variant="outline" className="flex items-center space-x-1">
                        <BarChart className="h-3 w-3" />
                        <span>5 Skills</span>
                      </Badge>
                      <Badge variant="outline" className="flex items-center space-x-1">
                        <Calendar className="h-3 w-3" />
                        <span>Member since {formatDate(user.createdAt || new Date())}</span>
                      </Badge>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4 bg-gray-50 flex justify-between">
                    <Button variant="outline" size="sm">View Profile</Button>
                    <Button variant="ghost" size="sm">Message</Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-md p-8 text-center">
              <div className="text-4xl mb-4 text-gray-300 flex justify-center">
                <span className="material-icons">people</span>
              </div>
              <h3 className="text-lg font-medium text-gray-900">No community members yet</h3>
              <p className="mt-1 text-gray-500">Invite others to join and learn together!</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Comment Dialog */}
      <Dialog open={commentDialogOpen} onOpenChange={setCommentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add a Comment</DialogTitle>
            <DialogDescription>
              Share your thoughts on this achievement.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={submitComment}>
            <div className="space-y-4">
              <div className="bg-gray-50 p-3 rounded-md">
                <h4 className="font-medium">{selectedMilestone?.title}</h4>
                <p className="text-sm text-gray-600">{selectedMilestone?.description}</p>
              </div>
              
              <Textarea
                id="comment"
                name="comment"
                placeholder="Write your comment here..."
                className="min-h-[100px]"
                disabled={commenting}
              />
            </div>
            
            <DialogFooter className="mt-4">
              <Button type="button" variant="outline" onClick={() => setCommentDialogOpen(false)} disabled={commenting}>
                Cancel
              </Button>
              <Button type="submit" disabled={commenting}>
                {commenting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Post Comment
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Create Goal Dialog */}
      <Dialog open={createGoalDialogOpen} onOpenChange={setCreateGoalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a Learning Goal</DialogTitle>
            <DialogDescription>
              Set a goal to learn together with the community.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Master TypeScript in 30 days" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe what you want to achieve with this goal..." 
                        className="min-h-[100px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Input placeholder="Web Development" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="targetDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter className="mt-4">
                <Button type="button" variant="outline" onClick={() => setCreateGoalDialogOpen(false)} disabled={createGoalMutation.isPending}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createGoalMutation.isPending}>
                  {createGoalMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create Goal
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}