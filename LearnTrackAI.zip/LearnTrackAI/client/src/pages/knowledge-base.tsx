import { useState, useEffect } from "react";
import { RecommendedContent } from "@/components/learning/recommended-content";
import { Category, RecommendedContent as RecommendedContentType } from "@/lib/types";

export default function KnowledgeBase() {
  const [isLoading, setIsLoading] = useState(true);
  const [content, setContent] = useState<RecommendedContentType[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Simulated data loading
  useEffect(() => {
    // Simulate API call delay
    const timer = setTimeout(() => {
      // This would be fetched from the API in a real app
      setCategories([
        { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
        { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
        { id: 3, name: "Design", icon: "brush", color: "#10B981" },
        { id: 4, name: "Sales", icon: "sell", color: "#EF4444" },
        { id: 5, name: "Data Science", icon: "analytics", color: "#F59E0B" },
      ]);
      
      setContent([
        {
          id: 1,
          title: "Modern JavaScript for React Developers",
          description: "Learn essential JavaScript concepts to boost your React skills",
          category: { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
          timeToRead: "10 min read",
          source: "dev.to",
          imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
          contentType: "article",
          url: "https://dev.to/javascript-react"
        },
        {
          id: 2,
          title: "Data-Driven Marketing Strategies for 2023",
          description: "How to use analytics to improve your marketing campaigns",
          category: { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
          timeToRead: "18 min video",
          source: "youtube.com",
          imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
          contentType: "video",
          url: "https://youtube.com/watch?v=marketing-data"
        },
        {
          id: 3,
          title: "Designing Accessible User Interfaces",
          description: "Best practices for creating inclusive digital experiences",
          category: { id: 3, name: "Design", icon: "brush", color: "#10B981" },
          timeToRead: "8 min read",
          source: "medium.com",
          imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
          contentType: "article",
          url: "https://medium.com/design/accessibility"
        },
        // Add more content items here...
      ]);
      
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  // Filter content based on selected category and search query
  const filteredContent = content.filter(item => {
    const matchesCategory = selectedCategory ? item.category.id === selectedCategory : true;
    const matchesSearch = searchQuery 
      ? item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesCategory && matchesSearch;
  });

  if (isLoading) {
    return (
      <div className="p-4 md:p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="h-12 bg-gray-200 rounded mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded h-64"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Knowledge Base</h1>
        <p className="text-gray-500">Discover content tailored to your professional growth</p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Search Content</label>
            <input
              type="text"
              placeholder="Search by title or description"
              className="w-full border rounded p-2"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Category</label>
            <select 
              className="border rounded p-2"
              value={selectedCategory || ""}
              onChange={(e) => setSelectedCategory(e.target.value ? parseInt(e.target.value) : null)}
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {filteredContent.length > 0 ? (
        <RecommendedContent content={filteredContent} />
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 text-center">
          <span className="material-icons text-gray-400 text-4xl mb-2">search_off</span>
          <h3 className="text-gray-700 font-medium mb-1">No content found</h3>
          <p className="text-gray-500 text-sm">Try changing your search criteria or filters</p>
        </div>
      )}
    </div>
  );
}
