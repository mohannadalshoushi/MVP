import React, { useEffect, useState } from "react";
import { useParams } from "wouter";
import { LearningMilestone } from "@/lib/types";
import { formatMilestoneDate } from "@/lib/milestone-utils";
import { Award, BookOpen, Clock, FileQuestion, Flame, Calendar, User, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export default function SharedMilestone() {
  const { shareUrl } = useParams<{ shareUrl: string }>();
  const [milestone, setMilestone] = useState<LearningMilestone | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchMilestone() {
      try {
        setIsLoading(true);
        
        // In a real app this would be a fetch call to get the milestone
        // For demo purposes, we'll use a simulated milestone
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Demo milestone data for preview
        if (shareUrl) {
          setMilestone({
            id: 107,
            userId: 1,
            title: "Advanced JavaScript Mastery",
            description: "Completed 50+ activities in JavaScript with outstanding quiz results!",
            achievedAt: new Date(),
            milestoneType: "category_mastery",
            iconName: "award",
            celebratedAt: new Date(),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: shareUrl,
            socialPlatforms: ["twitter", "linkedin"]
          });
        } else {
          setError("Missing milestone information");
        }
      } catch (err) {
        setError("Failed to load milestone");
        console.error("Error fetching milestone:", err);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchMilestone();
  }, [shareUrl]);
  
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "award":
      case "emoji_events":
        return <Award className="h-16 w-16" />;
      case "book":
      case "menu_book":
        return <BookOpen className="h-16 w-16" />;
      case "clock":
      case "schedule":
        return <Clock className="h-16 w-16" />;
      case "quiz":
      case "question_mark":
        return <FileQuestion className="h-16 w-16" />;
      case "fire":
      case "local_fire_department":
        return <Flame className="h-16 w-16" />;
      default:
        return <Award className="h-16 w-16" />;
    }
  };
  
  const getIconColorClass = (milestoneType: string) => {
    switch (milestoneType) {
      case "time":
        return "text-purple-500";
      case "content_count":
        return "text-amber-500";
      case "quiz_score":
        return "text-blue-500";
      case "streak":
        return "text-red-500";
      case "category_mastery":
        return "text-green-500";
      default:
        return "text-primary";
    }
  };
  
  const shareToSocialMedia = (platform: string) => {
    const shareableUrl = window.location.href;
    const text = encodeURIComponent(`Check out this learning achievement: "${milestone?.title}" from Learnfy.AI! 🎓`);
    
    let url;
    switch (platform) {
      case "twitter":
        url = `https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(shareableUrl)}`;
        break;
      case "linkedin":
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareableUrl)}`;
        break;
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareableUrl)}`;
        break;
      default:
        return;
    }
    
    window.open(url, '_blank', 'width=600,height=400');
  };

  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto py-12 px-4 sm:px-6">
        <Skeleton className="h-12 w-3/4 mb-4" />
        <Skeleton className="h-6 w-1/2 mb-12" />
        <div className="flex flex-col md:flex-row gap-8">
          <Skeleton className="h-64 w-full md:w-1/3 rounded-lg" />
          <div className="w-full md:w-2/3 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
            <div className="pt-4 flex gap-2">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !milestone) {
    return (
      <div className="container max-w-4xl mx-auto py-12 px-4 sm:px-6 text-center">
        <h1 className="text-3xl font-bold mb-6">Milestone Not Found</h1>
        <p className="text-muted-foreground mb-8">
          The milestone you're looking for doesn't exist or is no longer shared.
        </p>
        <Button asChild>
          <a href="/">Return to Dashboard</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/40">
      <div className="container max-w-4xl mx-auto py-12 px-4 sm:px-6">
        <div className="bg-background rounded-xl shadow-lg overflow-hidden">
          <div className="p-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
          
          <div className="p-6 sm:p-10">
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl sm:text-3xl font-bold">Learning Achievement</h1>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4 mr-1" />
                  {formatMilestoneDate(milestone.achievedAt)}
                </div>
              </div>
              
              <div className="h-px bg-border w-full mb-8"></div>
              
              <div className="flex flex-col md:flex-row gap-8">
                {/* Icon Column */}
                <div className="w-full md:w-1/3 flex justify-center md:block">
                  <div className={cn(
                    "rounded-2xl p-8 flex items-center justify-center",
                    "bg-gradient-to-br from-background to-muted border-2 border-border"
                  )}>
                    <div className={`p-6 rounded-full ${getIconColorClass(milestone.milestoneType)}`}>
                      {getIcon(milestone.iconName)}
                    </div>
                  </div>
                </div>
                
                {/* Content Column */}
                <div className="w-full md:w-2/3">
                  <h2 className="text-xl sm:text-2xl font-bold mb-4">{milestone.title}</h2>
                  <p className="text-muted-foreground mb-6">{milestone.description}</p>
                  
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
                    <User className="h-4 w-4" />
                    <span>Achieved by Julia Chen</span>
                  </div>
                  
                  <div className="bg-muted/50 rounded-lg p-4 mb-8">
                    <p className="text-sm">
                      This achievement was earned through consistent learning and demonstrated expertise. 
                      Learnfy.AI tracks learning activities across various platforms and resources to 
                      build a comprehensive learning profile.
                    </p>
                  </div>
                  
                  <div className="h-px bg-border w-full mb-6"></div>
                  
                  <div className="flex flex-wrap gap-2">
                    <Button 
                      className="bg-[#1DA1F2] hover:bg-[#1a94da]"
                      onClick={() => shareToSocialMedia('twitter')}
                    >
                      <Share2 className="mr-2 h-4 w-4" />
                      Share on Twitter
                    </Button>
                    <Button 
                      className="bg-[#0A66C2] hover:bg-[#095196]"
                      onClick={() => shareToSocialMedia('linkedin')}
                    >
                      <Share2 className="mr-2 h-4 w-4" />
                      Share on LinkedIn
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => window.location.href = '/'}
                    >
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-12 text-center text-sm text-muted-foreground">
              <p>Powered by <span className="font-semibold">Learnfy.AI</span> - Your Personal Learning Assistant</p>
              <p className="mt-1">Track your learning journey across platforms and build your professional skills portfolio.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}