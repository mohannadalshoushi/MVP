import { useEffect, useState } from "react";
import { StatsCard } from "@/components/learning/stats-card";
import { LearningProgress } from "@/components/learning/learning-progress";
import { QuizPerformance } from "@/components/learning/quiz-performance";
import { RecentActivities } from "@/components/learning/recent-activities";
import { RecommendedContent } from "@/components/learning/recommended-content";
import { ToolUsageChart } from "@/components/learning/tool-usage-chart";
import { LearningTimeline } from "@/components/learning/learning-timeline";
import { MilestoneCelebration } from "@/components/learning/milestone-celebration";
import { 
  CategoryProgress, 
  DashboardStats, 
  QuizPerformance as QuizPerformanceType, 
  RecentActivity, 
  RecommendedContent as RecommendedContentType,
  ToolUsageChart as ToolUsageChartType,
  LearningProgressEvent,
  LearningMilestone
} from "@/lib/types";

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({
    learningTime: { total: "0h 0m", change: "+0h this week" },
    articlesRead: { total: 0, change: "+0 this week" },
    videosWatched: { total: 0, change: "+0 this week" },
    quizAccuracy: { total: "0%", change: "+0% this week" }
  });
  
  const [categoryProgress, setCategoryProgress] = useState<CategoryProgress[]>([]);
  const [quizPerformance, setQuizPerformance] = useState<QuizPerformanceType>({
    accuracy: 0,
    correct: 0,
    incorrect: 0,
    skipped: 0
  });
  
  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([]);
  const [recommendedContent, setRecommendedContent] = useState<RecommendedContentType[]>([]);
  const [timeframe, setTimeframe] = useState("Last 4 Weeks");
  const [toolUsages, setToolUsages] = useState<ToolUsageChartType[]>([]);
  const [toolTimeframe, setToolTimeframe] = useState("30days");
  const [userId, setUserId] = useState<number>(1); // In a real app, this would come from auth

  // Load data from the API
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Since we still need to use mock data for most items,
        // we'll just fetch recommendations from the API for now
        const recommendationsResponse = await fetch(`/api/recommendations/${userId}`);
        
        if (recommendationsResponse.ok) {
          const recommendationsData = await recommendationsResponse.json();
          setRecommendedContent(recommendationsData);
        }
        
        // Load mock data for other sections (for demo purposes)
        setStats({
          learningTime: { total: "12h 45m", change: "+2.5h this week" },
          articlesRead: { total: 28, change: "+7 this week" },
          videosWatched: { total: 14, change: "+3 this week" },
          quizAccuracy: { total: "82%", change: "+5% this week" }
        });
        
        setCategoryProgress([
          { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6", hoursSpent: 18, percentage: 75 },
          { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6", hoursSpent: 14, percentage: 60 },
          { id: 3, name: "Design", icon: "brush", color: "#10B981", hoursSpent: 8, percentage: 40 },
          { id: 4, name: "Sales", icon: "sell", color: "#EF4444", hoursSpent: 6, percentage: 25 }
        ]);
        
        setQuizPerformance({
          accuracy: 82,
          correct: 75,
          incorrect: 19,
          skipped: 8
        });
        
        setRecentActivities([
          {
            id: 1,
            userId: 1,
            title: "Content Marketing Strategies for 2023",
            url: "https://blog.marketingpro.com/strategies-2023",
            source: "blog.marketingpro.com",
            categoryId: 1,
            category: { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
            contentType: "article",
            timeSpent: 1380, // 23 minutes
            quizScore: 90,
            learningDate: new Date(),
            summary: "Overview of marketing strategies for 2023"
          },
          {
            id: 2,
            userId: 1,
            title: "Advanced React Hooks Tutorial",
            url: "https://youtube.com/watch?v=react-hooks",
            source: "youtube.com",
            categoryId: 2,
            category: { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
            contentType: "video",
            timeSpent: 2700, // 45 minutes
            quizScore: 75,
            learningDate: new Date(Date.now() - 86400000), // yesterday
            summary: "Tutorial on React hooks usage"
          },
          {
            id: 3,
            userId: 1,
            title: "UX Design Principles for Mobile Apps",
            url: "https://design.medium.com/ux-principles",
            source: "design.medium.com",
            categoryId: 3,
            category: { id: 3, name: "Design", icon: "brush", color: "#10B981" },
            contentType: "article",
            timeSpent: 1080, // 18 minutes
            quizScore: 85,
            learningDate: new Date(Date.now() - 86400000 * 2), // 2 days ago
            summary: "Best practices for mobile UX design"
          },
          {
            id: 4,
            userId: 1,
            title: "B2B Sales Techniques Masterclass",
            url: "https://youtube.com/watch?v=sales-masterclass",
            source: "youtube.com",
            categoryId: 4,
            category: { id: 4, name: "Sales", icon: "sell", color: "#EF4444" },
            contentType: "video",
            timeSpent: 2100, // 35 minutes
            quizScore: 65,
            learningDate: new Date(Date.now() - 86400000 * 4), // 4 days ago
            summary: "Advanced B2B sales strategies"
          }
        ]);
        
        // Use default recommendations if API fails
        if (!recommendationsResponse.ok) {
          setRecommendedContent([
            {
              id: 1,
              title: "Modern JavaScript for React Developers",
              description: "Learn essential JavaScript concepts to boost your React skills",
              category: { id: 2, name: "Web Development", icon: "code", color: "#8B5CF6" },
              timeToRead: "10 min read",
              source: "dev.to",
              imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
              contentType: "article",
              url: "https://dev.to/javascript-react"
            },
            {
              id: 2,
              title: "Data-Driven Marketing Strategies for 2023",
              description: "How to use analytics to improve your marketing campaigns",
              category: { id: 1, name: "Marketing", icon: "trending_up", color: "#3B82F6" },
              timeToRead: "18 min video",
              source: "youtube.com",
              imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
              contentType: "video",
              url: "https://youtube.com/watch?v=marketing-data"
            },
            {
              id: 3,
              title: "Designing Accessible User Interfaces",
              description: "Best practices for creating inclusive digital experiences",
              category: { id: 3, name: "Design", icon: "brush", color: "#10B981" },
              timeToRead: "8 min read",
              source: "medium.com",
              imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=640&q=80",
              contentType: "article",
              url: "https://medium.com/design/accessibility"
            }
          ]);
        }
        
        // Mock tool usage data
        setToolUsages([
          { toolName: "JIRA", hoursSpent: 10, icon: "task_alt", color: "#0052CC", percentage: 20 },
          { toolName: "Replit", hoursSpent: 25, icon: "code", color: "#F26207", percentage: 50 },
          { toolName: "Figma", hoursSpent: 8, icon: "edit", color: "#F24E1E", percentage: 16 },
          { toolName: "GitHub", hoursSpent: 15, icon: "merge_type", color: "#24292E", percentage: 30 },
          { toolName: "Slack", hoursSpent: 12, icon: "chat", color: "#4A154B", percentage: 24 }
        ]);
        
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [userId]);

  const handleTimeframeChange = (newTimeframe: string) => {
    setTimeframe(newTimeframe);
    // In a real app, this would fetch new data based on the timeframe
  };
  
  const handleToolTimeframeChange = (newTimeframe: string) => {
    setToolTimeframe(newTimeframe);
    // In a real app, this would fetch new tool usage data based on the timeframe
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white p-5 rounded-lg shadow-sm border border-gray-100 h-32">
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/3 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
          {/* More loading placeholders would go here */}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Your Learning Dashboard</h1>
        <p className="text-gray-500">Track your learning progress and improve your skills</p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatsCard 
          title="Learning Time" 
          value={stats.learningTime.total} 
          change={stats.learningTime.change} 
          icon="timer" 
          iconColor="#3B82F6" 
        />
        <StatsCard 
          title="Articles Read" 
          value={stats.articlesRead.total} 
          change={stats.articlesRead.change} 
          icon="article" 
          iconColor="#8B5CF6" 
        />
        <StatsCard 
          title="Videos Watched" 
          value={stats.videosWatched.total} 
          change={stats.videosWatched.change} 
          icon="play_circle" 
          iconColor="#EF4444" 
        />
        <StatsCard 
          title="Quiz Accuracy" 
          value={stats.quizAccuracy.total} 
          change={stats.quizAccuracy.change} 
          icon="quiz" 
          iconColor="#10B981" 
        />
      </div>

      {/* Learning Progress Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <LearningProgress 
          categories={categoryProgress} 
          timeframe={timeframe}
          onTimeframeChange={handleTimeframeChange}
        />
        <QuizPerformance performance={quizPerformance} />
      </div>

      {/* Tool Usage Section */}
      <div className="mb-8">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <ToolUsageChart 
            toolUsages={toolUsages} 
            timeframe={toolTimeframe} 
            onTimeframeChange={handleToolTimeframeChange}
          />
        </div>
      </div>

      {/* Learning Timeline Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Learning Timeline</h2>
        <LearningTimeline userId={userId} limit={20} />
      </div>

      {/* Recent Activity Section */}
      <RecentActivities activities={recentActivities} />

      {/* Recommended Content Section */}
      <RecommendedContent content={recommendedContent} />
      
      {/* Milestone Celebration - This component will show automatically when milestones are reached */}
      <MilestoneCelebration 
        userId={userId} 
        onMilestoneCelebrated={(milestone) => {
          console.log("Milestone celebrated:", milestone);
          // In a real app, you might want to refresh the timeline or show a notification
        }}
      />
    </div>
  );
}
