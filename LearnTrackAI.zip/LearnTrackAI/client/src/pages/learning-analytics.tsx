import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line } from "recharts";
import { Activity, BarChart2, BookOpen, Clock, Lightbulb, Map, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LearningActivity, Category, ToolUsage } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function LearningAnalytics() {
  // State for data
  const [activities, setActivities] = useState<LearningActivity[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [toolUsages, setToolUsages] = useState<ToolUsage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState("30days"); // Default to 30 days
  const [activeTab, setActiveTab] = useState("overview");
  
  // Fetch data from API
  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        // Fetch all required data
        const userId = 1; // TODO: Replace with actual user ID from auth context
        
        const activitiesResponse = await fetch(`/api/learning-activities/${userId}`);
        const activitiesData = await activitiesResponse.json();
        
        const categoriesResponse = await fetch('/api/categories');
        const categoriesData = await categoriesResponse.json();
        
        const toolUsagesResponse = await fetch(`/api/tool-usages/${userId}`);
        const toolUsagesData = await toolUsagesResponse.json();
        
        setActivities(activitiesData);
        setCategories(categoriesData);
        setToolUsages(toolUsagesData);
      } catch (error) {
        console.error("Error fetching analytics data:", error);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchData();
  }, []);
  
  // Filter data based on time range
  const getFilteredData = () => {
    const now = new Date();
    let startDate = new Date();
    
    switch (timeRange) {
      case "7days":
        startDate.setDate(now.getDate() - 7);
        break;
      case "30days":
        startDate.setDate(now.getDate() - 30);
        break;
      case "90days":
        startDate.setDate(now.getDate() - 90);
        break;
      case "year":
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      case "all":
        startDate = new Date(0); // Beginning of time
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }
    
    return {
      activities: activities.filter(a => new Date(a.learningDate) > startDate),
      toolUsages: toolUsages // Tool usage data is cumulative
    };
  };
  
  const filteredData = getFilteredData();
  
  // Calculate various analytics metrics
  const calculateAnalytics = () => {
    const { activities } = filteredData;
    
    if (!activities.length) {
      return {
        totalTimeSpent: 0,
        averageQuizScore: 0,
        contentTypeDistribution: [],
        activityByCategory: [],
        timePerDay: [],
        learningTrend: [],
        topCategories: [],
        topSources: []
      };
    }
    
    // Total time spent (in hours)
    const totalTimeSpent = activities.reduce((sum, a) => sum + a.timeSpent, 0) / 3600;
    
    // Average quiz score
    const activitiesWithScores = activities.filter(a => a.quizScore !== undefined);
    const averageQuizScore = activitiesWithScores.length 
      ? activitiesWithScores.reduce((sum, a) => sum + (a.quizScore || 0), 0) / activitiesWithScores.length 
      : 0;
    
    // Content type distribution
    const contentTypes = activities.reduce((acc: Record<string, number>, a) => {
      acc[a.contentType] = (acc[a.contentType] || 0) + 1;
      return acc;
    }, {});
    
    const contentTypeDistribution = Object.entries(contentTypes).map(([name, value]) => ({
      name,
      value
    }));
    
    // Activity by category
    const activityByCategory = categories.map(cat => {
      const catActivities = activities.filter(a => a.categoryId === cat.id);
      const timeSpent = catActivities.reduce((sum, a) => sum + a.timeSpent, 0) / 3600; // Convert to hours
      
      return {
        name: cat.name,
        value: timeSpent,
        color: cat.color
      };
    }).filter(cat => cat.value > 0);
    
    // Learning activity by day
    const activityByDay: Record<string, number> = {};
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split('T')[0];
    }).reverse();
    
    // Initialize each day with 0
    last30Days.forEach(day => {
      activityByDay[day] = 0;
    });
    
    // Fill in actual values
    activities.forEach(activity => {
      const day = new Date(activity.learningDate).toISOString().split('T')[0];
      if (activityByDay[day] !== undefined) {
        activityByDay[day] += activity.timeSpent / 3600; // Convert to hours
      }
    });
    
    const timePerDay = Object.entries(activityByDay).map(([date, hours]) => ({
      date,
      hours: parseFloat(hours.toFixed(2))
    }));
    
    // Learning trend (cumulative time spent)
    let cumulativeTime = 0;
    const learningTrend = timePerDay.map(day => {
      cumulativeTime += day.hours;
      return {
        date: day.date,
        hours: parseFloat(cumulativeTime.toFixed(2))
      };
    });
    
    // Top categories by time spent
    const topCategories = [...activityByCategory]
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
    
    // Top sources
    const sourceCount = activities.reduce((acc: Record<string, number>, a) => {
      acc[a.source] = (acc[a.source] || 0) + 1;
      return acc;
    }, {});
    
    const topSources = Object.entries(sourceCount)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    return {
      totalTimeSpent: parseFloat(totalTimeSpent.toFixed(2)),
      averageQuizScore: Math.round(averageQuizScore),
      contentTypeDistribution,
      activityByCategory,
      timePerDay,
      learningTrend,
      topCategories,
      topSources
    };
  };
  
  const analytics = calculateAnalytics();
  
  // COLORS for charts
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];
  
  // Loading state
  if (isLoading) {
    return (
      <div className="container py-8">
        <div className="flex flex-col space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-48" />
          
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4 mt-4">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
          
          <Skeleton className="h-96 w-full mt-8" />
        </div>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Learning Analytics</h1>
          <p className="text-muted-foreground">
            Detailed insights into your learning activities and progress
          </p>
        </div>
        
        <div className="flex items-center space-x-4 mt-4 md:mt-0">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="90days">Last 90 Days</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm">
            <MoreHorizontal className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
      
      {/* Key Metrics Cards */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Learning Time</p>
                <h3 className="text-2xl font-bold">{analytics.totalTimeSpent} hours</h3>
              </div>
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <div className="mt-4">
              <Badge variant={analytics.totalTimeSpent > 10 ? "default" : "outline"}>
                {analytics.totalTimeSpent > 20 ? "Expert" : analytics.totalTimeSpent > 10 ? "Intermediate" : "Beginner"}
              </Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Average Quiz Score</p>
                <h3 className="text-2xl font-bold">{analytics.averageQuizScore}%</h3>
              </div>
              <Activity className="h-6 w-6 text-primary" />
            </div>
            <div className="mt-4">
              <Badge variant={analytics.averageQuizScore > 80 ? "default" : "outline"}>
                {analytics.averageQuizScore > 90 ? "Excellent" : analytics.averageQuizScore > 80 ? "Good" : analytics.averageQuizScore > 70 ? "Average" : "Needs improvement"}
              </Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Content Types</p>
                <h3 className="text-2xl font-bold">
                  {analytics.contentTypeDistribution.length} types
                </h3>
              </div>
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <div className="mt-4">
              <div className="flex space-x-1">
                {analytics.contentTypeDistribution.map((item, index) => (
                  <Badge key={index} variant="outline" className="capitalize">
                    {item.name}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Top Category</p>
                <h3 className="text-2xl font-bold">
                  {analytics.topCategories.length > 0 ? analytics.topCategories[0].name : "N/A"}
                </h3>
              </div>
              <Map className="h-6 w-6 text-primary" />
            </div>
            <div className="mt-4">
              {analytics.topCategories.length > 0 && (
                <Badge>
                  {analytics.topCategories[0].value.toString()} hours
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Analytics Content */}
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="overview" className="flex items-center">
            <BarChart2 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center">
            <Map className="h-4 w-4 mr-2" />
            Categories
          </TabsTrigger>
          <TabsTrigger value="activities" className="flex items-center">
            <Activity className="h-4 w-4 mr-2" />
            Activities
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center">
            <Lightbulb className="h-4 w-4 mr-2" />
            Insights
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
            {/* Learning Activity Trend */}
            <Card>
              <CardHeader>
                <CardTitle>Learning Activity Trend</CardTitle>
                <CardDescription>Hours spent learning over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analytics.learningTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(date) => {
                          const d = new Date(date);
                          return `${d.getMonth()+1}/${d.getDate()}`;
                        }}
                        tickCount={7}
                      />
                      <YAxis name="Hours" />
                      <Tooltip 
                        formatter={(value) => [`${value} hours`, 'Total']}
                        labelFormatter={(label) => {
                          const d = new Date(label);
                          return `${d.toLocaleDateString()}`;
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="hours" 
                        stroke="#8884d8" 
                        activeDot={{ r: 8 }} 
                        name="Cumulative Hours"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Daily Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Daily Learning Activity</CardTitle>
                <CardDescription>Hours spent each day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.timePerDay}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(date) => {
                          const d = new Date(date);
                          return `${d.getMonth()+1}/${d.getDate()}`;
                        }}
                        tickCount={7}
                      />
                      <YAxis name="Hours" />
                      <Tooltip 
                        formatter={(value) => [`${value} hours`, 'Time Spent']}
                        labelFormatter={(label) => {
                          const d = new Date(label);
                          return `${d.toLocaleDateString()}`;
                        }}
                      />
                      <Bar dataKey="hours" fill="#82ca9d" name="Hours" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Category Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Category Distribution</CardTitle>
                <CardDescription>Time spent by learning category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={analytics.activityByCategory}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                      >
                        {analytics.activityByCategory.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${typeof value === 'number' ? value.toFixed(2) : value} hours`, 'Time Spent']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Content Type Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Content Type Distribution</CardTitle>
                <CardDescription>Number of activities by content type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.contentTypeDistribution}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value} activities`, 'Count']} />
                      <Legend />
                      <Bar dataKey="value" fill="#8884d8" name="Activities" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Top Sources Table */}
          <Card>
            <CardHeader>
              <CardTitle>Top Content Sources</CardTitle>
              <CardDescription>Platforms you learn from the most</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Source</th>
                      <th className="text-right py-3 px-4">Activities</th>
                      <th className="text-right py-3 px-4">Percentage</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analytics.topSources.map((source, index) => {
                      const percentage = (source.count / activities.length) * 100;
                      return (
                        <tr key={index} className="border-b">
                          <td className="py-3 px-4">{source.name}</td>
                          <td className="text-right py-3 px-4">{source.count}</td>
                          <td className="text-right py-3 px-4">{percentage.toFixed(1)}%</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-6">
          <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
            {/* Categories Breakdown */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
                <CardDescription>Time spent across different learning categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={analytics.activityByCategory}
                      layout="vertical"
                      margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" width={80} />
                      <Tooltip formatter={(value) => [`${typeof value === 'number' ? value.toFixed(2) : value} hours`, 'Time Spent']} />
                      <Legend />
                      <Bar 
                        dataKey="value" 
                        name="Hours Spent" 
                        >
                        {analytics.activityByCategory.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Additional category metrics to be added later */}
          </div>
        </TabsContent>
        
        {/* Activities Tab */}
        <TabsContent value="activities" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Learning Activities</CardTitle>
              <CardDescription>Your most recent learning sessions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Title</th>
                      <th className="text-left py-3 px-4">Category</th>
                      <th className="text-left py-3 px-4">Type</th>
                      <th className="text-right py-3 px-4">Time Spent</th>
                      <th className="text-right py-3 px-4">Quiz Score</th>
                      <th className="text-right py-3 px-4">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredData.activities.slice(0, 10).map((activity, index) => {
                      const category = categories.find(c => c.id === activity.categoryId);
                      return (
                        <tr key={index} className="border-b">
                          <td className="py-3 px-4">{activity.title}</td>
                          <td className="py-3 px-4">
                            {category ? (
                              <div className="flex items-center">
                                <div className={`w-3 h-3 rounded-full mr-2`} style={{ backgroundColor: category.color }}></div>
                                {category.name}
                              </div>
                            ) : 'Unknown'}
                          </td>
                          <td className="py-3 px-4 capitalize">{activity.contentType}</td>
                          <td className="text-right py-3 px-4">{(activity.timeSpent / 3600).toFixed(1)} hrs</td>
                          <td className="text-right py-3 px-4">{activity.quizScore !== undefined ? `${activity.quizScore}%` : '-'}</td>
                          <td className="text-right py-3 px-4">{new Date(activity.learningDate).toLocaleDateString()}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Learning Patterns</CardTitle>
              <CardDescription>AI-generated insights about your learning habits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.totalTimeSpent > 0 ? (
                  <>
                    <div className="p-4 border rounded-lg bg-primary/5">
                      <h3 className="text-lg font-medium mb-2 flex items-center">
                        <Lightbulb className="h-5 w-5 mr-2 text-primary" />
                        Learning Consistency
                      </h3>
                      <p>
                        {analytics.timePerDay.filter(day => day.hours > 0).length > 10
                          ? "You've been consistently learning over time, which is excellent for knowledge retention."
                          : "Your learning seems to be concentrated on certain days. More consistent daily learning can improve retention."}
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg bg-primary/5">
                      <h3 className="text-lg font-medium mb-2 flex items-center">
                        <Lightbulb className="h-5 w-5 mr-2 text-primary" />
                        Content Diversity
                      </h3>
                      <p>
                        {analytics.contentTypeDistribution.length > 1
                          ? "You're consuming diverse content types which helps build a well-rounded understanding."
                          : "You might benefit from exploring different content formats to enhance your learning experience."}
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg bg-primary/5">
                      <h3 className="text-lg font-medium mb-2 flex items-center">
                        <Lightbulb className="h-5 w-5 mr-2 text-primary" />
                        Knowledge Assessment
                      </h3>
                      <p>
                        {analytics.averageQuizScore > 80
                          ? `With an average quiz score of ${analytics.averageQuizScore}%, you're demonstrating excellent comprehension of the material.`
                          : `Your average quiz score of ${analytics.averageQuizScore}% suggests there might be opportunities to deepen your understanding.`}
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg bg-primary/5">
                      <h3 className="text-lg font-medium mb-2 flex items-center">
                        <Lightbulb className="h-5 w-5 mr-2 text-primary" />
                        Focus Areas
                      </h3>
                      <p>
                        {analytics.topCategories.length > 0
                          ? `You're most engaged with ${analytics.topCategories[0].name} content, spending ${analytics.topCategories[0].value.toString()} hours in this area.`
                          : "You haven't focused on any particular category yet."}
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <Lightbulb className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No learning data yet</h3>
                    <p className="text-muted-foreground mt-2">
                      Start logging your learning activities to see insights
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}