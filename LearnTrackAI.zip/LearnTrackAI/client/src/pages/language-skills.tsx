import { useState } from "react";
import { Edit, FileText, Globe, Languages, MoreHorizontal, Plus, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { LanguageSkill } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { LanguageSkillForm } from "@/components/languages/language-skill-form";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export default function LanguageSkillsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedLanguageSkill, setSelectedLanguageSkill] = useState<LanguageSkill | null>(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  
  // Mock user ID until we have authentication
  const userId = 1;

  // Fetch language skills
  const { data: languageSkills, isLoading } = useQuery<LanguageSkill[]>({
    queryKey: ['/api/language-skills', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/language-skills/${userId}`);
      return res.json();
    },
  });

  // Delete language skill mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/language-skills/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/language-skills', userId] });
      toast({
        title: "Language Skill Deleted",
        description: "The language skill has been removed from your profile",
      });
      setIsDeleteAlertOpen(false);
      setSelectedLanguageSkill(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete language skill. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (languageSkill: LanguageSkill) => {
    setSelectedLanguageSkill(languageSkill);
    setIsAddDialogOpen(true);
  };

  const handleDelete = (languageSkill: LanguageSkill) => {
    setSelectedLanguageSkill(languageSkill);
    setIsDeleteAlertOpen(true);
  };

  const confirmDelete = () => {
    if (selectedLanguageSkill) {
      deleteMutation.mutate(selectedLanguageSkill.id);
    }
  };

  const closeForm = () => {
    setIsAddDialogOpen(false);
    setSelectedLanguageSkill(null);
  };

  // Calculate total hours
  const calculateTotalHours = (seconds: number) => {
    return Math.round(seconds / 3600);
  };

  // Format skill percentage based on reading and listening time
  const getLanguageUsagePercentage = (lang: LanguageSkill) => {
    const totalTime = lang.readingTimeSpent + lang.listeningTimeSpent;
    const readingPercentage = totalTime > 0 ? (lang.readingTimeSpent / totalTime) * 100 : 50;
    return {
      reading: readingPercentage,
      listening: 100 - readingPercentage
    };
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-1">
            <span className="bg-gradient-to-r from-primary to-primary/80 text-transparent bg-clip-text">
              Language Skills
            </span>
          </h1>
          <p className="text-gray-500">
            Your language skills are automatically tracked as you browse content in different languages
          </p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Language
        </Button>
      </div>

      {/* Language Skills List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {languageSkills && languageSkills.length > 0 ? (
          languageSkills.map((lang) => {
            const percentages = getLanguageUsagePercentage(lang);
            const totalHours = calculateTotalHours(lang.readingTimeSpent + lang.listeningTimeSpent);
            
            return (
              <div 
                key={lang.id} 
                className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 capitalize">{lang.language}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {lang.proficiencyLevel && (
                          <Badge variant="secondary">{lang.proficiencyLevel}</Badge>
                        )}
                        <span className="text-sm text-gray-500">{totalHours} hours total</span>
                      </div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEdit(lang)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(lang)}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                <div className="mt-4 space-y-3">
                  <div>
                    <div className="flex justify-between text-xs text-gray-600 mb-1">
                      <div className="flex items-center">
                        <FileText className="w-3 h-3 mr-1" /> Reading
                      </div>
                      <span>{calculateTotalHours(lang.readingTimeSpent)} hours</span>
                    </div>
                    <Progress value={percentages.reading} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-xs text-gray-600 mb-1">
                      <div className="flex items-center">
                        <Languages className="w-3 h-3 mr-1" /> Listening
                      </div>
                      <span>{calculateTotalHours(lang.listeningTimeSpent)} hours</span>
                    </div>
                    <Progress value={percentages.listening} className="h-2" />
                  </div>
                </div>
                
                <div className="mt-4 text-xs text-gray-500">
                  Last activity: {format(new Date(lang.lastActivity), 'MMM d, yyyy')}
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200 col-span-full">
            <Globe className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <h3 className="text-xl font-medium text-gray-700 mb-1">No language skills yet</h3>
            <p className="text-gray-500 mb-4">
              Your language skills will be automatically tracked as you browse content in different languages. 
              You can also manually add languages you already know.
            </p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Language
            </Button>
          </div>
        )}
      </div>

      {/* Add/Edit Language Skill Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[525px] p-0">
          <LanguageSkillForm 
            userId={userId} 
            languageSkill={selectedLanguageSkill || undefined} 
            onClose={closeForm} 
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Language Skill</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete your {selectedLanguageSkill?.language} language skill? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}