import { useState } from "react";
import { Award, Edit, MoreHorizontal, Plus, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Certification } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { CertificationForm } from "@/components/certifications/certification-form";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent } from "@/components/ui/dialog";

export default function CertificationsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedCertification, setSelectedCertification] = useState<Certification | null>(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  
  // Mock user ID until we have authentication
  const userId = 1;

  // Fetch certifications
  const { data: certifications, isLoading } = useQuery<Certification[]>({
    queryKey: ['/api/certifications', userId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/certifications/${userId}`);
      return res.json();
    },
  });

  // Delete certification mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/certifications/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/certifications', userId] });
      toast({
        title: "Certification Deleted",
        description: "The certification has been removed from your profile",
      });
      setIsDeleteAlertOpen(false);
      setSelectedCertification(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete certification. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (certification: Certification) => {
    setSelectedCertification(certification);
    setIsAddDialogOpen(true);
  };

  const handleDelete = (certification: Certification) => {
    setSelectedCertification(certification);
    setIsDeleteAlertOpen(true);
  };

  const confirmDelete = () => {
    if (selectedCertification) {
      deleteMutation.mutate(selectedCertification.id);
    }
  };

  const closeForm = () => {
    setIsAddDialogOpen(false);
    setSelectedCertification(null);
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-1">
            <span className="bg-gradient-to-r from-primary to-primary/80 text-transparent bg-clip-text">
              Professional Certifications
            </span>
          </h1>
          <p className="text-gray-500">
            Manage your professional certifications and credentials
          </p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Certification
        </Button>
      </div>

      {/* Certifications List */}
      <div className="space-y-4">
        {certifications && certifications.length > 0 ? (
          certifications.map((cert) => (
            <div 
              key={cert.id} 
              className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{cert.name}</h3>
                    <p className="text-gray-600 text-sm">
                      {cert.issuingOrganization} • Issued {format(new Date(cert.issueDate), 'MMM yyyy')}
                      {cert.expiryDate && ` • Expires ${format(new Date(cert.expiryDate), 'MMM yyyy')}`}
                    </p>
                    {cert.description && (
                      <p className="text-gray-700 mt-2 text-sm">{cert.description}</p>
                    )}
                    <div className="flex flex-wrap gap-3 mt-3">
                      {cert.credentialID && (
                        <div className="text-xs text-gray-500 flex items-center bg-gray-100 px-2 py-1 rounded">
                          ID: {cert.credentialID}
                        </div>
                      )}
                      {cert.credentialURL && (
                        <a 
                          href={cert.credentialURL} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs flex items-center text-primary hover:underline bg-primary/5 px-2 py-1 rounded"
                        >
                          Verify Credential
                        </a>
                      )}
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleEdit(cert)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => handleDelete(cert)}
                      className="text-red-600"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
            <Award className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <h3 className="text-xl font-medium text-gray-700 mb-1">No certifications yet</h3>
            <p className="text-gray-500 mb-4">Add your professional certifications to enhance your profile</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Certification
            </Button>
          </div>
        )}
      </div>

      {/* Add/Edit Certification Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[525px] p-0">
          <CertificationForm 
            userId={userId} 
            certification={selectedCertification || undefined} 
            onClose={closeForm} 
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Certification</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the certification "{selectedCertification?.name}"? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}