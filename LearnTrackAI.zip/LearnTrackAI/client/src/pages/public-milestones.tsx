import React, { useEffect, useState } from "react";
import { LearningMilestone } from "@/lib/types";
import { MilestoneShareCard } from "@/components/learning/milestone-share-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, TrendingUp, Award, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function AchievementMilestones() {
  const [milestones, setMilestones] = useState<LearningMilestone[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("recent");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // Fetch mock public milestones data for demo
  useEffect(() => {
    async function fetchPublicMilestones() {
      try {
        setIsLoading(true);
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Demo milestone data
        const mockMilestones: LearningMilestone[] = [
          {
            id: 201,
            userId: 2,
            title: "React Expert Badge",
            description: "Completed 30+ React learning activities with 95% quiz accuracy",
            achievedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
            milestoneType: "category_mastery",
            iconName: "award",
            celebratedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "react-expert-alex",
            socialPlatforms: ["twitter", "linkedin"]
          },
          {
            id: 202,
            userId: 3,
            title: "Learning Streak: 30 Days",
            description: "Consistently learned every day for a full month. Amazing dedication!",
            achievedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
            milestoneType: "streak",
            iconName: "fire",
            celebratedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "30-day-streak-sarah",
            socialPlatforms: ["twitter", "facebook"]
          },
          {
            id: 203,
            userId: 4,
            title: "Machine Learning Foundation",
            description: "Completed intro to machine learning with excellent project results",
            achievedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
            milestoneType: "category_mastery",
            iconName: "award",
            celebratedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "ml-foundation-mike",
            socialPlatforms: ["linkedin"]
          },
          {
            id: 204,
            userId: 5,
            title: "100 Hours Learning Journey",
            description: "Spent 100 hours expanding knowledge across multiple categories",
            achievedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
            milestoneType: "time",
            iconName: "clock",
            celebratedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "100-hour-journey-emma",
            socialPlatforms: ["twitter", "linkedin", "facebook"]
          },
          {
            id: 205,
            userId: 6,
            title: "Cloud Architecture Mastery",
            description: "Demonstrated expertise in cloud architecture principles and practices",
            achievedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
            milestoneType: "category_mastery",
            iconName: "award",
            celebratedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "cloud-arch-jason",
            socialPlatforms: ["linkedin"]
          },
          {
            id: 206,
            userId: 7,
            title: "Quiz Champion",
            description: "Scored 100% on 10 consecutive learning quizzes. Impressive recall!",
            achievedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
            milestoneType: "quiz_score",
            iconName: "quiz",
            celebratedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
            isHidden: false,
            isShared: true,
            privacyLevel: "public",
            shareUrl: "quiz-champ-priya",
            socialPlatforms: ["twitter"]
          }
        ];
        
        setMilestones(mockMilestones);
      } catch (error) {
        console.error("Error fetching public milestones:", error);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchPublicMilestones();
  }, []);
  
  // Filter and sort milestones based on user selections
  const filteredMilestones = milestones.filter(milestone => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      milestone.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      milestone.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Category filter
    const matchesCategory = selectedCategory === "all" || milestone.milestoneType === selectedCategory;
    
    return matchesSearch && matchesCategory;
  }).sort((a, b) => {
    switch (sortBy) {
      case "recent":
        return new Date(b.achievedAt || 0).getTime() - new Date(a.achievedAt || 0).getTime();
      case "oldest":
        return new Date(a.achievedAt || 0).getTime() - new Date(b.achievedAt || 0).getTime();
      case "alphabetical":
        return a.title.localeCompare(b.title);
      default:
        return 0;
    }
  });
  
  // Skeleton for loading state
  if (isLoading) {
    return (
      <div className="container py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-10 w-28" />
            <Skeleton className="h-10 w-28" />
          </div>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Achievement Milestones</h1>
          <p className="text-muted-foreground mb-4">
            Discover learning milestones shared by the community
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search achievements..."
              className="pl-8 w-full sm:w-[200px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full sm:w-[140px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="alphabetical">Alphabetical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="mb-8" onValueChange={setSelectedCategory}>
        <TabsList className="mb-4">
          <TabsTrigger value="all" className="flex gap-1">
            <TrendingUp className="h-4 w-4" />
            <span>All Types</span>
          </TabsTrigger>
          <TabsTrigger value="category_mastery" className="flex gap-1">
            <Award className="h-4 w-4" />
            <span>Mastery</span>
          </TabsTrigger>
          <TabsTrigger value="streak" className="flex gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>
            </svg>
            <span>Streaks</span>
          </TabsTrigger>
          <TabsTrigger value="time" className="flex gap-1">
            <Calendar className="h-4 w-4" />
            <span>Time</span>
          </TabsTrigger>
          <TabsTrigger value="quiz_score" className="flex gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="M9.9 9.9 14.1 14.1M14.1 9.9 9.9 14.1"/>
              <path d="M12 8v.5M12 15.5v.5"/>
              <path d="M8 12h.5M15.5 12h.5"/>
            </svg>
            <span>Quiz</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
      
      {filteredMilestones.length === 0 ? (
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center p-4 rounded-full bg-muted mb-4">
            <Search className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium">No achievements found</h3>
          <p className="text-muted-foreground mt-2 mb-4">
            Try adjusting your search or filter criteria
          </p>
          <Button variant="outline" onClick={() => {
            setSearchQuery("");
            setSelectedCategory("all");
            setSortBy("recent");
          }}>
            Reset Filters
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredMilestones.map(milestone => (
            <a 
              key={milestone.id} 
              href={`/share/${milestone.shareUrl}`}
              className="transition-transform hover:scale-[1.01] focus:scale-[1.01] focus:outline-none"
            >
              <MilestoneShareCard 
                milestone={milestone} 
                includeShareButton={false} 
              />
            </a>
          ))}
        </div>
      )}
    </div>
  );
}