// Learnfy.AI Background Script

// Set default API endpoint
const API_ENDPOINT = "https://learnfy-ai.replit.app";

// Store user session information
let userSession = {
  isLoggedIn: false,
  username: "",
  userId: null
};

// Load any saved session data
chrome.storage.local.get(['userSession'], function(result) {
  if (result.userSession) {
    userSession = result.userSession;
  }
});

// Track learning activities
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  chrome.storage.local.get(['learningTabs'], function(result) {
    const learningTabs = result.learningTabs || {};
    
    if (learningTabs[tabId]) {
      const tabData = learningTabs[tabId];
      
      // Calculate time spent on the page
      const timeSpent = Math.floor((Date.now() - tabData.startTime) / 1000); // in seconds
      
      if (timeSpent > 30 && userSession.isLoggedIn) { // Only track if spent more than 30 seconds and logged in
        // Send learning activity to server
        fetch(`${API_ENDPOINT}/api/learning-activities`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userId: userSession.userId,
            title: tabData.title,
            url: tabData.url,
            source: new URL(tabData.url).hostname,
            categoryId: tabData.categoryId || 1, // Default to uncategorized if not set
            contentType: tabData.contentType || "article",
            timeSpent: timeSpent,
            learningDate: new Date().toISOString()
          }),
          credentials: 'include'
        })
        .then(response => response.json())
        .then(data => {
          console.log("Learning activity recorded", data);
          
          // Generate a quiz for this activity if it's long enough
          if (timeSpent > 120) { // If spent more than 2 minutes
            chrome.storage.local.set({
              'pendingQuiz': {
                activityId: data.id,
                title: tabData.title,
                url: tabData.url
              }
            });
          }
        })
        .catch(error => {
          console.error("Error recording learning activity:", error);
        });
      }
      
      // Remove the tab from tracking
      delete learningTabs[tabId];
      chrome.storage.local.set({learningTabs});
    }
  });
});

// Listen for tab updates to track learning content
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    // Detect if this is a learning site based on keywords or domains
    const learningDomains = [
      'coursera.org', 'udemy.com', 'khanacademy.org', 'youtube.com',
      'medium.com', 'dev.to', 'freecodecamp.org', 'github.com',
      'stackoverflow.com', 'tutorialspoint.com', 'w3schools.com',
      'mozilla.org', 'mdn', 'docs.microsoft.com', 'edx.org'
    ];
    
    const learningKeywords = [
      'learn', 'tutorial', 'course', 'education', 'documentation',
      'guide', 'howto', 'training', 'academy', 'lesson', 'coding'
    ];
    
    const domain = new URL(tab.url).hostname;
    const isLearningDomain = learningDomains.some(d => domain.includes(d));
    const isLearningTitle = tab.title && learningKeywords.some(k => 
      tab.title.toLowerCase().includes(k));
    
    if (isLearningDomain || isLearningTitle) {
      // This appears to be a learning page, start tracking it
      chrome.storage.local.get(['learningTabs'], function(result) {
        const learningTabs = result.learningTabs || {};
        
        // Only start tracking if it's a new page or not already tracked
        if (!learningTabs[tabId]) {
          learningTabs[tabId] = {
            url: tab.url,
            title: tab.title,
            startTime: Date.now(),
            contentType: domain.includes('youtube.com') ? 'video' : 'article'
          };
          
          chrome.storage.local.set({learningTabs});
          
          // Notify user that learning is being tracked
          chrome.action.setBadgeText({text: "ON"});
          chrome.action.setBadgeBackgroundColor({color: "#4CAF50"});
          
          // Reset badge after 3 seconds
          setTimeout(() => {
            chrome.action.setBadgeText({text: ""});
          }, 3000);
        }
      });
    }
  }
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "login") {
    userSession = {
      isLoggedIn: true,
      username: message.username,
      userId: message.userId
    };
    chrome.storage.local.set({userSession});
    sendResponse({success: true, message: "Login successful"});
  }
  
  if (message.action === "logout") {
    userSession = {
      isLoggedIn: false,
      username: "",
      userId: null
    };
    chrome.storage.local.set({userSession});
    sendResponse({success: true, message: "Logout successful"});
  }
  
  if (message.action === "checkLoginStatus") {
    sendResponse({
      isLoggedIn: userSession.isLoggedIn,
      username: userSession.username,
      userId: userSession.userId
    });
  }
  
  return true; // Keep the message channel open for async responses
});

// Check for a pending quiz on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['pendingQuiz'], function(result) {
    if (result.pendingQuiz) {
      // There's a pending quiz, we'll handle it when they open the popup
    }
  });
});

console.log("Learnfy.AI Background Script loaded");