// Learnfy.AI Extension Popup Script
document.addEventListener('DOMContentLoaded', function() {
  // Initialize components
  initializePopup();
  initializeCategories();
  initializeTracking();
  initializeVoiceControl();
  
  // Add sample data if using demo mode
  if (document.body.classList.contains('demo-mode')) {
    loadSampleContent();
  }
});

// Initialize the main popup functionality
function initializePopup() {
  // Elements
  const trackingContainer = document.getElementById('tracking-container');
  const notTrackingContainer = document.getElementById('not-tracking-container');
  const quizContainer = document.getElementById('quiz-container');
  const categoryList = document.getElementById('category-list');
  const changeCategoryBtn = document.getElementById('change-category-btn');
  
  // Initially hide quiz container
  if (quizContainer) {
    quizContainer.style.display = 'none';
  }
  
  // Enable debug controls with special key combo (Shift+Alt+D)
  document.addEventListener('keydown', function(event) {
    if (event.shiftKey && event.altKey && event.key === 'D') {
      const debugControls = document.getElementById('debug-controls');
      if (debugControls) {
        debugControls.style.display = debugControls.style.display === 'none' ? 'block' : 'none';
      }
    }
  });
  
  // Set up debug buttons
  setupDebugControls();
  
  // Toggle category list
  if (changeCategoryBtn && categoryList) {
    changeCategoryBtn.addEventListener('click', function() {
      categoryList.classList.toggle('visible');
    });
    
    // Close category list when clicking outside
    document.addEventListener('click', function(event) {
      if (!event.target.closest('.category-section') && categoryList.classList.contains('visible')) {
        categoryList.classList.remove('visible');
      }
    });
  }
  
  // Close button functionality
  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      window.close(); // In a real extension this would close the popup
    });
  }
}

// Initialize category selection
function initializeCategories() {
  const categoryOptions = document.querySelectorAll('.category-option');
  const selectedCategoryText = document.getElementById('selected-category');
  const categoryTag = document.querySelector('.category-tag');
  
  categoryOptions.forEach(option => {
    option.addEventListener('click', function() {
      const categoryName = this.getAttribute('data-category');
      const categoryColor = this.getAttribute('data-color');
      
      // Update selected category text
      if (selectedCategoryText) {
        selectedCategoryText.textContent = categoryName;
      }
      
      // Update category tag color
      if (categoryTag) {
        categoryTag.className = 'category-tag';
        categoryTag.classList.add(categoryColor);
      }
      
      // Hide category list
      document.getElementById('category-list').classList.remove('visible');
      
      // In a real extension, we would save this selection
      console.log('Category selected:', categoryName);
      
      // Show notification for demo
      showNotification('Category updated to ' + categoryName);
    });
  });
}

// Initialize tracking functionality
function initializeTracking() {
  const toggleTrackingBtn = document.getElementById('toggle-tracking-btn');
  const trackingContainer = document.getElementById('tracking-container');
  const notTrackingContainer = document.getElementById('not-tracking-container');
  const addNoteBtn = document.getElementById('add-note-btn');
  
  if (toggleTrackingBtn) {
    toggleTrackingBtn.addEventListener('click', function() {
      const isTracking = toggleTrackingBtn.classList.contains('pause-btn');
      
      if (isTracking) {
        // Pause tracking
        toggleTrackingBtn.classList.remove('pause-btn');
        toggleTrackingBtn.classList.add('resume-btn');
        toggleTrackingBtn.textContent = 'Resume Tracking';
        
        // In a real extension, we would pause the tracking
        console.log('Tracking paused');
        showNotification('Tracking paused');
      } else {
        // Resume tracking
        toggleTrackingBtn.classList.remove('resume-btn');
        toggleTrackingBtn.classList.add('pause-btn');
        toggleTrackingBtn.textContent = 'Pause Tracking';
        
        // In a real extension, we would resume the tracking
        console.log('Tracking resumed');
        showNotification('Tracking resumed');
      }
    });
  }
  
  if (addNoteBtn) {
    addNoteBtn.addEventListener('click', function() {
      // Show note input dialog
      const note = prompt('Add a note about this content:');
      
      if (note && note.trim() !== '') {
        // In a real extension, we would save this note
        console.log('Note added:', note);
        showNotification('Note added');
      }
    });
  }
  
  // Demo: Toggle between tracking and not tracking views
  const demoToggleView = document.getElementById('demo-toggle-view');
  if (demoToggleView) {
    demoToggleView.addEventListener('click', function() {
      if (trackingContainer && notTrackingContainer) {
        const isTracking = trackingContainer.style.display !== 'none';
        
        if (isTracking) {
          trackingContainer.style.display = 'none';
          notTrackingContainer.style.display = 'block';
          demoToggleView.textContent = 'Show Tracking View';
        } else {
          trackingContainer.style.display = 'block';
          notTrackingContainer.style.display = 'none';
          demoToggleView.textContent = 'Show Not Tracking View';
        }
      }
    });
  }
}

// Initialize voice control
function initializeVoiceControl() {
  const voiceToggleBtn = document.getElementById('voice-toggle-btn');
  
  if (voiceToggleBtn) {
    voiceToggleBtn.addEventListener('click', function() {
      const isActive = voiceToggleBtn.classList.contains('active');
      
      if (isActive) {
        voiceToggleBtn.classList.remove('active');
        // In a real extension, we would disable voice control
        console.log('Voice control disabled');
        showNotification('Voice control disabled');
      } else {
        voiceToggleBtn.classList.add('active');
        // In a real extension, we would enable voice control
        console.log('Voice control enabled');
        showNotification('Voice control enabled - try saying "Hey Learnfy"');
      }
    });
  }
}

// Load sample content for demo
function loadSampleContent() {
  // Update tracking time
  const trackingTime = document.getElementById('tracking-time');
  if (trackingTime) {
    trackingTime.textContent = '12:45';
  }
  
  // Update content title and source
  const contentTitle = document.querySelector('.content-details h3');
  const contentSource = document.querySelector('.content-details p');
  
  if (contentTitle && contentSource) {
    contentTitle.textContent = 'Introduction to Machine Learning';
    contentSource.textContent = 'Medium · 8 min read';
  }
}

// Show notification
function showNotification(message, isAchievement = false) {
  const notification = document.createElement('div');
  notification.className = 'notification';
  
  // If achievement, add achievement styling and icon
  if (isAchievement) {
    notification.classList.add('achievement-notification');
    notification.innerHTML = `
      <span class="material-icons achievement-icon">emoji_events</span>
      <div>
        <div class="achievement-title">Achievement Unlocked!</div>
        <div class="achievement-message">${message}</div>
      </div>
    `;
    
    // Trigger confetti celebration if available
    if (window.confetti) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  } else {
    notification.textContent = message;
  }
  
  document.body.appendChild(notification);
  
  // Animation
  setTimeout(() => {
    notification.classList.add('show');
  }, 10);
  
  // Remove after duration (longer for achievements)
  const duration = isAchievement ? 5000 : 3000;
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, duration);
}

// Show quiz
function showQuiz() {
  const trackingContainer = document.getElementById('tracking-container');
  const notTrackingContainer = document.getElementById('not-tracking-container');
  const quizContainer = document.getElementById('quiz-container');
  
  if (trackingContainer) trackingContainer.style.display = 'none';
  if (notTrackingContainer) notTrackingContainer.style.display = 'none';
  if (quizContainer) quizContainer.style.display = 'block';
  
  // In a real extension, we would load questions from the backend
  const questions = [
    {
      question: 'What is the main difference between supervised and unsupervised learning?',
      options: [
        'Supervised learning requires labeled data, unsupervised doesn\'t',
        'Unsupervised learning is faster than supervised learning',
        'Supervised learning only works with numerical data',
        'Unsupervised learning always uses neural networks'
      ],
      correctOptionIndex: 0
    },
    {
      question: 'Which of these is NOT a type of machine learning algorithm?',
      options: [
        'Decision Trees',
        'Neural Networks',
        'Random Forests',
        'Quantum Predictors'
      ],
      correctOptionIndex: 3
    }
  ];
  
  // Initialize quiz
  initializeQuiz(questions);
}

// Initialize quiz functionality
function initializeQuiz(questions) {
  let currentQuestionIndex = 0;
  const quizQuestions = document.getElementById('quiz-questions');
  const nextQuestionBtn = document.getElementById('next-question-btn');
  const previousQuestionBtn = document.getElementById('previous-question-btn');
  const finishQuizBtn = document.getElementById('finish-quiz-btn');
  
  // Render first question
  if (quizQuestions) {
    renderQuestion(questions[currentQuestionIndex], currentQuestionIndex);
  }
  
  // Navigation buttons
  if (nextQuestionBtn) {
    nextQuestionBtn.addEventListener('click', function() {
      if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        renderQuestion(questions[currentQuestionIndex], currentQuestionIndex);
        
        // Update navigation buttons
        previousQuestionBtn.disabled = false;
        if (currentQuestionIndex === questions.length - 1) {
          nextQuestionBtn.style.display = 'none';
          finishQuizBtn.style.display = 'block';
        }
      }
    });
  }
  
  if (previousQuestionBtn) {
    previousQuestionBtn.addEventListener('click', function() {
      if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        renderQuestion(questions[currentQuestionIndex], currentQuestionIndex);
        
        // Update navigation buttons
        nextQuestionBtn.style.display = 'block';
        finishQuizBtn.style.display = 'none';
        if (currentQuestionIndex === 0) {
          previousQuestionBtn.disabled = true;
        }
      }
    });
  }
  
  if (finishQuizBtn) {
    finishQuizBtn.addEventListener('click', function() {
      // In a real extension, we would calculate score and save results
      console.log('Quiz completed');
      showNotification('Quiz completed! Score: 80%');
      
      // Redirect to results page in demo
      window.location.href = 'quiz-results.html';
    });
  }
}

// Render a question
function renderQuestion(question, index) {
  const quizQuestions = document.getElementById('quiz-questions');
  if (!quizQuestions) return;
  
  // Create question element
  const questionHTML = `
    <div class="quiz-question-container">
      <div class="quiz-question-number">Question ${index + 1} of 5</div>
      <h3 class="quiz-question">${question.question}</h3>
      <div class="quiz-options">
        ${question.options.map((option, i) => `
          <div class="quiz-option" data-index="${i}">
            <div class="quiz-option-letter">${String.fromCharCode(65 + i)}</div>
            <div class="quiz-option-text">${option}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  
  quizQuestions.innerHTML = questionHTML;
  
  // Add click handlers to options
  const optionElements = quizQuestions.querySelectorAll('.quiz-option');
  optionElements.forEach(option => {
    option.addEventListener('click', function() {
      // Remove selected class from all options
      optionElements.forEach(opt => opt.classList.remove('selected'));
      
      // Add selected class to clicked option
      this.classList.add('selected');
      
      // Get selected option index
      const selectedIndex = parseInt(this.getAttribute('data-index'));
      
      // Check if answer is correct
      const isCorrect = selectedIndex === question.correctOptionIndex;
      
      // In a real extension, we would save this answer
      console.log('Selected option:', selectedIndex, 'Correct:', isCorrect);
      
      // Show feedback
      if (isCorrect) {
        this.classList.add('correct');
        showNotification('Correct answer!');
      } else {
        this.classList.add('incorrect');
        optionElements[question.correctOptionIndex].classList.add('correct');
        showNotification('Incorrect answer!');
      }
    });
  });
}

// Setup debug controls
function setupDebugControls() {
  // Get debug buttons
  const debugAddPoints = document.getElementById('debug-add-points');
  const debugAddStreak = document.getElementById('debug-add-streak');
  const debugLevelUp = document.getElementById('debug-level-up');
  
  // Add points button
  if (debugAddPoints) {
    debugAddPoints.addEventListener('click', function() {
      if (window.gamification) {
        gamification.addPoints(25, 'Debug: Added points');
        console.log('Debug: Added 25 points');
      }
    });
  }
  
  // Add streak button
  if (debugAddStreak) {
    debugAddStreak.addEventListener('click', function() {
      if (window.gamification) {
        gamification.streak += 1;
        gamification.updateUI();
        console.log('Debug: Added 1 streak day');
        showNotification('Streak day added!');
      }
    });
  }
  
  // Test level up button
  if (debugLevelUp) {
    debugLevelUp.addEventListener('click', function() {
      if (window.gamification) {
        // Direct call to level up animation
        gamification.showLevelUpAnimation();
        console.log('Debug: Testing level up animation');
      } else {
        // Fallback to our standalone level-up animation
        showLevelUpAnimation();
        console.log('Debug: Testing level up animation');
      }
    });
  }
  
  // Show debug controls - visible by default for development
  setTimeout(() => {
    // Make debug controls visible in development
    const debugControls = document.getElementById('debug-controls');
    if (debugControls) {
      debugControls.style.display = 'block';
    }
  }, 1000);
}