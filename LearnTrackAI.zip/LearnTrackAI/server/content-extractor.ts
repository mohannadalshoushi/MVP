import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

// Extract text content from an HTML string
export async function extractContentFromHtml(html: string): Promise<string> {
  try {
    // Basic cleaning of HTML
    const cleanHtml = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<nav\b[^<]*(?:(?!<\/nav>)<[^<]*)*<\/nav>/gi, '')
      .replace(/<footer\b[^<]*(?:(?!<\/footer>)<[^<]*)*<\/footer>/gi, '')
      .replace(/<header\b[^<]*(?:(?!<\/header>)<[^<]*)*<\/header>/gi, '')
      .replace(/<aside\b[^<]*(?:(?!<\/aside>)<[^<]*)*<\/aside>/gi, '');

    // First try to identify article tags or main content sections
    const articleMatch = /<article[\s\S]*?>([\s\S]*?)<\/article>/i.exec(cleanHtml);
    const mainMatch = /<main[\s\S]*?>([\s\S]*?)<\/main>/i.exec(cleanHtml);
    
    let extractedContent = '';
    
    if (articleMatch && articleMatch[1]) {
      extractedContent = articleMatch[1];
    } else if (mainMatch && mainMatch[1]) {
      extractedContent = mainMatch[1];
    } else {
      // Try to extract content div with typical classnames
      const contentRegexes = [
        /<div[^>]*class="[^"]*content[^"]*"[^>]*>([\s\S]*?)<\/div>/i,
        /<div[^>]*class="[^"]*article[^"]*"[^>]*>([\s\S]*?)<\/div>/i,
        /<div[^>]*class="[^"]*post[^"]*"[^>]*>([\s\S]*?)<\/div>/i,
        /<div[^>]*class="[^"]*entry[^"]*"[^>]*>([\s\S]*?)<\/div>/i
      ];
      
      for (const regex of contentRegexes) {
        const match = regex.exec(cleanHtml);
        if (match && match[1]) {
          extractedContent = match[1];
          break;
        }
      }
    }
    
    // If we found content with regex, clean it up
    if (extractedContent) {
      // Remove HTML tags, keep text content
      extractedContent = extractedContent
        .replace(/<[^>]*>/g, ' ') // Replace tags with spaces
        .replace(/\s+/g, ' ')     // Normalize whitespace
        .trim();
    }
    
    // If we couldn't extract via regex, or extracted content is too short, use OpenAI
    if (!extractedContent || extractedContent.length < 200) {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: 
              "You are a content extraction assistant. Extract only the main article content from this HTML. " +
              "Ignore navigation, headers, footers, sidebars, comments, and advertisements. " +
              "Return only the meaningful text of the article content.",
          },
          {
            role: "user",
            content: cleanHtml,
          },
        ],
        max_tokens: 1500,
      });

      return response.choices[0].message.content || "";
    }
    
    return extractedContent;
  } catch (error) {
    console.error("Error extracting content from HTML:", error);
    throw new Error("Failed to extract content from HTML");
  }
}

// Extract a transcript from YouTube video ID or URL
export async function extractYouTubeTranscript(videoIdOrUrl: string): Promise<string> {
  try {
    // Extract video ID from the URL
    let videoId = videoIdOrUrl;
    if (videoIdOrUrl.includes('youtube.com') || videoIdOrUrl.includes('youtu.be')) {
      const url = new URL(videoIdOrUrl);
      if (url.hostname === 'youtu.be') {
        videoId = url.pathname.slice(1);
      } else {
        videoId = url.searchParams.get('v') || '';
      }
    }

    if (!videoId) {
      throw new Error("Could not extract video ID from URL");
    }

    // In a production environment, we'd use YouTube's API with proper auth
    // For this implementation, we'll use OpenAI to analyze the video based on its ID
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: 
            "You are a YouTube content assistant. Based on the provided YouTube video ID, " +
            "generate a detailed transcript-like summary of what this video likely contains. " +
            "Focus on creating a useful learning resource about the topic indicated by the video ID. " +
            "Format your response as if it were an actual transcript, with detailed information " +
            "that would be valuable for a learner trying to understand this topic.",
        },
        {
          role: "user",
          content: `YouTube Video ID: ${videoId}. Please generate a transcript-like summary that would be useful for learning purposes.`,
        },
      ],
      max_tokens: 1500,
    });

    return response.choices[0].message.content || 
      `Could not generate transcript for YouTube video ID: ${videoId}. Please try another video.`;
  } catch (error) {
    console.error("Error extracting YouTube transcript:", error);
    throw new Error("Failed to extract transcript from YouTube video");
  }
}

// Preprocess URL to determine content type and source
export function preprocessUrl(url: string): {
  contentType: 'article' | 'video';
  source: string;
} {
  const urlObj = new URL(url);
  const hostname = urlObj.hostname;
  
  // Check for YouTube
  if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
    return {
      contentType: 'video',
      source: 'youtube.com'
    };
  }
  
  // Default to article and extract domain
  return {
    contentType: 'article',
    source: hostname.replace('www.', '')
  };
}

export default {
  extractContentFromHtml,
  extractYouTubeTranscript,
  preprocessUrl
};
