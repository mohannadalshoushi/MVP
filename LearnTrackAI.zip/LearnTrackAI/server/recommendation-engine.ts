import { User, LearningActivity, Category, RecommendedContent } from "@shared/schema";
import { storage } from "./storage";
import OpenAI from "openai";

// Initialize OpenAI
let openai: OpenAI | null = null;
try {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("OPENAI_API_KEY not found in environment. Personalized recommendations will be disabled.");
  } else {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
    console.log("OpenAI API initialized for recommendation engine");
  }
} catch (error) {
  console.error("Failed to initialize OpenAI API:", error);
}

/**
 * Generates recommendations based on user's learning history and preferences
 */
export async function generateRecommendations(
  user: User,
  limit: number = 5
): Promise<RecommendedContent[]> {
  try {
    // Get user's learning activities
    const activities = await storage.getLearningActivities(user.id);
    
    // If the user has no activities, return default recommendations
    if (!activities || activities.length === 0) {
      return generateDefaultRecommendations(user);
    }
    
    // Create a user profile based on learning activities
    const userProfile = await createUserProfile(user, activities);
    
    // Use OpenAI to generate personalized recommendations
    return await generatePersonalizedRecommendations(userProfile, limit);
  } catch (error) {
    console.error("Error generating recommendations:", error);
    return generateDefaultRecommendations(user);
  }
}

/**
 * Creates a user profile based on their learning history
 */
async function createUserProfile(user: User, activities: LearningActivity[]): Promise<any> {
  // Get all categories
  const categories = await storage.getCategories();
  
  // Count activities per category
  const categoryCounts: { [key: number]: number } = {};
  
  for (const activity of activities) {
    if (!categoryCounts[activity.categoryId]) {
      categoryCounts[activity.categoryId] = 0;
    }
    categoryCounts[activity.categoryId]++;
  }
  
  // Get top categories
  const topCategories = Object.entries(categoryCounts)
    .map(([categoryId, count]) => ({
      category: categories.find(c => c.id === parseInt(categoryId)),
      count
    }))
    .filter(item => item.category) // Filter out undefined categories
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map(item => item.category!);
  
  // Get recent activities with valid dates
  const activitiesWithDates = activities.filter(a => a.learningDate != null);
  
  // Sort them by date (most recent first) and take the 5 most recent
  const recentActivities = activitiesWithDates
    .sort((a, b) => {
      // Convert dates to timestamps for comparison
      const timestampA = a.learningDate instanceof Date 
        ? a.learningDate.getTime() 
        : new Date(String(a.learningDate)).getTime();
      
      const timestampB = b.learningDate instanceof Date 
        ? b.learningDate.getTime() 
        : new Date(String(b.learningDate)).getTime();
      
      return timestampB - timestampA;
    })
    .slice(0, 5);
  
  // Count content types
  const contentTypeCounts = {
    article: activities.filter(a => a.contentType === "article").length,
    video: activities.filter(a => a.contentType === "video").length
  };
  
  // Create the user profile
  return {
    userId: user.id,
    sector: user.sector,
    topCategories,
    recentActivities,
    contentTypePreference: contentTypeCounts.article > contentTypeCounts.video ? "article" : "video",
    totalActivities: activities.length
  };
}

/**
 * Generates personalized recommendations using OpenAI
 */
async function generatePersonalizedRecommendations(userProfile: any, limit: number): Promise<RecommendedContent[]> {
  try {
    // Check if there are categories and activities
    const hasCategories = Array.isArray(userProfile.topCategories) && userProfile.topCategories.length > 0;
    const hasActivities = Array.isArray(userProfile.recentActivities) && userProfile.recentActivities.length > 0;
    
    // Extract category names and recent activity titles with fallbacks for empty arrays
    const categoryNames = hasCategories 
      ? userProfile.topCategories.map((cat: Category) => cat.name)
      : ["General Learning"];
      
    const recentTitles = hasActivities
      ? userProfile.recentActivities.map((activity: LearningActivity) => activity.title)
      : ["General professional development"];
    
    // Create a prompt for OpenAI
    const prompt = `
      Based on a user with the following learning profile:
      - Sector: ${userProfile.sector || "Unknown"}
      - Top categories: ${categoryNames.join(", ")}
      - Recent learning activities: ${recentTitles.join(", ")}
      - Preferred content type: ${userProfile.contentTypePreference}
      
      Generate ${limit} recommended learning resources that would be relevant and valuable for this user's professional development.
      
      For each recommendation, provide the following fields in JSON format:
      - title: The title of the content
      - description: A brief description (2-3 sentences)
      - timeToRead: Estimated time to consume the content (e.g., "5 min read", "20 min video")
      - source: The content provider (e.g., "medium.com", "youtube.com", "coursera.org")
      - contentType: Either "article" or "video"
      - category: One of the top categories that most closely matches the content
      - url: A plausible URL for this content
      - relevanceScore: A score from 1-100 indicating how relevant this is to the user
      
      Each recommendation should be realistic, specific, and tailored to the user's professional interests.
    `;
    
    // Check if OpenAI is initialized
    if (!openai) {
      console.warn("OpenAI API not initialized. Falling back to default recommendations.");
      throw new Error("OpenAI API not available");
    }
    
    // Call OpenAI to generate recommendations
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a personalized learning recommendation system." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the response
    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }
    
    const recommendations = JSON.parse(content);
    
    // Map the API response to our RecommendedContent type
    return recommendations.recommendations.map((rec: any, index: number) => {
      // Get categories from storage if userProfile doesn't have any 
      const hasCategories = Array.isArray(userProfile.topCategories) && userProfile.topCategories.length > 0;
      
      // Find matching category or use a default one
      let category;
      if (hasCategories) {
        category = userProfile.topCategories.find((cat: Category) => 
          cat.name.toLowerCase() === rec.category.toLowerCase()
        ) || userProfile.topCategories[0];
      } else {
        // Default category if none are available - will be populated from DB later
        category = {
          id: 1,
          name: rec.category || "General Learning",
          icon: "school",
          color: "#3B82F6"
        };
      }
      
      return {
        id: index + 1, // Generate temporary IDs
        title: rec.title,
        description: rec.description,
        category,
        timeToRead: rec.timeToRead,
        source: rec.source,
        imageUrl: getImageUrlForSource(rec.source, rec.contentType),
        contentType: rec.contentType,
        url: rec.url,
        relevanceScore: rec.relevanceScore
      };
    });
  } catch (error) {
    console.error("Error generating personalized recommendations:", error);
    throw error;
  }
}

/**
 * Generates default recommendations based on user sector
 */
async function generateDefaultRecommendations(user: User): Promise<RecommendedContent[]> {
  // Get all categories
  const categories = await storage.getCategories();
  
  // Default recommendations based on common professional topics
  const defaults = [
    {
      title: "Introduction to Data Analysis",
      description: "Learn the fundamentals of data analysis and how to make data-driven decisions.",
      categoryName: "Data Analysis",
      timeToRead: "15 min read",
      source: "medium.com",
      contentType: "article" as const,
      url: "https://medium.com/introduction-to-data-analysis"
    },
    {
      title: "Effective Communication in the Workplace",
      description: "Discover techniques to improve your communication skills with colleagues and clients.",
      categoryName: "Communication",
      timeToRead: "10 min read",
      source: "harvard.edu",
      contentType: "article" as const,
      url: "https://harvard.edu/business/effective-communication"
    },
    {
      title: "Intro to Project Management Methodologies",
      description: "Compare different project management approaches and find what works for your team.",
      categoryName: "Project Management",
      timeToRead: "20 min video",
      source: "youtube.com",
      contentType: "video" as const,
      url: "https://youtube.com/watch?v=project-management-intro"
    },
    {
      title: "Digital Marketing Fundamentals",
      description: "Master the basics of digital marketing for any industry or business size.",
      categoryName: "Marketing",
      timeToRead: "12 min read",
      source: "hubspot.com",
      contentType: "article" as const,
      url: "https://hubspot.com/digital-marketing-fundamentals"
    },
    {
      title: "Introduction to UX/UI Design",
      description: "Learn the principles of user experience and interface design for digital products.",
      categoryName: "Design",
      timeToRead: "25 min video",
      source: "youtube.com",
      contentType: "video" as const,
      url: "https://youtube.com/watch?v=ux-ui-design-intro"
    }
  ];
  
  // Map default recommendations to RecommendedContent type
  return defaults.map((rec, index) => {
    // Find matching category or use the first one
    const category = categories.find(c => 
      c.name.toLowerCase() === rec.categoryName.toLowerCase()
    ) || categories[0];
    
    return {
      id: index + 1,
      title: rec.title,
      description: rec.description,
      category,
      timeToRead: rec.timeToRead,
      source: rec.source,
      imageUrl: getImageUrlForSource(rec.source, rec.contentType),
      contentType: rec.contentType,
      url: rec.url,
      relevanceScore: 70 // Default relevance score
    };
  });
}

/**
 * Returns a placeholder image URL based on content source and type
 */
function getImageUrlForSource(source: string, contentType: string): string {
  if (source.includes("youtube")) {
    return "https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  } else if (source.includes("medium")) {
    return "https://images.unsplash.com/photo-1542435503-956c469947f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  } else if (source.includes("harvard")) {
    return "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  } else if (source.includes("hubspot")) {
    return "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  } else if (contentType === "video") {
    return "https://images.unsplash.com/photo-1576267423445-b2e0074d68a4?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  } else {
    return "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?ixlib=rb-1.2.1&auto=format&fit=crop&w=640&q=80";
  }
}