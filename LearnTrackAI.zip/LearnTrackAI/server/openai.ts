import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

// Extract and summarize content from the provided text
export async function summarizeContent(text: string, category?: string): Promise<string> {
  const prompt = `Please summarize the following ${category || ''} content concisely while maintaining key points and important concepts:\n\n${text}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 500,
  });

  return response.choices[0].message.content || "Failed to generate summary";
}

// Generate a learning category based on the content
export async function categorizeContent(text: string): Promise<{
  category: string;
  confidence: number;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a content categorization expert. Analyze the text and determine which professional category it belongs to (Marketing, Sales, Design, Web Development, Data Science, Business, etc.). Provide the category name and a confidence score between 0 and 1. Respond with JSON in this format: { 'category': string, 'confidence': number }",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      category: result.category || "Uncategorized",
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
    };
  } catch (error) {
    console.error("Failed to categorize content:", error);
    return {
      category: "Uncategorized",
      confidence: 0,
    };
  }
}

// Generate quiz questions based on content
export async function generateQuizQuestions(content: string, numQuestions: number = 3): Promise<Array<{
  question: string;
  options: string[];
  correctOption: number;
}>> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            `You are a quiz generator. Create ${numQuestions} multiple-choice questions based on the provided content. Each question should have 4 answer options with exactly one correct option. Make the questions meaningful to test comprehension of key concepts. Respond with JSON in this format: 
            [
              {
                "question": "Question text?",
                "options": ["Option A", "Option B", "Option C", "Option D"],
                "correctOption": 0
              }
            ]
            Where correctOption is the zero-based index of the correct answer.`,
        },
        {
          role: "user",
          content: content,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return Array.isArray(result) ? result : [];
  } catch (error) {
    console.error("Failed to generate quiz questions:", error);
    return [];
  }
}

// Generate a CV-ready summary of learning
export async function generateCVSummary(activities: any[], category: string): Promise<string> {
  try {
    if (!activities || activities.length === 0) {
      return "No learning activities found for this category. Start tracking your learning to build your CV summary.";
    }

    // Format activities with more detailed information
    const activitySummaries = activities.map(a => {
      const timeSpent = Math.round((a.timeSpent || 0) / 60); // Convert seconds to minutes
      const quizScore = a.quizScore ? `${a.quizScore}% quiz score` : 'No quiz taken';
      const date = a.learningDate ? new Date(a.learningDate).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      }) : 'Unknown date';
      
      return `- ${a.title} (${a.source}, ${date})
  * Time spent: ${timeSpent} minutes
  * Content type: ${a.contentType || 'article'}
  * ${quizScore}
  * Summary: ${a.summary || 'No summary available'}`
    }).join('\n\n');
    
    // Get the current date for context
    const currentDate = new Date().toISOString().split('T')[0];
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: 
            `You are an expert professional development writer specializing in CV and resume writing.
            
            Create a compelling, professional summary of expertise in the "${category}" field based on the learning activities provided.
            Focus on translating learning activities into professional skills and knowledge gained.
            
            The summary should:
            1. Be written in first person perspective for use in a CV/LinkedIn
            2. Start with a strong professional headline relevant to the ${category} field
            3. Highlight specific skills developed through these learning activities
            4. Demonstrate how this learning translates to practical professional capabilities
            5. Use confident, achievement-oriented language
            6. Include measurable achievements where possible
            7. Be well-structured with 2-3 paragraphs focusing on different aspects of expertise
            8. Be under 250 words and optimized for professional impact
            
            Today's date: ${currentDate}`,
        },
        {
          role: "user",
          content: `Learning activities in the "${category}" category:\n${activitySummaries}`,
        },
      ],
      max_tokens: 600,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Failed to generate CV summary:", error);
    return "Failed to generate summary. Please try again later.";
  }
}

export default {
  summarizeContent,
  categorizeContent,
  generateQuizQuestions,
  generateCVSummary
};
