import { 
  LearningActivity, 
  InsertLearningMilestone, 
  LearningMilestone,
  LearningProgressEvent
} from "../shared/schema";
import { storage } from "./storage";

/**
 * Service for tracking, creating, and maintaining learning milestones
 */
// Helper to generate a unique share URL
function generateShareUrl(milestoneId: number): string {
  const baseUrl = process.env.BASE_URL || 'https://learnfy.ai';
  // Generate a unique but reproducible ID based on the milestone ID
  const uniqueId = Buffer.from(`milestone-${milestoneId}-${Date.now()}`).toString('base64');
  return `${baseUrl}/share/${uniqueId}`;
}

export const milestoneService = {
  /**
   * Check for and create new milestones based on user activities
   */
  async checkMilestones(userId: number): Promise<LearningMilestone[]> {
    const newMilestones: LearningMilestone[] = [];
    
    try {
      // Get user's learning activities
      const activities = await storage.getLearningActivities(userId);
      
      // Don't proceed if user has no activities
      if (activities.length === 0) {
        return [];
      }
      
      // Get existing milestones to avoid duplicates
      const existingMilestones = await storage.getLearningMilestones(userId);
      
      // Calculate various metrics
      const totalTimeSpent = activities.reduce((sum, activity) => sum + activity.timeSpent, 0);
      const totalHours = Math.floor(totalTimeSpent / 3600);
      
      const articleCount = activities.filter(a => a.contentType === "article").length;
      const videoCount = activities.filter(a => a.contentType === "video").length;
      
      const quizScores = activities
        .filter(a => a.quizScore !== null && a.quizScore !== undefined)
        .map(a => a.quizScore as number);
      
      const avgQuizScore = quizScores.length > 0 
        ? quizScores.reduce((sum, score) => sum + score, 0) / quizScores.length 
        : 0;
      
      // Check for time-based milestones
      const timeBasedMilestones = [
        {hours: 1, title: "First Hour of Learning", description: "You've spent your first hour learning!"},
        {hours: 5, title: "Five Hours of Learning", description: "You've dedicated 5 hours to expanding your knowledge."},
        {hours: 10, title: "Ten Hours Club", description: "You've invested 10 hours in your professional development."},
        {hours: 25, title: "Quarter Century", description: "25 hours of learning accumulated. Great dedication!"},
        {hours: 50, title: "Half Century", description: "You've reached 50 hours of learning. Impressive commitment!"},
        {hours: 100, title: "Century Club", description: "100 hours of learning! You're truly dedicated to growth."}
      ];
      
      for (const milestone of timeBasedMilestones) {
        if (totalHours >= milestone.hours && 
            !existingMilestones.some(m => 
              m.milestoneType === "time" && 
              m.title === milestone.title
            )) {
          const newMilestone = await this.createMilestone({
            userId,
            title: milestone.title,
            description: milestone.description,
            milestoneType: "time",
            iconName: "schedule",
            isHidden: false
          });
          
          if (newMilestone) {
            newMilestones.push(newMilestone);
          }
        }
      }
      
      // Check for content count milestones
      const contentMilestones = [
        {count: 5, title: "5 Learning Activities", description: "You've completed 5 learning activities. Keep it up!"},
        {count: 10, title: "Double Digits", description: "10 learning activities completed. You're building momentum!"},
        {count: 25, title: "Knowledge Hunter", description: "25 learning activities and counting. Impressive progress!"},
        {count: 50, title: "Learning Enthusiast", description: "You've completed 50 learning activities. Amazing dedication!"},
        {count: 100, title: "Century Learner", description: "100 learning activities! You're a true lifelong learner."}
      ];
      
      for (const milestone of contentMilestones) {
        if (activities.length >= milestone.count && 
            !existingMilestones.some(m => 
              m.milestoneType === "content_count" && 
              m.title === milestone.title
            )) {
          const newMilestone = await this.createMilestone({
            userId,
            title: milestone.title,
            description: milestone.description,
            milestoneType: "content_count",
            iconName: "menu_book",
            isHidden: false
          });
          
          if (newMilestone) {
            newMilestones.push(newMilestone);
          }
        }
      }
      
      // Check for quiz score milestones
      if (quizScores.length >= 5) {
        const quizMilestones = [
          {score: 70, title: "Quiz Proficient", description: "Achieved an average quiz score of 70% or higher."},
          {score: 80, title: "Quiz Expert", description: "Achieved an average quiz score of 80% or higher."},
          {score: 90, title: "Quiz Master", description: "Achieved an average quiz score of 90% or higher."},
          {score: 95, title: "Quiz Virtuoso", description: "Achieved an average quiz score of 95% or higher. Exceptional!"}
        ];
        
        for (const milestone of quizMilestones) {
          if (avgQuizScore >= milestone.score && 
              !existingMilestones.some(m => 
                m.milestoneType === "quiz_score" && 
                m.title === milestone.title
              )) {
            const newMilestone = await this.createMilestone({
              userId,
              title: milestone.title,
              description: milestone.description,
              milestoneType: "quiz_score",
              iconName: "quiz",
              isHidden: false
            });
            
            if (newMilestone) {
              newMilestones.push(newMilestone);
            }
          }
        }
      }
      
      // Check for streak milestones
      const streak = await this.calculateCurrentStreak(userId);
      
      const streakMilestones = [
        {days: 3, title: "3-Day Streak", description: "You've learned for 3 days in a row!"},
        {days: 7, title: "Week Warrior", description: "7-day learning streak achieved!"},
        {days: 14, title: "Two Week Triumph", description: "14 consecutive days of learning. Incredible discipline!"},
        {days: 30, title: "30-Day Dedication", description: "A full month of daily learning. Outstanding commitment!"},
        {days: 60, title: "60-Day Scholar", description: "Two months of consistent daily learning. Remarkable!"},
        {days: 100, title: "100-Day Legend", description: "100 days of consecutive learning. You're unstoppable!"}
      ];
      
      for (const milestone of streakMilestones) {
        if (streak >= milestone.days && 
            !existingMilestones.some(m => 
              m.milestoneType === "streak" && 
              m.title === milestone.title
            )) {
          const newMilestone = await this.createMilestone({
            userId,
            title: milestone.title,
            description: milestone.description,
            milestoneType: "streak",
            iconName: "local_fire_department",
            isHidden: false
          });
          
          if (newMilestone) {
            newMilestones.push(newMilestone);
          }
        }
      }
      
      return newMilestones;
    } catch (error) {
      console.error("Error checking for milestones:", error);
      return [];
    }
  },
  
  /**
   * Create a new milestone
   */
  async createMilestone(milestoneData: InsertLearningMilestone): Promise<LearningMilestone | null> {
    try {
      return await storage.createLearningMilestone(milestoneData);
    } catch (error) {
      console.error("Error creating milestone:", error);
      return null;
    }
  },
  
  /**
   * Mark a milestone as celebrated
   */
  async celebrateMilestone(milestoneId: number): Promise<LearningMilestone | null> {
    try {
      return await storage.updateLearningMilestone(milestoneId, {
        celebratedAt: new Date()
      });
    } catch (error) {
      console.error("Error celebrating milestone:", error);
      return null;
    }
  },
  
  /**
   * Get all uncelebrated milestones for a user
   */
  async getUncelebratedMilestones(userId: number): Promise<LearningMilestone[]> {
    try {
      const allMilestones = await storage.getLearningMilestones(userId);
      return allMilestones.filter(milestone => !milestone.celebratedAt && !milestone.isHidden);
    } catch (error) {
      console.error("Error getting uncelebrated milestones:", error);
      return [];
    }
  },
  
  /**
   * Get learning progress timeline events
   */
  async getLearningTimeline(userId: number, limit: number = 50): Promise<LearningProgressEvent[]> {
    try {
      const activities = await storage.getLearningActivities(userId);
      const milestones = await storage.getLearningMilestones(userId);
      const categories = await storage.getCategories();
      
      // Convert activities to timeline events
      const activityEvents: LearningProgressEvent[] = activities.map((activity, index) => {
        const category = categories.find(c => c.id === activity.categoryId);
        
        return {
          id: index + 1, // Temporary ID for ordering
          userId,
          date: new Date(activity.learningDate),
          eventType: "activity",
          title: activity.title,
          description: `${activity.contentType === "article" ? "Read article" : "Watched video"} from ${activity.source}`,
          iconName: activity.contentType === "article" ? "article" : "play_circle",
          iconColor: category?.color || "#6366F1",
          metadata: {
            activityId: activity.id,
            categoryId: activity.categoryId,
            quizScore: activity.quizScore
          }
        };
      });
      
      // Convert milestones to timeline events
      const milestoneEvents: LearningProgressEvent[] = milestones.map((milestone, index) => {
        let iconColor = "#10B981"; // Default green color for milestones
        
        // Assign colors based on milestone type
        switch (milestone.milestoneType) {
          case "time":
            iconColor = "#6366F1"; // Purple
            break;
          case "content_count":
            iconColor = "#F59E0B"; // Amber
            break;
          case "quiz_score":
            iconColor = "#3B82F6"; // Blue
            break;
          case "streak":
            iconColor = "#EF4444"; // Red
            break;
        }
        
        return {
          id: activities.length + index + 1, // Continue ID sequence after activities
          userId,
          date: new Date(milestone.achievedAt),
          eventType: "milestone",
          title: milestone.title,
          description: milestone.description,
          iconName: milestone.iconName,
          iconColor,
          metadata: {
            milestoneId: milestone.id
          }
        };
      });
      
      // Combine and sort all events by date (newest first)
      const allEvents = [...activityEvents, ...milestoneEvents]
        .sort((a, b) => b.date.getTime() - a.date.getTime())
        .slice(0, limit);
      
      // Reassign proper sequential IDs
      return allEvents.map((event, index) => ({
        ...event,
        id: index + 1
      }));
    } catch (error) {
      console.error("Error getting learning timeline:", error);
      return [];
    }
  },
  
  /**
   * Calculate the current learning streak (consecutive days)
   */
  async calculateCurrentStreak(userId: number): Promise<number> {
    try {
      const activities = await storage.getLearningActivities(userId);
      
      if (activities.length === 0) {
        return 0;
      }
      
      // Sort activities by date (newest first)
      const sortedActivities = [...activities].sort(
        (a, b) => new Date(b.learningDate).getTime() - new Date(a.learningDate).getTime()
      );
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Check if the user learned today
      const mostRecentActivity = sortedActivities[0];
      const mostRecentDate = new Date(mostRecentActivity.learningDate);
      mostRecentDate.setHours(0, 0, 0, 0);
      
      // If the most recent activity wasn't today or yesterday, streak is broken
      const dayDifference = Math.floor(
        (today.getTime() - mostRecentDate.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      if (dayDifference > 1) {
        return 0;
      }
      
      // Calculate streak by checking consecutive days
      let streak = 1; // Start with 1 for the most recent day
      let currentDate = new Date(mostRecentDate);
      
      // Go back through previous days
      for (let i = 1; i < sortedActivities.length; i++) {
        currentDate.setDate(currentDate.getDate() - 1); // Go to previous day
        
        // Check if there was any activity on this day
        const foundActivity = sortedActivities.find(activity => {
          const activityDate = new Date(activity.learningDate);
          activityDate.setHours(0, 0, 0, 0);
          return activityDate.getTime() === currentDate.getTime();
        });
        
        if (foundActivity) {
          streak++;
        } else {
          break; // Streak is broken
        }
      }
      
      return streak;
    } catch (error) {
      console.error("Error calculating streak:", error);
      return 0;
    }
  },
  
  /**
   * Share a milestone with specific privacy settings
   */
  async shareMilestone(milestoneId: number, privacyLevel: string): Promise<LearningMilestone | null> {
    try {
      const milestone = await storage.getLearningMilestone(milestoneId);
      
      if (!milestone) {
        return null;
      }
      
      // Generate a share URL if not already present
      const shareUrl = milestone.shareUrl || generateShareUrl(milestoneId);
      
      return await storage.updateLearningMilestone(milestoneId, {
        isShared: true,
        privacyLevel,
        shareUrl
      });
    } catch (error) {
      console.error("Error sharing milestone:", error);
      return null;
    }
  },
  
  /**
   * Stop sharing a milestone
   */
  async unShareMilestone(milestoneId: number): Promise<LearningMilestone | null> {
    try {
      return await storage.updateLearningMilestone(milestoneId, {
        isShared: false
      });
    } catch (error) {
      console.error("Error unsharing milestone:", error);
      return null;
    }
  },
  
  /**
   * Share milestone to a specific social platform
   */
  async shareToSocialPlatform(milestoneId: number, platform: string): Promise<LearningMilestone | null> {
    try {
      const milestone = await storage.getLearningMilestone(milestoneId);
      
      if (!milestone) {
        return null;
      }
      
      // Parse the existing platforms or initialize an empty array
      const existingPlatforms = milestone.socialPlatforms ? 
        (Array.isArray(milestone.socialPlatforms) ? milestone.socialPlatforms : []) : 
        [];
      
      // Add the new platform if it's not already included
      if (!existingPlatforms.includes(platform)) {
        const updatedPlatforms = [...existingPlatforms, platform];
        
        return await storage.updateLearningMilestone(milestoneId, {
          socialPlatforms: updatedPlatforms
        });
      }
      
      return milestone;
    } catch (error) {
      console.error("Error sharing to social platform:", error);
      return null;
    }
  },
  
  /**
   * Get a milestone by its share URL
   */
  async getMilestoneByShareUrl(shareUrl: string): Promise<LearningMilestone | null> {
    try {
      const allMilestones = await storage.getAllMilestones();
      const milestone = allMilestones.find(m => m.shareUrl === shareUrl && m.isShared);
      
      if (!milestone) {
        return null;
      }
      
      // Only return publicly shared milestones
      if (milestone.privacyLevel === 'public' || milestone.privacyLevel === 'connections') {
        return milestone;
      }
      
      return null;
    } catch (error) {
      console.error("Error getting milestone by share URL:", error);
      return null;
    }
  },
  
  /**
   * Get all public milestones
   */
  async getPublicMilestones(limit: number = 20): Promise<LearningMilestone[]> {
    try {
      const allMilestones = await storage.getAllMilestones();
      
      // Filter for public milestones
      return allMilestones
        .filter(m => m.isShared && m.privacyLevel === 'public')
        .sort((a, b) => new Date(b.achievedAt).getTime() - new Date(a.achievedAt).getTime())
        .slice(0, limit);
    } catch (error) {
      console.error("Error getting public milestones:", error);
      return [];
    }
  }
};

export default milestoneService;