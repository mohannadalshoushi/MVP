import OpenAI from "openai";
import { QuizQuestion, InsertQuizQuestion } from "@shared/schema";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

export async function generateQuiz(content: string, activityId: number, numQuestions: number = 3): Promise<QuizQuestion[]> {
  try {
    // Get the learning activity to access category and user information
    const activity = await storage.getLearningActivity(activityId);
    if (!activity) {
      throw new Error(`Learning activity with ID ${activityId} not found`);
    }
    
    // Get additional context about the user and category
    const user = await storage.getUser(activity.userId);
    const category = await storage.getCategory(activity.categoryId);
    
    // Prepare context for more personalized questions
    const userContext = user ? {
      sector: user.sector || undefined,
      name: user.name || undefined
    } : undefined;
    
    const categoryContext = category ? category.name : undefined;
    
    // Generate quiz questions using OpenAI with enhanced context
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            `You are a quiz generator for professional learning content. Create ${numQuestions} multiple-choice questions based on the provided content. 
            
            Each question should have 4 answer options with exactly one correct option. The questions should test comprehension of key concepts and be challenging but fair.
            
            ${userContext ? `Personalize the questions for someone working in the ${userContext.sector} sector.` : ''}
            ${categoryContext ? `This content is categorized as "${categoryContext}".` : ''}
            
            Focus on practical application of concepts and professional skills development. Questions should range from knowledge recall to application and analysis.
            
            Respond with JSON in this format: 
            [
              {
                "question": "Question text?",
                "options": ["Option A", "Option B", "Option C", "Option D"],
                "correctOption": 0
              }
            ]
            Where correctOption is the zero-based index of the correct answer.`,
        },
        {
          role: "user",
          content: content,
        },
      ],
      response_format: { type: "json_object" },
    });

    const quizJson = JSON.parse(response.choices[0].message.content || "[]");
    
    if (!Array.isArray(quizJson) || quizJson.length === 0) {
      throw new Error("Failed to generate valid quiz questions");
    }

    // Store questions in database
    const savedQuestions: QuizQuestion[] = [];
    
    for (const q of quizJson) {
      if (!q.question || !Array.isArray(q.options) || q.options.length !== 4 || q.correctOption === undefined) {
        continue;
      }
      
      const questionData: InsertQuizQuestion = {
        activityId,
        question: q.question,
        options: q.options,
        correctOption: q.correctOption,
      };
      
      const savedQuestion = await storage.createQuizQuestion(questionData);
      savedQuestions.push(savedQuestion);
    }

    return savedQuestions;
  } catch (error) {
    console.error("Error generating quiz:", error);
    throw new Error("Failed to generate quiz");
  }
}

export async function evaluateQuiz(
  questionIds: number[], 
  userAnswers: number[]
): Promise<{ 
  score: number; 
  results: { 
    questionId: number; 
    correct: boolean; 
    correctOption: number;
  }[]
}> {
  try {
    if (questionIds.length !== userAnswers.length) {
      throw new Error("Number of questions and answers don't match");
    }

    const results = [];
    let correctCount = 0;

    for (let i = 0; i < questionIds.length; i++) {
      const questionId = questionIds[i];
      const userAnswer = userAnswers[i];
      
      // Get all questions from storage - this is a simple approach for our in-memory storage
      // In a real database implementation, we would add a getQuizQuestionById method
      const activities = await storage.getLearningActivities(1); // Get all activities
      
      // Get questions for all activities and flatten them
      const allQuestions = await Promise.all(
        activities.map(activity => storage.getQuizQuestions(activity.id))
      );
      
      // Flatten the array of arrays and find the question with matching ID
      const flatQuestions = allQuestions.flat();
      const matchedQuestion = flatQuestions.find(q => q.id === questionId);
      
      if (!matchedQuestion) {
        throw new Error(`Question with ID ${questionId} not found`);
      }
      
      // Update the question with user's answer
      await storage.updateQuizQuestion(questionId, { userAnswer });
      
      const isCorrect = matchedQuestion.correctOption === userAnswer;
      if (isCorrect) correctCount++;
      
      results.push({
        questionId,
        correct: isCorrect,
        correctOption: matchedQuestion.correctOption
      });
    }

    const score = Math.round((correctCount / questionIds.length) * 100);
    
    return {
      score,
      results
    };
  } catch (error) {
    console.error("Error evaluating quiz:", error);
    throw new Error("Failed to evaluate quiz");
  }
}

export default {
  generateQuiz,
  evaluateQuiz
};
