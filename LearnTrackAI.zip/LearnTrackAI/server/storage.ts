import {
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  learningActivities, type LearningActivity, type InsertLearningActivity,
  quizQuestions, type QuizQuestion, type InsertQuizQuestion,
  learningSummaries, type LearningSummary, type InsertLearningSummary,
  toolUsages, type ToolUsage, type InsertToolUsage,
  learningMilestones, type LearningMilestone, type InsertLearningMilestone,
  certifications, type Certification, type InsertCertification,
  languageSkills, type LanguageSkill, type InsertLanguageSkill,
  learningGoals, type LearningGoal, type InsertLearningGoal,
  milestoneCelebrations, type MilestoneCelebration, type InsertMilestoneCelebration,
  milestoneComments, type MilestoneComment, type InsertMilestoneComment
} from "@shared/schema";
import { db } from "./db";
import { eq, like } from "drizzle-orm";

import session from "express-session";
import type { Store } from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

export interface IStorage {
  sessionStore: Store;
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>; // For community members list

  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Learning activity methods
  getLearningActivities(userId: number): Promise<LearningActivity[]>;
  getLearningActivity(id: number): Promise<LearningActivity | undefined>;
  createLearningActivity(activity: InsertLearningActivity): Promise<LearningActivity>;
  updateLearningActivity(id: number, data: Partial<InsertLearningActivity>): Promise<LearningActivity | undefined>;
  
  // Quiz question methods
  getQuizQuestions(activityId: number): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  updateQuizQuestion(id: number, data: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined>;
  
  // Learning summary methods
  getLearningSummaries(userId: number): Promise<LearningSummary[]>;
  getLearningSummary(id: number): Promise<LearningSummary | undefined>;
  createLearningSummary(summary: InsertLearningSummary): Promise<LearningSummary>;
  
  // Tool usage methods
  getToolUsages(userId: number): Promise<ToolUsage[]>;
  getToolUsage(id: number): Promise<ToolUsage | undefined>;
  getToolUsageByName(userId: number, toolName: string): Promise<ToolUsage | undefined>;
  createToolUsage(toolUsage: InsertToolUsage): Promise<ToolUsage>;
  updateToolUsage(id: number, data: Partial<InsertToolUsage>): Promise<ToolUsage | undefined>;
  
  // Community methods
  getLearningGoals(): Promise<LearningGoal[]>;
  getLearningGoal(id: number): Promise<LearningGoal | undefined>;
  createLearningGoal(goal: any): Promise<LearningGoal>;
  updateLearningGoal(id: number, data: Partial<any>): Promise<LearningGoal | undefined>;
  addParticipantToGoal(goalId: number, userId: number): Promise<LearningGoal | undefined>;
  removeParticipantFromGoal(goalId: number, userId: number): Promise<LearningGoal | undefined>;
  
  // Milestone celebrations/comments
  celebrateMilestone(milestoneId: number, userId: number): Promise<MilestoneCelebration>;
  getMilestoneCelebrations(milestoneId: number): Promise<MilestoneCelebration[]>;
  addMilestoneComment(milestoneId: number, userId: number, content: string): Promise<MilestoneComment>;
  getMilestoneComments(milestoneId: number): Promise<MilestoneComment[]>;
  
  // Learning milestone methods
  getLearningMilestones(userId: number): Promise<LearningMilestone[]>;
  getLearningMilestone(id: number): Promise<LearningMilestone | undefined>;
  getAllMilestones(): Promise<LearningMilestone[]>;
  createLearningMilestone(milestone: InsertLearningMilestone): Promise<LearningMilestone>;
  updateLearningMilestone(id: number, data: Partial<InsertLearningMilestone>): Promise<LearningMilestone | undefined>;
  
  // Certification methods
  getCertifications(userId: number): Promise<Certification[]>;
  getCertification(id: number): Promise<Certification | undefined>;
  createCertification(certification: InsertCertification): Promise<Certification>;
  updateCertification(id: number, data: Partial<InsertCertification>): Promise<Certification | undefined>;
  
  // Language skills methods
  getLanguageSkills(userId: number): Promise<LanguageSkill[]>;
  getLanguageSkill(id: number): Promise<LanguageSkill | undefined>;
  getLanguageSkillByName(userId: number, language: string): Promise<LanguageSkill | undefined>;
  createLanguageSkill(languageSkill: InsertLanguageSkill): Promise<LanguageSkill>;
  updateLanguageSkill(id: number, data: Partial<InsertLanguageSkill>): Promise<LanguageSkill | undefined>;
}

export class MemStorage implements IStorage {
  sessionStore: Store;
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private learningActivities: Map<number, LearningActivity>;
  private quizQuestions: Map<number, QuizQuestion>;
  private learningSummaries: Map<number, LearningSummary>;
  private toolUsages: Map<number, ToolUsage>;
  private learningMilestones: Map<number, LearningMilestone>;
  private certifications: Map<number, Certification>;
  private languageSkills: Map<number, LanguageSkill>;
  private learningGoals: Map<number, LearningGoal>;
  private milestoneCelebrations: Map<number, MilestoneCelebration>;
  private milestoneComments: Map<number, MilestoneComment>;
  
  private userIdCounter: number;
  private categoryIdCounter: number;
  private activityIdCounter: number;
  private questionIdCounter: number;
  private summaryIdCounter: number;
  private toolUsageIdCounter: number;
  private milestoneIdCounter: number;
  private certificationIdCounter: number;
  private languageSkillIdCounter: number;
  private learningGoalIdCounter: number;
  private celebrationIdCounter: number;
  private commentIdCounter: number;

  constructor() {
    const MemoryStore = require("memorystore")(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    this.users = new Map();
    this.categories = new Map();
    this.learningActivities = new Map();
    this.quizQuestions = new Map();
    this.learningSummaries = new Map();
    this.toolUsages = new Map();
    this.learningMilestones = new Map();
    this.certifications = new Map();
    this.languageSkills = new Map();
    this.learningGoals = new Map();
    this.milestoneCelebrations = new Map();
    this.milestoneComments = new Map();
    
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.activityIdCounter = 1;
    this.questionIdCounter = 1;
    this.summaryIdCounter = 1;
    this.toolUsageIdCounter = 1;
    this.milestoneIdCounter = 1;
    this.certificationIdCounter = 1;
    this.languageSkillIdCounter = 1;
    this.learningGoalIdCounter = 1;
    this.celebrationIdCounter = 1;
    this.commentIdCounter = 1;
    
    // Initialize with default categories
    this.initializeDefaultCategories();
  }

  private initializeDefaultCategories() {
    const defaultCategories = [
      { name: "Marketing", icon: "trending_up", color: "#3B82F6" },
      { name: "Web Development", icon: "code", color: "#8B5CF6" },
      { name: "Design", icon: "brush", color: "#10B981" },
      { name: "Sales", icon: "sell", color: "#EF4444" },
      { name: "Data Science", icon: "analytics", color: "#F59E0B" },
    ];

    defaultCategories.forEach(category => {
      this.createCategory({
        name: category.name,
        icon: category.icon,
        color: category.color,
      });
    });
  }

  private initializeDefaultToolUsages(userId: number) {
    const defaultTools = [
      { name: "JIRA", category: "Project Management", icon: "task_alt", color: "#0052CC", hours: 10 },
      { name: "Replit", category: "Development", icon: "code", color: "#F26207", hours: 25 },
      { name: "Figma", category: "Design", icon: "edit", color: "#F24E1E", hours: 8 },
      { name: "GitHub", category: "Development", icon: "merge_type", color: "#24292E", hours: 15 },
      { name: "Slack", category: "Communication", icon: "chat", color: "#4A154B", hours: 12 },
    ];

    defaultTools.forEach(tool => {
      this.createToolUsage({
        userId,
        toolName: tool.name,
        toolCategory: tool.category,
        hoursSpent: tool.hours * 3600, // convert hours to seconds
        icon: tool.icon,
        color: tool.color,
      });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      name: insertUser.name || null,
      email: insertUser.email || null,
      sector: insertUser.sector || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.name.toLowerCase() === name.toLowerCase(),
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  // Learning activity methods
  async getLearningActivities(userId: number): Promise<LearningActivity[]> {
    return Array.from(this.learningActivities.values()).filter(
      (activity) => activity.userId === userId,
    );
  }

  async getLearningActivity(id: number): Promise<LearningActivity | undefined> {
    return this.learningActivities.get(id);
  }

  async createLearningActivity(insertActivity: InsertLearningActivity): Promise<LearningActivity> {
    const id = this.activityIdCounter++;
    const now = new Date();
    const activity: LearningActivity = { 
      ...insertActivity, 
      id, 
      learningDate: now,
      quizScore: insertActivity.quizScore ?? null,
      summary: insertActivity.summary ?? null,
      language: insertActivity.language ?? null
    };
    this.learningActivities.set(id, activity);
    return activity;
  }

  async updateLearningActivity(id: number, data: Partial<InsertLearningActivity>): Promise<LearningActivity | undefined> {
    const activity = await this.getLearningActivity(id);
    if (!activity) return undefined;
    
    const updatedActivity = { ...activity, ...data };
    this.learningActivities.set(id, updatedActivity);
    return updatedActivity;
  }

  // Quiz question methods
  async getQuizQuestions(activityId: number): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values()).filter(
      (question) => question.activityId === activityId,
    );
  }

  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const id = this.questionIdCounter++;
    const question: QuizQuestion = { 
      ...insertQuestion, 
      id,
      userAnswer: insertQuestion.userAnswer ?? null
    };
    this.quizQuestions.set(id, question);
    return question;
  }

  async updateQuizQuestion(id: number, data: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined> {
    const question = this.quizQuestions.get(id);
    if (!question) return undefined;
    
    const updatedQuestion = { ...question, ...data };
    this.quizQuestions.set(id, updatedQuestion);
    return updatedQuestion;
  }

  // Learning summary methods
  async getLearningSummaries(userId: number): Promise<LearningSummary[]> {
    return Array.from(this.learningSummaries.values()).filter(
      (summary) => summary.userId === userId,
    );
  }

  async getLearningSummary(id: number): Promise<LearningSummary | undefined> {
    return this.learningSummaries.get(id);
  }

  async createLearningSummary(insertSummary: InsertLearningSummary): Promise<LearningSummary> {
    const id = this.summaryIdCounter++;
    const now = new Date();
    const summary: LearningSummary = { ...insertSummary, id, createdAt: now };
    this.learningSummaries.set(id, summary);
    return summary;
  }

  // Tool usage methods
  async getToolUsages(userId: number): Promise<ToolUsage[]> {
    return Array.from(this.toolUsages.values()).filter(
      (usage) => usage.userId === userId,
    );
  }

  async getToolUsage(id: number): Promise<ToolUsage | undefined> {
    return this.toolUsages.get(id);
  }

  async getToolUsageByName(userId: number, toolName: string): Promise<ToolUsage | undefined> {
    return Array.from(this.toolUsages.values()).find(
      (usage) => usage.userId === userId && usage.toolName.toLowerCase() === toolName.toLowerCase(),
    );
  }

  async createToolUsage(insertToolUsage: InsertToolUsage): Promise<ToolUsage> {
    const id = this.toolUsageIdCounter++;
    const now = new Date();
    const toolUsage: ToolUsage = { 
      ...insertToolUsage, 
      id, 
      lastUsedDate: now,
      toolCategory: insertToolUsage.toolCategory ?? null
    };
    this.toolUsages.set(id, toolUsage);
    return toolUsage;
  }

  async updateToolUsage(id: number, data: Partial<InsertToolUsage>): Promise<ToolUsage | undefined> {
    const toolUsage = await this.getToolUsage(id);
    if (!toolUsage) return undefined;
    
    const updatedToolUsage = { ...toolUsage, ...data };
    // Update the last used date when hours spent is updated
    if (data.hoursSpent !== undefined) {
      updatedToolUsage.lastUsedDate = new Date();
    }
    this.toolUsages.set(id, updatedToolUsage);
    return updatedToolUsage;
  }

  // Learning milestone methods
  async getLearningMilestones(userId: number): Promise<LearningMilestone[]> {
    return Array.from(this.learningMilestones.values()).filter(
      (milestone) => milestone.userId === userId,
    );
  }

  async getLearningMilestone(id: number): Promise<LearningMilestone | undefined> {
    return this.learningMilestones.get(id);
  }
  
  async getAllMilestones(): Promise<LearningMilestone[]> {
    return Array.from(this.learningMilestones.values());
  }

  async createLearningMilestone(insertMilestone: InsertLearningMilestone): Promise<LearningMilestone> {
    const id = this.milestoneIdCounter++;
    const now = new Date();
    const milestone: LearningMilestone = { 
      ...insertMilestone, 
      id, 
      achievedAt: now,
      celebratedAt: null,
      isHidden: insertMilestone.isHidden ?? false,
      isShared: insertMilestone.isShared ?? false,
      privacyLevel: insertMilestone.privacyLevel ?? 'private',
      shareUrl: insertMilestone.shareUrl ?? null,
      socialPlatforms: insertMilestone.socialPlatforms ?? []
    };
    this.learningMilestones.set(id, milestone);
    return milestone;
  }

  async updateLearningMilestone(id: number, data: Partial<InsertLearningMilestone>): Promise<LearningMilestone | undefined> {
    const milestone = await this.getLearningMilestone(id);
    if (!milestone) return undefined;
    
    const updatedMilestone = { ...milestone, ...data };
    this.learningMilestones.set(id, updatedMilestone);
    return updatedMilestone;
  }
  
  // Certification methods
  async getCertifications(userId: number): Promise<Certification[]> {
    return Array.from(this.certifications.values()).filter(
      (certification) => certification.userId === userId,
    );
  }

  async getCertification(id: number): Promise<Certification | undefined> {
    return this.certifications.get(id);
  }

  async createCertification(insertCertification: InsertCertification): Promise<Certification> {
    const id = this.certificationIdCounter++;
    const now = new Date();
    const certification: Certification = { 
      ...insertCertification, 
      id, 
      createdAt: now,
      credentialID: insertCertification.credentialID ?? null,
      credentialURL: insertCertification.credentialURL ?? null,
      description: insertCertification.description ?? null,
      expiryDate: insertCertification.expiryDate ?? null
    };
    this.certifications.set(id, certification);
    return certification;
  }

  async updateCertification(id: number, data: Partial<InsertCertification>): Promise<Certification | undefined> {
    const certification = await this.getCertification(id);
    if (!certification) return undefined;
    
    const updatedCertification = { ...certification, ...data };
    this.certifications.set(id, updatedCertification);
    return updatedCertification;
  }
  
  // Language skills methods
  async getLanguageSkills(userId: number): Promise<LanguageSkill[]> {
    return Array.from(this.languageSkills.values()).filter(
      (languageSkill) => languageSkill.userId === userId,
    );
  }

  async getLanguageSkill(id: number): Promise<LanguageSkill | undefined> {
    return this.languageSkills.get(id);
  }

  async getLanguageSkillByName(userId: number, language: string): Promise<LanguageSkill | undefined> {
    return Array.from(this.languageSkills.values()).find(
      (languageSkill) => 
        languageSkill.userId === userId && 
        languageSkill.language.toLowerCase() === language.toLowerCase(),
    );
  }

  async createLanguageSkill(insertLanguageSkill: InsertLanguageSkill): Promise<LanguageSkill> {
    const id = this.languageSkillIdCounter++;
    const now = new Date();
    const languageSkill: LanguageSkill = { 
      ...insertLanguageSkill, 
      id, 
      lastActivity: now,
      readingTimeSpent: insertLanguageSkill.readingTimeSpent ?? 0,
      listeningTimeSpent: insertLanguageSkill.listeningTimeSpent ?? 0,
      proficiencyLevel: insertLanguageSkill.proficiencyLevel ?? null
    };
    this.languageSkills.set(id, languageSkill);
    return languageSkill;
  }

  async updateLanguageSkill(id: number, data: Partial<InsertLanguageSkill>): Promise<LanguageSkill | undefined> {
    const languageSkill = await this.getLanguageSkill(id);
    if (!languageSkill) return undefined;
    
    const updatedLanguageSkill = { ...languageSkill, ...data, lastActivity: new Date() };
    this.languageSkills.set(id, updatedLanguageSkill);
    return updatedLanguageSkill;
  }

  // Community methods - Learning Goals
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getLearningGoals(): Promise<LearningGoal[]> {
    return Array.from(this.learningGoals.values());
  }
  
  async getLearningGoal(id: number): Promise<LearningGoal | undefined> {
    return this.learningGoals.get(id);
  }
  
  async createLearningGoal(insertGoal: InsertLearningGoal): Promise<LearningGoal> {
    const id = this.learningGoalIdCounter++;
    const now = new Date();
    const goal: LearningGoal = {
      ...insertGoal,
      id,
      createdAt: now,
      participants: insertGoal.participants || [],
      progress: insertGoal.progress || 0
    };
    this.learningGoals.set(id, goal);
    return goal;
  }
  
  async updateLearningGoal(id: number, data: Partial<InsertLearningGoal>): Promise<LearningGoal | undefined> {
    const goal = await this.getLearningGoal(id);
    if (!goal) return undefined;
    
    const updatedGoal = { ...goal, ...data };
    this.learningGoals.set(id, updatedGoal);
    return updatedGoal;
  }
  
  async addParticipantToGoal(goalId: number, userId: number): Promise<LearningGoal | undefined> {
    const goal = await this.getLearningGoal(goalId);
    if (!goal) return undefined;
    
    // Check if user is already a participant
    if (goal.participants.includes(userId)) {
      return goal;
    }
    
    const updatedParticipants = [...goal.participants, userId];
    const updatedGoal = { ...goal, participants: updatedParticipants };
    this.learningGoals.set(goalId, updatedGoal);
    return updatedGoal;
  }
  
  async removeParticipantFromGoal(goalId: number, userId: number): Promise<LearningGoal | undefined> {
    const goal = await this.getLearningGoal(goalId);
    if (!goal) return undefined;
    
    const updatedParticipants = goal.participants.filter(id => id !== userId);
    const updatedGoal = { ...goal, participants: updatedParticipants };
    this.learningGoals.set(goalId, updatedGoal);
    return updatedGoal;
  }
  
  // Milestone celebrations/comments
  async celebrateMilestone(milestoneId: number, userId: number): Promise<MilestoneCelebration> {
    const id = this.celebrationIdCounter++;
    const now = new Date();
    const celebration: MilestoneCelebration = {
      id,
      milestoneId,
      userId,
      celebrationType: 'like', // Default celebration type
      createdAt: now
    };
    this.milestoneCelebrations.set(id, celebration);
    return celebration;
  }
  
  async getMilestoneCelebrations(milestoneId: number): Promise<MilestoneCelebration[]> {
    return Array.from(this.milestoneCelebrations.values())
      .filter(celebration => celebration.milestoneId === milestoneId);
  }
  
  async addMilestoneComment(milestoneId: number, userId: number, content: string): Promise<MilestoneComment> {
    const id = this.commentIdCounter++;
    const now = new Date();
    const comment: MilestoneComment = {
      id,
      milestoneId,
      userId,
      content,
      createdAt: now
    };
    this.milestoneComments.set(id, comment);
    return comment;
  }
  
  async getMilestoneComments(milestoneId: number): Promise<MilestoneComment[]> {
    return Array.from(this.milestoneComments.values())
      .filter(comment => comment.milestoneId === milestoneId);
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: Store;

  constructor() {
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
  }
  // Community methods - for all users
  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }
  
  // Community methods - Learning Goals
  async getLearningGoals(): Promise<LearningGoal[]> {
    return db.select().from(learningGoals);
  }
  
  async getLearningGoal(id: number): Promise<LearningGoal | undefined> {
    const [goal] = await db.select().from(learningGoals).where(eq(learningGoals.id, id));
    return goal;
  }
  
  async createLearningGoal(insertGoal: InsertLearningGoal): Promise<LearningGoal> {
    const [goal] = await db
      .insert(learningGoals)
      .values(insertGoal)
      .returning();
    return goal;
  }
  
  async updateLearningGoal(id: number, data: Partial<InsertLearningGoal>): Promise<LearningGoal | undefined> {
    const [updatedGoal] = await db
      .update(learningGoals)
      .set(data)
      .where(eq(learningGoals.id, id))
      .returning();
    return updatedGoal;
  }
  
  async addParticipantToGoal(goalId: number, userId: number): Promise<LearningGoal | undefined> {
    // First, get the current goal to access its participants
    const [goal] = await db
      .select()
      .from(learningGoals)
      .where(eq(learningGoals.id, goalId));
    
    if (!goal) return undefined;
    
    // Check if user is already a participant
    const participants = goal.participants as number[] || [];
    if (participants.includes(userId)) {
      return goal;
    }
    
    // Add participant and update
    const updatedParticipants = [...participants, userId];
    const [updatedGoal] = await db
      .update(learningGoals)
      .set({ participants: updatedParticipants })
      .where(eq(learningGoals.id, goalId))
      .returning();
    
    return updatedGoal;
  }
  
  async removeParticipantFromGoal(goalId: number, userId: number): Promise<LearningGoal | undefined> {
    // First, get the current goal to access its participants
    const [goal] = await db
      .select()
      .from(learningGoals)
      .where(eq(learningGoals.id, goalId));
    
    if (!goal) return undefined;
    
    // Remove participant and update
    const participants = goal.participants as number[] || [];
    const updatedParticipants = participants.filter(id => id !== userId);
    
    const [updatedGoal] = await db
      .update(learningGoals)
      .set({ participants: updatedParticipants })
      .where(eq(learningGoals.id, goalId))
      .returning();
    
    return updatedGoal;
  }
  
  // Milestone celebrations/comments
  async celebrateMilestone(milestoneId: number, userId: number): Promise<MilestoneCelebration> {
    const [celebration] = await db
      .insert(milestoneCelebrations)
      .values({
        milestoneId,
        userId,
        celebrationType: 'like', // Default celebration type
      })
      .returning();
    
    return celebration;
  }
  
  async getMilestoneCelebrations(milestoneId: number): Promise<MilestoneCelebration[]> {
    return db
      .select()
      .from(milestoneCelebrations)
      .where(eq(milestoneCelebrations.milestoneId, milestoneId));
  }
  
  async addMilestoneComment(milestoneId: number, userId: number, content: string): Promise<MilestoneComment> {
    const [comment] = await db
      .insert(milestoneComments)
      .values({
        milestoneId,
        userId,
        content,
      })
      .returning();
    
    return comment;
  }
  
  async getMilestoneComments(milestoneId: number): Promise<MilestoneComment[]> {
    return db
      .select()
      .from(milestoneComments)
      .where(eq(milestoneComments.milestoneId, milestoneId));
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  // Certification methods
  async getCertifications(userId: number): Promise<Certification[]> {
    return db.select().from(certifications).where(eq(certifications.userId, userId));
  }

  async getCertification(id: number): Promise<Certification | undefined> {
    const [certification] = await db.select().from(certifications).where(eq(certifications.id, id));
    return certification;
  }

  async createCertification(insertCertification: InsertCertification): Promise<Certification> {
    const [certification] = await db
      .insert(certifications)
      .values(insertCertification)
      .returning();
    return certification;
  }

  async updateCertification(id: number, data: Partial<InsertCertification>): Promise<Certification | undefined> {
    const [updatedCertification] = await db
      .update(certifications)
      .set(data)
      .where(eq(certifications.id, id))
      .returning();
    return updatedCertification;
  }
  
  // Language skills methods
  async getLanguageSkills(userId: number): Promise<LanguageSkill[]> {
    return db.select().from(languageSkills).where(eq(languageSkills.userId, userId));
  }

  async getLanguageSkill(id: number): Promise<LanguageSkill | undefined> {
    const [languageSkill] = await db.select().from(languageSkills).where(eq(languageSkills.id, id));
    return languageSkill;
  }

  async getLanguageSkillByName(userId: number, language: string): Promise<LanguageSkill | undefined> {
    const [languageSkill] = await db.select().from(languageSkills).where(
      eq(languageSkills.userId, userId) && eq(languageSkills.language, language)
    );
    return languageSkill;
  }

  async createLanguageSkill(insertLanguageSkill: InsertLanguageSkill): Promise<LanguageSkill> {
    const [languageSkill] = await db
      .insert(languageSkills)
      .values(insertLanguageSkill)
      .returning();
    return languageSkill;
  }

  async updateLanguageSkill(id: number, data: Partial<InsertLanguageSkill>): Promise<LanguageSkill | undefined> {
    const [updatedLanguageSkill] = await db
      .update(languageSkills)
      .set(data)
      .where(eq(languageSkills.id, id))
      .returning();
    return updatedLanguageSkill;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(
      eq(categories.name, name)
    );
    return category;
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }

  // Learning activity methods
  async getLearningActivities(userId: number): Promise<LearningActivity[]> {
    return db.select().from(learningActivities).where(eq(learningActivities.userId, userId));
  }

  async getLearningActivity(id: number): Promise<LearningActivity | undefined> {
    const [activity] = await db.select().from(learningActivities).where(eq(learningActivities.id, id));
    return activity;
  }

  async createLearningActivity(insertActivity: InsertLearningActivity): Promise<LearningActivity> {
    const [activity] = await db
      .insert(learningActivities)
      .values(insertActivity)
      .returning();
    return activity;
  }

  async updateLearningActivity(id: number, data: Partial<InsertLearningActivity>): Promise<LearningActivity | undefined> {
    const [updatedActivity] = await db
      .update(learningActivities)
      .set(data)
      .where(eq(learningActivities.id, id))
      .returning();
    return updatedActivity;
  }

  // Quiz question methods
  async getQuizQuestions(activityId: number): Promise<QuizQuestion[]> {
    return db.select().from(quizQuestions).where(eq(quizQuestions.activityId, activityId));
  }

  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const [question] = await db
      .insert(quizQuestions)
      .values(insertQuestion)
      .returning();
    return question;
  }

  async updateQuizQuestion(id: number, data: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined> {
    const [updatedQuestion] = await db
      .update(quizQuestions)
      .set(data)
      .where(eq(quizQuestions.id, id))
      .returning();
    return updatedQuestion;
  }

  // Learning summary methods
  async getLearningSummaries(userId: number): Promise<LearningSummary[]> {
    return db.select().from(learningSummaries).where(eq(learningSummaries.userId, userId));
  }

  async getLearningSummary(id: number): Promise<LearningSummary | undefined> {
    const [summary] = await db.select().from(learningSummaries).where(eq(learningSummaries.id, id));
    return summary;
  }

  async createLearningSummary(insertSummary: InsertLearningSummary): Promise<LearningSummary> {
    const [summary] = await db
      .insert(learningSummaries)
      .values(insertSummary)
      .returning();
    return summary;
  }

  // Tool usage methods
  async getToolUsages(userId: number): Promise<ToolUsage[]> {
    return db.select().from(toolUsages).where(eq(toolUsages.userId, userId));
  }

  async getToolUsage(id: number): Promise<ToolUsage | undefined> {
    const [usage] = await db.select().from(toolUsages).where(eq(toolUsages.id, id));
    return usage;
  }

  async getToolUsageByName(userId: number, toolName: string): Promise<ToolUsage | undefined> {
    const usages = await db.select().from(toolUsages);
    
    // Filter using JavaScript to handle case-insensitive comparison
    const result = usages.find(
      (usage: ToolUsage) => usage.userId === userId && 
                           usage.toolName.toLowerCase() === toolName.toLowerCase()
    );
    
    return result;
  }

  async createToolUsage(insertToolUsage: InsertToolUsage): Promise<ToolUsage> {
    const [usage] = await db
      .insert(toolUsages)
      .values(insertToolUsage)
      .returning();
    return usage;
  }

  async updateToolUsage(id: number, data: Partial<InsertToolUsage>): Promise<ToolUsage | undefined> {
    // First, get the current tool usage
    const [currentUsage] = await db
      .select()
      .from(toolUsages)
      .where(eq(toolUsages.id, id));

    if (!currentUsage) return undefined;

    // When hours spent is updated, set lastUsedDate now
    let lastUsedDate = currentUsage.lastUsedDate;
    if (data.hoursSpent !== undefined) {
      lastUsedDate = new Date();
    }

    // Update with the correct set of fields
    const [updatedUsage] = await db
      .update(toolUsages)
      .set({
        ...currentUsage,
        ...data,
        lastUsedDate
      })
      .where(eq(toolUsages.id, id))
      .returning();
    
    return updatedUsage;
  }

  // Learning milestone methods
  async getLearningMilestones(userId: number): Promise<LearningMilestone[]> {
    return db.select().from(learningMilestones).where(eq(learningMilestones.userId, userId));
  }

  async getLearningMilestone(id: number): Promise<LearningMilestone | undefined> {
    const [milestone] = await db.select().from(learningMilestones).where(eq(learningMilestones.id, id));
    return milestone;
  }
  
  async getAllMilestones(): Promise<LearningMilestone[]> {
    return db.select().from(learningMilestones);
  }

  async createLearningMilestone(insertMilestone: InsertLearningMilestone): Promise<LearningMilestone> {
    const [milestone] = await db
      .insert(learningMilestones)
      .values(insertMilestone)
      .returning();
    return milestone;
  }

  async updateLearningMilestone(id: number, data: Partial<InsertLearningMilestone>): Promise<LearningMilestone | undefined> {
    const [updatedMilestone] = await db
      .update(learningMilestones)
      .set(data)
      .where(eq(learningMilestones.id, id))
      .returning();
    return updatedMilestone;
  }
}

// Change from MemStorage to DatabaseStorage
export const storage = new DatabaseStorage();
