import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import path from "path";
import fs from "fs";
import { 
  extractContentSchema, 
  generateQuizSchema, 
  analyzeContentSchema,
  insertUserSchema,
  insertLearningActivitySchema,
  insertToolUsageSchema,
  insertLearningMilestoneSchema,
  insertCertificationSchema,
  insertLanguageSkillSchema
} from "@shared/schema";
import contentExtractor from "./content-extractor";
import openai from "./openai";
import quizGenerator from "./quiz-generator";
import milestoneService from "./milestone-service";
import { setupAuth } from "./auth";

import { generateRecommendations } from './recommendation-engine';

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);

  // Categories routes
  app.get("/api/categories", async (_req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.status(200).json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Learning activities routes
  app.get("/api/learning-activities/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const activities = await storage.getLearningActivities(userId);
      res.status(200).json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch learning activities" });
    }
  });

  app.post("/api/learning-activities", async (req: Request, res: Response) => {
    try {
      const activityData = insertLearningActivitySchema.parse(req.body);
      const activity = await storage.createLearningActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create learning activity" });
    }
  });

  // Content extraction route
  app.post("/api/extract-content", async (req: Request, res: Response) => {
    try {
      const { url, contentType } = extractContentSchema.parse(req.body);
      
      const urlInfo = contentExtractor.preprocessUrl(url);
      let extractedContent = "";
      
      if (urlInfo.contentType === "video") {
        extractedContent = await contentExtractor.extractYouTubeTranscript(url);
      } else {
        // For articles, we would fetch the HTML and extract content
        // In a real implementation, this would call a fetch function
        extractedContent = "This is where extracted article content would appear. In a real implementation, we would fetch the article content from the provided URL.";
      }
      
      res.status(200).json({ 
        content: extractedContent,
        contentType: urlInfo.contentType,
        source: urlInfo.source
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to extract content" });
    }
  });

  // Content analysis route
  app.post("/api/analyze-content", async (req: Request, res: Response) => {
    try {
      const { content, category } = analyzeContentSchema.parse(req.body);
      
      // If category is provided, use it; otherwise, categorize the content
      let contentCategory = category;
      let categoryConfidence = 1.0;
      
      if (!contentCategory) {
        const categorization = await openai.categorizeContent(content);
        contentCategory = categorization.category;
        categoryConfidence = categorization.confidence;
      }
      
      // Generate a summary of the content
      const summary = await openai.summarizeContent(content, contentCategory);
      
      res.status(200).json({
        category: contentCategory,
        confidence: categoryConfidence,
        summary
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to analyze content" });
    }
  });

  // Quiz generation route
  app.post("/api/generate-quiz", async (req: Request, res: Response) => {
    try {
      const { content, numQuestions } = generateQuizSchema.parse(req.body);
      const { activityId } = req.body;
      
      if (!activityId) {
        return res.status(400).json({ message: "Activity ID is required" });
      }
      
      const quizQuestions = await quizGenerator.generateQuiz(content, activityId, numQuestions);
      
      res.status(200).json({
        activityId,
        questions: quizQuestions.map(q => ({
          id: q.id,
          question: q.question,
          options: q.options
        }))
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to generate quiz" });
    }
  });

  // Get quiz questions for an activity
  app.get("/api/quiz-questions/:activityId", async (req: Request, res: Response) => {
    try {
      const activityId = parseInt(req.params.activityId);
      
      if (isNaN(activityId)) {
        return res.status(400).json({ message: "Invalid activity ID" });
      }
      
      // Get the activity to verify it exists
      const activity = await storage.getLearningActivity(activityId);
      
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      // Get quiz questions for this activity
      let questions = await storage.getQuizQuestions(activityId);
      
      // If no questions exist, generate them
      if (!questions || questions.length === 0) {
        // For demo purposes, we'll generate questions based on activity title
        const content = `Learning activity about ${activity.title}. This is content related to ${activity.title} that would be summarized from the actual web page. For this demo, we're generating placeholder quiz questions.`;
        questions = await quizGenerator.generateQuiz(content, activityId, 5);
      }
      
      // Return questions without revealing the correct answers
      const safeQuestions = questions.map(q => ({
        id: q.id,
        question: q.question,
        options: q.options,
        correctOption: q.correctOption // Include for demo purposes, but would be removed in production
      }));
      
      res.status(200).json(safeQuestions);
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      res.status(500).json({ message: "Failed to fetch quiz questions" });
    }
  });

  // Quiz evaluation route
  app.post("/api/evaluate-quiz", async (req: Request, res: Response) => {
    try {
      const { questionIds, userAnswers, activityId } = req.body;
      
      if (!Array.isArray(questionIds) || !Array.isArray(userAnswers) || !activityId) {
        return res.status(400).json({ message: "Question IDs, user answers, and activity ID are required" });
      }
      
      const evaluation = await quizGenerator.evaluateQuiz(questionIds, userAnswers);
      
      // Update the learning activity with the quiz score
      await storage.updateLearningActivity(activityId, { quizScore: evaluation.score });
      
      res.status(200).json(evaluation);
    } catch (error) {
      res.status(500).json({ message: "Failed to evaluate quiz" });
    }
  });

  // CV generation route
  app.post("/api/generate-cv-summary", async (req: Request, res: Response) => {
    try {
      const { userId, categoryId } = req.body;
      
      if (!userId || !categoryId) {
        return res.status(400).json({ message: "User ID and category ID are required" });
      }
      
      // Get activities for this user and category
      const allActivities = await storage.getLearningActivities(userId);
      const categoryActivities = allActivities.filter(a => a.categoryId === categoryId);
      
      if (categoryActivities.length === 0) {
        return res.status(404).json({ message: "No learning activities found for this category" });
      }
      
      // Get category name
      const category = await storage.getCategory(categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      // Generate CV summary
      const summary = await openai.generateCVSummary(categoryActivities, category.name);
      
      // Save summary to database
      const savedSummary = await storage.createLearningSummary({
        userId,
        categoryId,
        content: summary
      });
      
      res.status(200).json(savedSummary);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate CV summary" });
    }
  });

  // Learning summaries route
  app.get("/api/learning-summaries/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const summaries = await storage.getLearningSummaries(userId);
      res.status(200).json(summaries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch learning summaries" });
    }
  });

  // Tool usage routes
  app.get("/api/tool-usages/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const toolUsages = await storage.getToolUsages(userId);
      res.status(200).json(toolUsages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tool usages" });
    }
  });

  app.post("/api/tool-usages", async (req: Request, res: Response) => {
    try {
      const toolUsageData = insertToolUsageSchema.parse(req.body);

      // Check if the tool usage already exists for this user
      const existingToolUsage = await storage.getToolUsageByName(toolUsageData.userId, toolUsageData.toolName);
      
      if (existingToolUsage) {
        // Update the existing tool usage
        const updatedToolUsage = await storage.updateToolUsage(existingToolUsage.id, {
          hoursSpent: existingToolUsage.hoursSpent + toolUsageData.hoursSpent
        });
        return res.status(200).json(updatedToolUsage);
      } else {
        // Create a new tool usage
        const newToolUsage = await storage.createToolUsage(toolUsageData);
        return res.status(201).json(newToolUsage);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid tool usage data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create/update tool usage" });
    }
  });
  
  // Recommendations route
  app.get("/api/recommendations/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user's learning activities
      const activities = await storage.getLearningActivities(userId);
      
      // Generate recommendations based on user's learning history and profile
      const recommendations = await generateRecommendations(user);
      
      res.status(200).json(recommendations);
    } catch (error) {
      console.error("Error generating recommendations:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  // Learning milestones routes
  app.get("/api/learning-milestones/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const milestones = await storage.getLearningMilestones(userId);
      res.status(200).json(milestones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch learning milestones" });
    }
  });

  app.post("/api/learning-milestones", async (req: Request, res: Response) => {
    try {
      const milestoneData = insertLearningMilestoneSchema.parse(req.body);
      const milestone = await storage.createLearningMilestone(milestoneData);
      res.status(201).json(milestone);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid milestone data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create learning milestone" });
    }
  });

  app.post("/api/learning-milestones/check/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Check for and create new milestones
      const newMilestones = await milestoneService.checkMilestones(userId);
      
      res.status(200).json({ 
        newMilestones,
        count: newMilestones.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to check for new milestones" });
    }
  });

  app.post("/api/learning-milestones/celebrate/:id", async (req: Request, res: Response) => {
    try {
      const milestoneId = parseInt(req.params.id);
      if (isNaN(milestoneId)) {
        return res.status(400).json({ message: "Invalid milestone ID" });
      }
      
      const celebratedMilestone = await milestoneService.celebrateMilestone(milestoneId);
      
      if (!celebratedMilestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      res.status(200).json(celebratedMilestone);
    } catch (error) {
      res.status(500).json({ message: "Failed to celebrate milestone" });
    }
  });

  app.get("/api/learning-milestones/uncelebrated/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const uncelebratedMilestones = await milestoneService.getUncelebratedMilestones(userId);
      
      res.status(200).json(uncelebratedMilestones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch uncelebrated milestones" });
    }
  });
  
  // Share a milestone
  app.post("/api/learning-milestones/share/:id", async (req: Request, res: Response) => {
    try {
      const milestoneId = parseInt(req.params.id);
      if (isNaN(milestoneId)) {
        return res.status(400).json({ message: "Invalid milestone ID" });
      }
      
      const { privacyLevel } = req.body;
      if (!privacyLevel || !['private', 'connections', 'public'].includes(privacyLevel)) {
        return res.status(400).json({ message: "Valid privacy level is required (private, connections, or public)" });
      }
      
      const sharedMilestone = await milestoneService.shareMilestone(milestoneId, privacyLevel);
      
      if (!sharedMilestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      res.status(200).json(sharedMilestone);
    } catch (error) {
      console.error("Error sharing milestone:", error);
      res.status(500).json({ message: "Failed to share milestone" });
    }
  });
  
  // Unshare a milestone
  app.post("/api/learning-milestones/unshare/:id", async (req: Request, res: Response) => {
    try {
      const milestoneId = parseInt(req.params.id);
      if (isNaN(milestoneId)) {
        return res.status(400).json({ message: "Invalid milestone ID" });
      }
      
      const unsharedMilestone = await milestoneService.unShareMilestone(milestoneId);
      
      if (!unsharedMilestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      res.status(200).json(unsharedMilestone);
    } catch (error) {
      console.error("Error unsharing milestone:", error);
      res.status(500).json({ message: "Failed to unshare milestone" });
    }
  });
  
  // Share milestone to a social platform
  app.post("/api/learning-milestones/share-to-platform/:id", async (req: Request, res: Response) => {
    try {
      const milestoneId = parseInt(req.params.id);
      if (isNaN(milestoneId)) {
        return res.status(400).json({ message: "Invalid milestone ID" });
      }
      
      const { platform } = req.body;
      if (!platform) {
        return res.status(400).json({ message: "Platform is required" });
      }
      
      const sharedMilestone = await milestoneService.shareToSocialPlatform(milestoneId, platform);
      
      if (!sharedMilestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      res.status(200).json(sharedMilestone);
    } catch (error) {
      console.error("Error sharing milestone to platform:", error);
      res.status(500).json({ message: "Failed to share milestone to platform" });
    }
  });
  
  // Get milestone by share URL
  app.get("/api/share/:shareUrl", async (req: Request, res: Response) => {
    try {
      const { shareUrl } = req.params;
      
      if (!shareUrl) {
        return res.status(400).json({ message: "Share URL is required" });
      }
      
      const milestone = await milestoneService.getMilestoneByShareUrl(shareUrl);
      
      if (!milestone) {
        return res.status(404).json({ message: "Shared milestone not found or not publicly available" });
      }
      
      res.status(200).json(milestone);
    } catch (error) {
      console.error("Error getting shared milestone:", error);
      res.status(500).json({ message: "Failed to get shared milestone" });
    }
  });
  
  // Get public milestones
  app.get("/api/public-milestones", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      
      const publicMilestones = await milestoneService.getPublicMilestones(limit);
      res.status(200).json(publicMilestones);
    } catch (error) {
      console.error("Error getting public milestones:", error);
      res.status(500).json({ message: "Failed to get public milestones" });
    }
  });

  // Community API endpoints
  app.get("/api/community/milestones", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const publicMilestones = await milestoneService.getPublicMilestones(limit);
      res.status(200).json(publicMilestones);
    } catch (error) {
      console.error("Error fetching community milestones:", error);
      res.status(500).json({ message: "Failed to fetch community milestones" });
    }
  });
  
  app.get("/api/community/users", async (req: Request, res: Response) => {
    try {
      // Fetch all users for community display
      const users = await storage.getAllUsers();
      res.status(200).json(users);
    } catch (error) {
      console.error("Error fetching community users:", error);
      res.status(500).json({ message: "Failed to fetch community users" });
    }
  });
  
  app.get("/api/community/goals", async (req: Request, res: Response) => {
    try {
      // Get community learning goals
      const goals = await storage.getLearningGoals();
      res.status(200).json(goals);
    } catch (error) {
      console.error("Error fetching learning goals:", error);
      res.status(500).json({ message: "Failed to fetch learning goals" });
    }
  });
  
  app.post("/api/community/goals", async (req: Request, res: Response) => {
    try {
      const goalData = {
        title: req.body.title,
        description: req.body.description,
        creatorId: req.body.userId,
        category: req.body.category,
        targetDate: new Date(req.body.targetDate),
        createdAt: new Date()
      };
      
      const goal = await storage.createLearningGoal(goalData);
      res.status(201).json(goal);
    } catch (error) {
      console.error("Error creating learning goal:", error);
      res.status(500).json({ message: "Failed to create learning goal" });
    }
  });
  
  app.post("/api/community/goals/:id/join", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const goal = await storage.addParticipantToGoal(parseInt(id), userId);
      res.status(200).json(goal);
    } catch (error) {
      console.error("Error joining learning goal:", error);
      res.status(500).json({ message: "Failed to join learning goal" });
    }
  });
  
  app.post("/api/community/milestones/:id/celebrate", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const celebration = await storage.celebrateMilestone(parseInt(id), userId);
      res.status(201).json(celebration);
    } catch (error) {
      console.error("Error celebrating milestone:", error);
      res.status(500).json({ message: "Failed to celebrate milestone" });
    }
  });
  
  app.post("/api/community/milestones/:id/comments", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { userId, content } = req.body;
      
      if (!userId || !content) {
        return res.status(400).json({ message: "User ID and comment content are required" });
      }
      
      const comment = await storage.addMilestoneComment(parseInt(id), userId, content);
      res.status(201).json(comment);
    } catch (error) {
      console.error("Error adding milestone comment:", error);
      res.status(500).json({ message: "Failed to add milestone comment" });
    }
  });
  
  app.get("/api/community/milestones/:id/comments", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const comments = await storage.getMilestoneComments(parseInt(id));
      res.status(200).json(comments);
    } catch (error) {
      console.error("Error fetching milestone comments:", error);
      res.status(500).json({ message: "Failed to fetch milestone comments" });
    }
  });

  app.get("/api/learning-timeline/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      
      const timeline = await milestoneService.getLearningTimeline(userId, limit);
      
      res.status(200).json(timeline);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch learning timeline" });
    }
  });

  app.get("/api/learning-streak/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const streak = await milestoneService.calculateCurrentStreak(userId);
      
      res.status(200).json({ streak });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate streak" });
    }
  });
  
  // Gamification Endpoints
  app.get("/api/user/gamification", (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        // For demo purposes, return dummy data for non-authenticated users
        return res.json({
          points: 150,
          streak: 3,
          level: 2,
          badges: [
            {
              id: 'consistent_learner',
              name: 'Consistent Learner',
              icon: 'local_fire_department',
              description: '3-day learning streak'
            },
            {
              id: 'knowledge_seeker',
              name: 'Knowledge Seeker',
              icon: 'search',
              description: 'Earned 500 XP'
            }
          ],
          xpToNextLevel: 100
        });
      }
      
      // Use the user ID from the session
      const userId = req.user!.id;
      
      // This would normally fetch from a database
      // For now, we'll use sample data based on userId
      const data = {
        points: 150 + (userId * 10),
        streak: Math.min(7, 2 + (userId % 5)),
        level: Math.max(1, Math.floor(userId / 2)),
        badges: [
          {
            id: 'consistent_learner',
            name: 'Consistent Learner',
            icon: 'local_fire_department',
            description: '3-day learning streak'
          }
        ],
        xpToNextLevel: 100
      };
      
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve gamification data" });
    }
  });
  
  app.post("/api/user/gamification/points", (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      // Normally we would update the user's points in the database
      const { points, level } = req.body;
      
      // Success response
      res.json({ success: true, points, level });
    } catch (error) {
      res.status(500).json({ error: "Failed to update points" });
    }
  });
  
  app.post("/api/user/gamification/badges", (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      // Normally we would update the user's badges in the database
      const { badges } = req.body;
      
      // Success response
      res.json({ success: true, badges });
    } catch (error) {
      res.status(500).json({ error: "Failed to update badges" });
    }
  });

  // Certifications routes
  app.get("/api/certifications/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const certifications = await storage.getCertifications(userId);
      res.status(200).json(certifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch certifications" });
    }
  });

  app.post("/api/certifications", async (req: Request, res: Response) => {
    try {
      const certificationData = insertCertificationSchema.parse(req.body);
      const certification = await storage.createCertification(certificationData);
      res.status(201).json(certification);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid certification data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create certification" });
    }
  });

  app.put("/api/certifications/:id", async (req: Request, res: Response) => {
    try {
      const certificationId = parseInt(req.params.id);
      if (isNaN(certificationId)) {
        return res.status(400).json({ message: "Invalid certification ID" });
      }
      
      const certificationData = req.body;
      const updatedCertification = await storage.updateCertification(certificationId, certificationData);
      
      if (!updatedCertification) {
        return res.status(404).json({ message: "Certification not found" });
      }
      
      res.status(200).json(updatedCertification);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid certification data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update certification" });
    }
  });

  // Language skills routes
  app.get("/api/language-skills/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const languageSkills = await storage.getLanguageSkills(userId);
      res.status(200).json(languageSkills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch language skills" });
    }
  });

  app.post("/api/language-skills", async (req: Request, res: Response) => {
    try {
      const languageSkillData = insertLanguageSkillSchema.parse(req.body);
      
      // Check if the language skill already exists for this user
      const existingLanguageSkill = await storage.getLanguageSkillByName(
        languageSkillData.userId, 
        languageSkillData.language
      );
      
      if (existingLanguageSkill) {
        // Update the existing language skill
        const updatedLanguageSkill = await storage.updateLanguageSkill(existingLanguageSkill.id, {
          readingTimeSpent: (existingLanguageSkill.readingTimeSpent || 0) + (languageSkillData.readingTimeSpent || 0),
          listeningTimeSpent: (existingLanguageSkill.listeningTimeSpent || 0) + (languageSkillData.listeningTimeSpent || 0),
        });
        return res.status(200).json(updatedLanguageSkill);
      } else {
        // Create a new language skill
        const newLanguageSkill = await storage.createLanguageSkill(languageSkillData);
        return res.status(201).json(newLanguageSkill);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid language skill data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create/update language skill" });
    }
  });

  // Track language usage when creating learning activity
  app.post("/api/track-language", async (req: Request, res: Response) => {
    try {
      const { userId, language, contentType, timeSpent } = req.body;
      
      if (!userId || !language || !contentType || !timeSpent) {
        return res.status(400).json({ message: "User ID, language, content type, and time spent are required" });
      }
      
      // Check if the language skill already exists for this user
      const existingLanguageSkill = await storage.getLanguageSkillByName(userId, language);
      
      if (existingLanguageSkill) {
        // Update the existing language skill based on content type
        let updateData: { readingTimeSpent?: number; listeningTimeSpent?: number } = {};
        
        if (contentType === 'article') {
          updateData = {
            readingTimeSpent: (existingLanguageSkill.readingTimeSpent || 0) + timeSpent
          };
        } else if (contentType === 'video') {
          updateData = {
            listeningTimeSpent: (existingLanguageSkill.listeningTimeSpent || 0) + timeSpent
          };
        }
        
        const updatedLanguageSkill = await storage.updateLanguageSkill(existingLanguageSkill.id, updateData);
        return res.status(200).json(updatedLanguageSkill);
      } else {
        // Create a new language skill
        const languageSkillData = {
          userId,
          language,
          readingTimeSpent: contentType === 'article' ? timeSpent : 0,
          listeningTimeSpent: contentType === 'video' ? timeSpent : 0,
          proficiencyLevel: 'Beginner'
        };
        
        const newLanguageSkill = await storage.createLanguageSkill(languageSkillData);
        return res.status(201).json(newLanguageSkill);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to track language usage" });
    }
  });

  // Landing page route
  app.get("/landing.html", (req: Request, res: Response) => {
    try {
      const landingPath = path.join(process.cwd(), "client", "public", "landing.html");
      
      if (fs.existsSync(landingPath)) {
        return res.sendFile(landingPath);
      } else {
        return res.status(404).send("Landing page not found");
      }
    } catch (error) {
      console.error('Error serving landing page:', error);
      res.status(500).send("Error loading landing page");
    }
  });
  
  // Root route - redirect to landing page for better navigation
  app.get("/", (req: Request, res: Response) => {
    // If user is authenticated, serve the React app
    if (req.isAuthenticated && req.isAuthenticated()) {
      return res.sendFile(path.join(process.cwd(), "client", "index.html"));
    }
    // Otherwise redirect to landing page
    return res.redirect("/landing.html");
  });

  // Extension preview routes with static file serving for assets
  app.use('/extension/assets', (req, res, next) => {
    const staticPath = path.join(process.cwd(), 'client', 'public', 'extension');
    // For debugging
    console.log('Serving static assets from:', staticPath);
    console.log('Requested asset:', req.url);
    // Use Express's static middleware
    express().use(express.static(staticPath))(req, res, next);
  });

  app.get("/extension/preview/:page", (req: Request, res: Response) => {
    try {
      const page = req.params.page;
      const allowedPages = ["popup", "login", "signup", "dashboard", "quiz", "landing"];
      
      if (!allowedPages.includes(page)) {
        return res.status(404).send("Extension page not found");
      }
      
      const filePath = path.join(process.cwd(), "client", "public", "extension", `${page}.html`);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).send(`Extension page ${page}.html not found`);
      }
      
      // For debugging
      console.log('Requested extension page:', filePath);
      console.log('File exists:', fs.existsSync(filePath));
      
      // Send the file directly
      res.sendFile(filePath);
    } catch (error) {
      console.error('Error loading extension preview:', error);
      res.status(500).send("Error loading extension preview");
    }
  });

  // Endpoint to serve the popup.html from the extension directory
  app.get("/extension/popup", (req: Request, res: Response) => {
    try {
      const filePath = path.join(process.cwd(), "client", "public", "extension", "popup.html");
      
      console.log(`[express] Serving popup from: ${filePath}`);
      console.log(`[express] File exists: ${fs.existsSync(filePath)}`);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).send("Popup page not found");
      }
      
      res.sendFile(filePath);
    } catch (error) {
      console.error('Error loading popup preview:', error);
      res.status(500).send("Error loading popup preview");
    }
  });
  
  // Create a special endpoint to preview the extension popup in a more realistic way
  app.get("/extension-demo", (req: Request, res: Response) => {
    try {
      const htmlContent = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Learnfy.AI Extension Demo</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            background-color: #f9fafb;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px;
          }
          h1 {
            color: #4f46e5;
            margin-bottom: 30px;
          }
          .browser-mockup {
            border: 2px solid #d1d5db;
            border-radius: 8px;
            background-color: #fff;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            max-width: 1000px;
            width: 100%;
          }
          .extension-mockup {
            position: relative;
            width: 350px;
            border: 2px solid #d1d5db;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            background-color: white;
            margin-top: 20px;
            overflow: hidden;
          }
          .extension-header {
            background-color: #f3f4f6;
            padding: 10px;
            border-bottom: 1px solid #e5e7eb;
            text-align: center;
            font-weight: bold;
            color: #4b5563;
          }
          .extension-content {
            height: 450px;
            overflow: hidden;
          }
          iframe {
            border: none;
            width: 100%;
            height: 100%;
          }
          .instructions {
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
            color: #4b5563;
          }
          .buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
          }
          .button {
            display: inline-block;
            background-color: #4f46e5;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.2s;
          }
          .button:hover {
            background-color: #4338ca;
          }
          .button-secondary {
            background-color: #9ca3af;
          }
          .button-secondary:hover {
            background-color: #6b7280;
          }
        </style>
      </head>
      <body>
        <h1>Learnfy.AI Extension Demo</h1>
        
        <div class="instructions">
          <p>This is a demonstration of how the Learnfy.AI Chrome extension looks when installed in your browser. The extension popup appears when you click on the extension icon in your browser toolbar.</p>
        </div>
        
        <div class="buttons">
          <a href="/extension/preview/popup" class="button">View Popup</a>
          <a href="/extension/preview/signup" class="button">View Signup</a>
          <a href="/extension/preview/login" class="button">View Login</a>
          <a href="/" class="button button-secondary">Back to Landing Page</a>
        </div>
        
        <div class="browser-mockup">
          <div class="extension-mockup">
            <div class="extension-header">Learnfy.AI Extension</div>
            <div class="extension-content">
              <iframe src="/extension/preview/popup" frameborder="0"></iframe>
            </div>
          </div>
        </div>
      </body>
      </html>
      `;
      
      res.send(htmlContent);
    } catch (error) {
      console.error('Error loading extension demo:', error);
      res.status(500).send("Error loading extension demo");
    }
  });
  
  // Serve static files from the extension directory
  app.use('/extension', express().use(express.static(path.join(process.cwd(), 'client', 'public', 'extension'))));
  
  // Serve static files from the scripts directory
  app.use('/scripts', express().use(express.static(path.join(process.cwd(), 'client', 'public', 'scripts'))));
  
  // Serve voice control and accessibility scripts directly from the public dir
  app.use(express.static(path.join(process.cwd(), 'client', 'public')));
  
  // Explicit route for the extension demos page
  app.get("/extension-demos", (req: Request, res: Response) => {
    const filePath = path.join(process.cwd(), "client", "public", "extension-demos.html");
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("Extension demos page not found");
    }
  });
  
  // Route for quiz testing page
  app.get("/extension-quiz-test", (req: Request, res: Response) => {
    const filePath = path.join(process.cwd(), "client", "public", "extension-quiz-test.html");
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("Quiz test page not found");
    }
  });
  
  // Serve the extension download page
  app.get("/extension/download", (req: Request, res: Response) => {
    const filePath = path.join(process.cwd(), "client", "public", "extension", "download.html");
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("Extension download page not found");
    }
  });
  
  // Add route for downloading the extension zip file
  app.get("/learnfy-extension.zip", (req: Request, res: Response) => {
    const zipPath = path.join(process.cwd(), "client", "public", "learnfy-extension.zip");
    if (fs.existsSync(zipPath)) {
      res.download(zipPath, "learnfy-extension.zip");
    } else {
      res.status(404).send("Extension package not found");
    }
  });
  
  // Serve the extension files directly through simplified routes with better error handling
  app.get("/extension/:page", (req: Request, res: Response) => {
    try {
      const page = req.params.page;
      const filePath = path.join(process.cwd(), "client", "public", "extension", `${page}.html`);
      
      // Debug logging
      console.log(`[express] Serving extension page: ${page}`);
      console.log(`[express] File path: ${filePath}`);
      console.log(`[express] File exists: ${fs.existsSync(filePath)}`);
      
      if (!fs.existsSync(filePath)) {
        console.log(`[express] Extension page not found: ${page}`);
        return res.status(404).send(`Extension page ${page} not found`);
      }
      
      return res.sendFile(filePath);
    } catch (error) {
      console.error(`[express] Error serving extension page:`, error);
      res.status(500).send("Failed to serve extension page");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
