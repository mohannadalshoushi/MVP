
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// In development, provide a fallback URL
const isDev = process.env.NODE_ENV !== 'production';
const connectionString = process.env.DATABASE_URL || (isDev ? "postgresql://postgres:postgres@localhost:5432/postgres" : "");

let pool: Pool | null = null;
let db: any = null;

try {
  if (!connectionString) {
    console.error("⚠️ DATABASE_URL is not configured. Please add this to your deployment secrets.");
    if (!isDev) {
      console.error("Missing DATABASE_URL in production environment.");
      console.error("API endpoints requiring database access will not work,");
      console.error("but the application will continue to serve static content.");
    } else {
      console.warn("Using in-memory storage for development since DATABASE_URL is not configured.");
    }
  } else {
    pool = new Pool({ connectionString });
    db = drizzle({ client: pool, schema });
    console.log("Database connection established");
    
    // Test the connection
    pool.query("SELECT NOW()").then(() => {
      console.log("Database connection test successful");
    }).catch(err => {
      console.error("Database connection test failed:", err);
      if (!isDev) {
        // Don't exit in production - we should still serve static content
        console.error("Database connection failed. API endpoints requiring database access will not work,");
        console.error("but the application will continue to serve static content.");
      }
    });
  }
} catch (error) {
  console.error("Database connection error:", error);
  if (!isDev) {
    // Don't exit in production - we should still serve static content
    console.error("Database connection failed. API endpoints requiring database access will not work,");
    console.error("but the application will continue to serve static content.");
  }
}

export { pool, db };
