// This script helps ensure the database schema is properly synced with our Drizzle models
// It's meant to be run before deployment or after changes to the database schema

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';

const execAsync = promisify(exec);

// Check if DATABASE_URL is configured
if (!process.env.DATABASE_URL) {
  console.error('⚠️ DATABASE_URL is not set. Please set it before running this script.');
  console.error('Example: DATABASE_URL=postgresql://user:password@localhost:5432/dbname node sync-db.js');
  process.exit(1);
}

async function main() {
  try {
    console.log('🔄 Syncing database schema...');
    
    // Run drizzle-kit push to sync schema changes
    const { stdout, stderr } = await execAsync('npx drizzle-kit push');
    
    if (stderr) {
      console.error('Error during schema sync:', stderr);
    }
    
    console.log('✅ Database schema sync completed successfully!');
    console.log(stdout);
    
    // Create a timestamp file to track the last successful sync
    const timestamp = new Date().toISOString();
    await fs.writeFile('.db-sync-timestamp', timestamp);
    
    console.log(`📝 Schema sync timestamp recorded: ${timestamp}`);
    console.log('🚀 Your database is now ready for deployment!');
    
  } catch (error) {
    console.error('❌ Failed to sync database schema:', error.message);
    process.exit(1);
  }
}

main();