import { pgTable, text, serial, integer, boolean, timestamp, json, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
  sector: text("sector"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Learning categories schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

// Learning activities schema
export const learningActivities = pgTable("learning_activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  source: text("source").notNull(),
  categoryId: integer("category_id").notNull(),
  contentType: text("content_type").notNull(), // "article", "video"
  timeSpent: integer("time_spent").notNull(), // in seconds
  quizScore: integer("quiz_score"), // percentage (0-100)
  summary: text("summary"),
  learningDate: timestamp("learning_date").defaultNow(),
  language: text("language").default("english"), // The language of the content
});

// Professional certifications schema
export const certifications = pgTable("certifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  issuingOrganization: text("issuing_organization").notNull(),
  issueDate: date("issue_date").notNull(),
  expiryDate: date("expiry_date"),
  credentialID: text("credential_id"),
  credentialURL: text("credential_url"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Language skills schema
export const languageSkills = pgTable("language_skills", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  language: text("language").notNull(),
  readingTimeSpent: integer("reading_time_spent").default(0), // in seconds
  listeningTimeSpent: integer("listening_time_spent").default(0), // in seconds
  proficiencyLevel: text("proficiency_level"), // e.g., "Beginner", "Intermediate", "Advanced", "Fluent"
  lastActivity: timestamp("last_activity").defaultNow(),
});

// Quiz questions schema
export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  activityId: integer("activity_id").notNull(),
  question: text("question").notNull(),
  options: json("options").notNull(), // array of options
  correctOption: integer("correct_option").notNull(),
  userAnswer: integer("user_answer"),
});

// Learning summary schema
export const learningSummaries = pgTable("learning_summaries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  categoryId: integer("category_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Tool usage schema
export const toolUsages = pgTable("tool_usages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  toolName: text("tool_name").notNull(),
  toolCategory: text("tool_category"), // e.g., "Project Management", "Development", "Design"
  hoursSpent: integer("hours_spent").notNull(), // in seconds
  lastUsedDate: timestamp("last_used_date").defaultNow(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

// Insert schemas using drizzle-zod
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertLearningActivitySchema = createInsertSchema(learningActivities).omit({
  id: true,
  learningDate: true,
});

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({
  id: true,
});

export const insertLearningSummarySchema = createInsertSchema(learningSummaries).omit({
  id: true,
  createdAt: true,
});

export const insertToolUsageSchema = createInsertSchema(toolUsages).omit({
  id: true,
  lastUsedDate: true,
});

export const insertCertificationSchema = createInsertSchema(certifications).omit({
  id: true,
  createdAt: true,
});

export const insertLanguageSkillSchema = createInsertSchema(languageSkills).omit({
  id: true,
  lastActivity: true,
});

// TypeScript types using z.infer
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type InsertLearningActivity = z.infer<typeof insertLearningActivitySchema>;
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
export type InsertLearningSummary = z.infer<typeof insertLearningSummarySchema>;
export type InsertToolUsage = z.infer<typeof insertToolUsageSchema>;
export type InsertCertification = z.infer<typeof insertCertificationSchema>;
export type InsertLanguageSkill = z.infer<typeof insertLanguageSkillSchema>;

// Select types
export type User = typeof users.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type LearningActivity = typeof learningActivities.$inferSelect;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type LearningSummary = typeof learningSummaries.$inferSelect;
export type ToolUsage = typeof toolUsages.$inferSelect;
export type Certification = typeof certifications.$inferSelect;
export type LanguageSkill = typeof languageSkills.$inferSelect;

// Content extraction schema
export const extractContentSchema = z.object({
  url: z.string().url(),
  contentType: z.enum(["article", "video"]),
});

// Quiz generation schema
export const generateQuizSchema = z.object({
  content: z.string(),
  numQuestions: z.number().min(1).max(10).default(3),
});

// Content analysis schema
export const analyzeContentSchema = z.object({
  content: z.string(),
  category: z.string().optional(),
});

// Interface for recommended content
export interface RecommendedContent {
  id: number;
  title: string;
  description: string;
  category: Category;
  timeToRead: string;
  source: string;
  imageUrl: string;
  contentType: "article" | "video";
  url: string;
  relevanceScore?: number;  // How relevant this content is to the user (0-100)
}

// Learning milestone schema
export const learningMilestones = pgTable("learning_milestones", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  achievedAt: timestamp("achieved_at").defaultNow(),
  milestoneType: text("milestone_type").notNull(), // "time", "content_count", "quiz_score", "category_mastery"
  iconName: text("icon_name").notNull(),
  celebratedAt: timestamp("celebrated_at"),
  isHidden: boolean("is_hidden").default(false),
  isShared: boolean("is_shared").default(false),
  privacyLevel: text("privacy_level").default("private"), // "private", "connections", "public"
  shareUrl: text("share_url"),
  socialPlatforms: json("social_platforms").default([]),  // platforms where this milestone has been shared
});

export const insertLearningMilestoneSchema = createInsertSchema(learningMilestones).omit({
  id: true,
  achievedAt: true,
  celebratedAt: true,
});

export type InsertLearningMilestone = z.infer<typeof insertLearningMilestoneSchema>;
export type LearningMilestone = typeof learningMilestones.$inferSelect;

// Learning progress event for timeline display
export interface LearningProgressEvent {
  id: number;
  userId: number;
  date: Date; 
  eventType: "activity" | "milestone" | "quiz" | "streak";
  title: string;
  description: string;
  iconName: string;
  iconColor: string;
  metadata?: {
    activityId?: number;
    categoryId?: number;
    milestoneId?: number;
    quizScore?: number;
    streakDays?: number;
  };
}

// Community learning goals schema
export const learningGoals = pgTable("learning_goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  creatorId: integer("creator_id").notNull(),
  category: text("category").notNull(),
  targetDate: timestamp("target_date").notNull(),
  progress: integer("progress").default(0), // 0-100
  participants: json("participants").default([]), // Array of user IDs
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLearningGoalSchema = createInsertSchema(learningGoals).omit({
  id: true,
  progress: true,
  participants: true,
  createdAt: true,
});

export type InsertLearningGoal = z.infer<typeof insertLearningGoalSchema>;
export type LearningGoal = typeof learningGoals.$inferSelect;

// Milestone celebrations (likes/reactions from community)
export const milestoneCelebrations = pgTable("milestone_celebrations", {
  id: serial("id").primaryKey(),
  milestoneId: integer("milestone_id").notNull(),
  userId: integer("user_id").notNull(),
  celebrationType: text("celebration_type").default("like"), // like, congrats, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMilestoneCelebrationSchema = createInsertSchema(milestoneCelebrations).omit({
  id: true,
  createdAt: true,
});

export type InsertMilestoneCelebration = z.infer<typeof insertMilestoneCelebrationSchema>;
export type MilestoneCelebration = typeof milestoneCelebrations.$inferSelect;

// Milestone comments
export const milestoneComments = pgTable("milestone_comments", {
  id: serial("id").primaryKey(),
  milestoneId: integer("milestone_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMilestoneCommentSchema = createInsertSchema(milestoneComments).omit({
  id: true,
  createdAt: true,
});

export type InsertMilestoneComment = z.infer<typeof insertMilestoneCommentSchema>;
export type MilestoneComment = typeof milestoneComments.$inferSelect;
